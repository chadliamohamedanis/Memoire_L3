<?php
session_start();

$host        = 'localhost';
$dbname      = 'anis';
$db_username = 'root';
$db_password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $db_username, $db_password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    $pdo = null;
}

$isLoggedIn   = isset($_SESSION['user_id']);
$userRole     = $_SESSION['role'] ?? null;
$userName     = $_SESSION['username'] ?? null;
$userPhoto    = null;
$userFullName = $userName;

if ($isLoggedIn && $pdo) {
    $stmt = $pdo->prepare("SELECT ProfilePictureURL, FullName FROM Users WHERE UserID = :uid");
    $stmt->execute(['uid' => $_SESSION['user_id']]);
    $ud = $stmt->fetch(PDO::FETCH_ASSOC);
    $userPhoto    = $ud['ProfilePictureURL'] ?? null;
    $userFullName = $ud['FullName'] ?? $userName;
}

 
$searchQ    = trim($_GET['q']        ?? '');
$filterCat  = trim($_GET['category'] ?? '');
$filterWil  = trim($_GET['wilaya']   ?? '');
$sortBy     = trim($_GET['sort']     ?? 'rating');

 
$where  = ['1=1'];
$params = [];

if ($searchQ !== '') {
    $where[]          = '(s.Title LIKE :q OR s.Description LIKE :q2 OR s.Category LIKE :q3)';
    $params[':q']     = '%' . $searchQ . '%';
    $params[':q2']    = '%' . $searchQ . '%';
    $params[':q3']    = '%' . $searchQ . '%';
}
if ($filterCat !== '') {
    $where[]          = 's.Category = :cat';
    $params[':cat']   = $filterCat;
}
if ($filterWil !== '') {
    $where[]          = 'a.State = :wil';
    $params[':wil']   = $filterWil;
}

$orderBy = match($sortBy) {
    'price_asc'  => 's.Price ASC',
    'price_desc' => 's.Price DESC',
    'newest'     => 's.ServiceID DESC',
    default      => 's.Rating DESC, s.ServiceID DESC',
};

$services = [];
$total    = 0;
if ($pdo) {
    $whereStr = implode(' AND ', $where);
    $sql = "
        SELECT s.ServiceID, s.Title, s.Description, s.Price, s.Rating, s.ImageURL, s.Category, s.CreatedAt,
               u.FullName AS ArtisanName, u.ProfilePictureURL AS ArtisanPhoto,
               a.State AS ArtisanState, a.YearsOfExperience, a.Specialty, a.ArtisanID
        FROM Services s
        JOIN Artisans a ON s.ArtisanID = a.ArtisanID
        JOIN Users u ON a.UserID = u.UserID
        WHERE $whereStr
        ORDER BY $orderBy
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $services = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $total    = count($services);
}

$catMeta = [
    'Électricité'   => ['icon' => 'fas fa-bolt',        'color' => '#f59e0b'],
    'Plomberie'     => ['icon' => 'fas fa-faucet',       'color' => '#3b82f6'],
    'Peinture'      => ['icon' => 'fas fa-paint-roller', 'color' => '#ec4899'],
    'Maçonnerie'    => ['icon' => 'fas fa-hard-hat',     'color' => '#8b5cf6'],
    'Menuiserie'    => ['icon' => 'fas fa-hammer',       'color' => '#10b981'],
    'Climatisation' => ['icon' => 'fas fa-snowflake',    'color' => '#06b6d4'],
    'Soudure'       => ['icon' => 'fas fa-fire',         'color' => '#f97316'],
    'Autre'         => ['icon' => 'fas fa-tools',        'color' => '#6b7280'],
];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recherche — Services Artisans</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }

        :root {
            --primary:   #1e3a5f;
            --accent:    #3b66f5;
            --accent2:   #f97316;
            --success:   #10b981;
            --bg:        #f4f7fe;
            --white:     #ffffff;
            --text:      #1a202c;
            --muted:     #718096;
            --border:    #e2e8f0;
            --radius:    14px;
            --shadow:    0 4px 24px rgba(0,0,0,0.07);
            --shadow-lg: 0 12px 40px rgba(0,0,0,0.12);
        }

        body { font-family: 'Cairo', sans-serif; background: var(--bg); color: var(--text); }

 
        .nav { background: var(--white); padding: 0 5%; position: sticky; top: 0; z-index: 100; box-shadow: 0 2px 16px rgba(0,0,0,0.06); }
        .nav-inner { max-width: 1300px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; height: 68px; gap: 1.5rem; }
        .nav-brand { font-size: 1.4rem; font-weight: 900; color: var(--accent); text-decoration: none; white-space: nowrap; }
        .nav-brand span { color: var(--accent2); }
        .nav-search { flex: 1; max-width: 480px; position: relative; }
        .nav-search input { width: 100%; padding: 0.6rem 1rem 0.6rem 2.75rem; border: 1.5px solid var(--border); border-radius: 999px; font-family: 'Cairo', sans-serif; font-size: 0.9rem; outline: none; background: var(--bg); transition: border-color 0.2s; }
        .nav-search input:focus { border-color: var(--accent); background: white; }
        .nav-search i { position: absolute; left: 1rem; top: 50%; transform: translateY(-50%); color: var(--muted); font-size: 0.85rem; }
        .nav-actions { display: flex; gap: 0.75rem; align-items: center; }
        .btn { display: inline-flex; align-items: center; gap: 0.5rem; padding: 0.5rem 1.1rem; border-radius: 999px; font-family: 'Cairo', sans-serif; font-size: 0.88rem; font-weight: 600; cursor: pointer; text-decoration: none; border: none; transition: all 0.2s; }
        .btn-outline { border: 2px solid var(--accent); color: var(--accent); background: transparent; }
        .btn-outline:hover { background: var(--accent); color: white; }
        .btn-filled { background: linear-gradient(135deg, var(--accent), #6c8fff); color: white; }
        .btn-filled:hover { opacity: 0.9; transform: translateY(-1px); }
        .user-chip { display: flex; align-items: center; gap: 0.6rem; background: var(--bg); border: 1.5px solid var(--border); border-radius: 999px; padding: 0.3rem 1rem 0.3rem 0.3rem; text-decoration: none; color: var(--text); font-weight: 600; font-size: 0.85rem; transition: border-color 0.2s; }
        .user-chip:hover { border-color: var(--accent); }
        .user-avatar { width: 32px; height: 32px; border-radius: 50%; background: linear-gradient(135deg, var(--accent), #6c8fff); display: flex; align-items: center; justify-content: center; color: white; font-weight: 700; font-size: 0.85rem; overflow: hidden; flex-shrink: 0; }
        .user-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .btn-logout { color: var(--muted); font-size: 0.85rem; font-weight: 600; background: none; border: none; cursor: pointer; font-family: 'Cairo', sans-serif; padding: 0.4rem 0.7rem; border-radius: 8px; transition: color 0.2s, background 0.2s; }
        .btn-logout:hover { color: #e53e3e; background: #fff5f5; }

 
        .search-hero {
            background: linear-gradient(135deg, var(--primary) 0%, #2d4f7c 100%);
            padding: 2.5rem 5%;
        }
        .search-hero-inner { max-width: 1300px; margin: 0 auto; }
        .search-hero h1 { color: white; font-size: 1.5rem; font-weight: 800; margin-bottom: 1.25rem; }
        .search-hero h1 span { color: #fbbf24; }
        .search-bar-wrap {
            display: flex;
            background: white;
            border-radius: 999px;
            padding: 6px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.2);
            max-width: 720px;
        }
        .search-bar-wrap input {
            flex: 1;
            border: none;
            padding: 0.75rem 1.5rem;
            font-family: 'Cairo', sans-serif;
            font-size: 1rem;
            color: var(--text);
            outline: none;
            border-radius: 999px;
            background: transparent;
        }
        .search-bar-btn {
            background: linear-gradient(135deg, var(--accent), #6c8fff);
            color: white; border: none;
            padding: 0.75rem 1.75rem;
            border-radius: 999px;
            font-family: 'Cairo', sans-serif;
            font-size: 0.95rem; font-weight: 700;
            cursor: pointer; display: flex; align-items: center; gap: 0.5rem;
            transition: opacity 0.2s, transform 0.1s;
            white-space: nowrap;
        }
        .search-bar-btn:hover { opacity: 0.9; transform: scale(1.02); }

 
        .page-layout {
            max-width: 1300px;
            margin: 2rem auto;
            padding: 0 5% 4rem;
            display: grid;
            grid-template-columns: 280px 1fr;
            gap: 2rem;
            align-items: start;
        }

 
        .sidebar-filters {
            background: white;
            border-radius: var(--radius);
            border: 1.5px solid var(--border);
            overflow: hidden;
            position: sticky;
            top: 88px;
        }
        .sf-header {
            background: linear-gradient(135deg, var(--primary), #2d4f7c);
            color: white;
            padding: 1.1rem 1.25rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .sf-header h3 { font-size: 1rem; font-weight: 700; display: flex; align-items: center; gap: 0.5rem; }
        .sf-reset { background: rgba(255,255,255,0.15); border: none; color: white; font-family: 'Cairo', sans-serif; font-size: 0.78rem; font-weight: 600; padding: 0.3rem 0.8rem; border-radius: 999px; cursor: pointer; transition: background 0.2s; }
        .sf-reset:hover { background: rgba(255,255,255,0.3); }

        .sf-section { padding: 1.25rem; border-bottom: 1px solid var(--border); }
        .sf-section:last-child { border-bottom: none; }
        .sf-label { font-size: 0.8rem; font-weight: 700; color: var(--muted); text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 0.85rem; display: flex; align-items: center; gap: 0.4rem; }
        .sf-label i { color: var(--accent); }

        .sf-select {
            width: 100%;
            padding: 0.6rem 0.9rem;
            border: 1.5px solid var(--border);
            border-radius: 10px;
            font-family: 'Cairo', sans-serif;
            font-size: 0.9rem;
            color: var(--text);
            background: var(--bg);
            outline: none;
            cursor: pointer;
            transition: border-color 0.2s;
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23718096' d='M6 8L1 3h10z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 0.9rem center;
            background-color: var(--bg);
            padding-right: 2.25rem;
        }
        .sf-select:focus { border-color: var(--accent); background-color: white; }

 
        .cat-pills { display: flex; flex-direction: column; gap: 0.5rem; }
        .cat-pill {
            display: flex; align-items: center; gap: 0.65rem;
            padding: 0.55rem 0.85rem;
            border-radius: 10px;
            border: 1.5px solid var(--border);
            cursor: pointer;
            font-size: 0.88rem; font-weight: 600; color: var(--text);
            transition: all 0.15s;
            background: var(--bg);
        }
        .cat-pill:hover { border-color: var(--accent); color: var(--accent); background: #f0f4ff; }
        .cat-pill.active { background: var(--accent); color: white; border-color: var(--accent); }
        .cat-pill .pill-icon { width: 22px; text-align: center; }
        .cat-pill .pill-count { margin-left: auto; font-size: 0.75rem; opacity: 0.7; }

 
        .sort-btns { display: flex; flex-direction: column; gap: 0.4rem; }
        .sort-btn { display: flex; align-items: center; gap: 0.6rem; padding: 0.55rem 0.85rem; border-radius: 10px; border: 1.5px solid var(--border); cursor: pointer; font-size: 0.88rem; font-weight: 600; color: var(--text); background: var(--bg); transition: all 0.15s; }
        .sort-btn:hover { border-color: var(--accent); color: var(--accent); }
        .sort-btn.active { background: var(--accent); color: white; border-color: var(--accent); }
        .sort-btn i { width: 16px; text-align: center; }

 
        .results-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
            gap: 0.75rem;
        }
        .results-count { font-size: 1rem; font-weight: 700; color: var(--primary); }
        .results-count span { color: var(--accent); }
        .active-filters { display: flex; gap: 0.5rem; flex-wrap: wrap; }
        .filter-tag { display: inline-flex; align-items: center; gap: 0.4rem; background: #eef2ff; color: var(--accent); font-size: 0.8rem; font-weight: 600; padding: 0.3rem 0.75rem; border-radius: 999px; }
        .filter-tag button { background: none; border: none; cursor: pointer; color: var(--accent); font-size: 0.9rem; line-height: 1; padding: 0; margin-left: 2px; }

 
        .cards-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(265px, 1fr));
            gap: 1.25rem;
        }

        .svc-card {
            background: white;
            border-radius: 18px;
            overflow: hidden;
            border: 1.5px solid var(--border);
            transition: transform 0.2s, box-shadow 0.2s, border-color 0.2s;
            text-decoration: none;
            color: inherit;
            display: flex;
            flex-direction: column;
        }
        .svc-card:hover { transform: translateY(-4px); box-shadow: var(--shadow-lg); border-color: #c3d0ff; }

        .svc-img-wrap { position: relative; }
        .svc-img { width: 100%; height: 165px; object-fit: cover; display: block; }
        .svc-img-placeholder { width: 100%; height: 165px; background: linear-gradient(135deg, #eef2ff, #e0e7ff); display: flex; align-items: center; justify-content: center; font-size: 2.8rem; color: #a5b4fc; }
        .svc-cat-badge {
            position: absolute; top: 0.7rem; left: 0.7rem;
            background: white;
            border-radius: 999px;
            padding: 0.25rem 0.75rem;
            font-size: 0.72rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em;
            box-shadow: 0 2px 8px rgba(0,0,0,0.12);
        }

        .svc-body { padding: 1rem; flex: 1; display: flex; flex-direction: column; }
        .svc-title { font-size: 0.95rem; font-weight: 700; color: var(--text); margin-bottom: 0.6rem; line-height: 1.3; }

        .svc-artisan-row { display: flex; align-items: center; gap: 0.6rem; margin-bottom: 0.4rem; }
        .svc-artisan-avatar { width: 26px; height: 26px; border-radius: 50%; background: linear-gradient(135deg, var(--accent), #6c8fff); display: flex; align-items: center; justify-content: center; color: white; font-size: 0.72rem; font-weight: 700; overflow: hidden; flex-shrink: 0; }
        .svc-artisan-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .svc-artisan-name { font-size: 0.82rem; font-weight: 600; color: var(--text); }
        .svc-artisan-spec { font-size: 0.75rem; color: var(--muted); }

        .svc-meta-row { display: flex; align-items: center; gap: 0.4rem; font-size: 0.8rem; color: var(--muted); margin-bottom: 0.3rem; }
        .svc-meta-row i { width: 14px; text-align: center; }
        .svc-meta-row i.loc { color: var(--accent2); }
        .svc-meta-row i.exp { color: var(--success); }

        .svc-footer { display: flex; justify-content: space-between; align-items: center; padding-top: 0.85rem; margin-top: auto; border-top: 1px solid var(--border); }
        .svc-price { font-size: 1rem; font-weight: 800; color: var(--accent); }
        .svc-price small { font-size: 0.7rem; font-weight: 500; color: var(--muted); display: block; line-height: 1.2; }
        .svc-rating { display: flex; align-items: center; gap: 3px; font-size: 0.82rem; font-weight: 700; color: #f59e0b; }
        .svc-rating .reviews { font-size: 0.72rem; color: var(--muted); font-weight: 400; margin-left: 2px; }

 
        .no-results {
            grid-column: 1/-1;
            text-align: center;
            padding: 5rem 2rem;
            color: var(--muted);
        }
        .no-results i { font-size: 3.5rem; opacity: 0.25; display: block; margin-bottom: 1.25rem; }
        .no-results h3 { font-size: 1.2rem; font-weight: 700; color: var(--primary); margin-bottom: 0.5rem; }

 
        @media (max-width: 900px) {
            .page-layout { grid-template-columns: 1fr; }
            .sidebar-filters { position: static; }
            .cat-pills { flex-direction: row; flex-wrap: wrap; }
            .cat-pill { flex-direction: row; }
            .sort-btns { flex-direction: row; flex-wrap: wrap; }
        }
        @media (max-width: 600px) {
            .nav-search { display: none; }
            .search-hero h1 { font-size: 1.2rem; }
        }
    </style>
</head>
<body>

 
<nav class="nav">
    <div class="nav-inner">
                 <a href="Home.php" class="nav-brand">  <i class="fas fa-screwdriver-wrench" style="color:#3b66f5; margin-right:8px;"></i>Services <span>Artisans</span></a>

        <div class="nav-search">
            <i class="fas fa-search"></i>
            <input type="text" id="navSearchInput" placeholder="Rechercher un service..."
                value="<?php echo htmlspecialchars($searchQ); ?>"
                onkeydown="if(event.key==='Enter') doSearch(this.value)">
        </div>
        <div class="nav-actions">
            <?php if ($isLoggedIn): ?>
                <a href="profile.php" class="user-chip">
                    <div class="user-avatar">
                        <?php if ($userPhoto): ?>
                            <img src="data:image/jpeg;base64,<?php echo $userPhoto; ?>" alt="">
                        <?php else: ?>
                            <?php echo strtoupper(substr($userFullName ?? $userName, 0, 1)); ?>
                        <?php endif; ?>
                    </div>
                    <?php echo htmlspecialchars($userFullName ?? $userName); ?>
                </a>
                <?php if ($userRole === 'Artisan'): ?>
                    <a href="services.php" class="btn btn-outline"><i class="fas fa-briefcase"></i> Mes services</a>
                <?php endif; ?>
                <form method="GET" action="profile.php" style="display:inline;">
                    <input type="hidden" name="logout" value="1">
                    <button type="submit" class="btn-logout"><i class="fas fa-sign-out-alt"></i> Déconnexion</button>
                </form>
            <?php else: ?>
                <a href="index1.php" class="btn btn-outline"><i class="fas fa-sign-in-alt"></i> Connexion</a>
                <a href="register.php" class="btn btn-filled"><i class="fas fa-user-plus"></i> S'inscrire</a>
            <?php endif; ?>
        </div>
    </div>
</nav>

 
<div class="search-hero">
    <div class="search-hero-inner">
        <h1>
            <?php if ($searchQ): ?>
                Résultats pour <span>"<?php echo htmlspecialchars($searchQ); ?>"</span>
            <?php elseif ($filterCat): ?>
                Services — <span><?php echo htmlspecialchars($filterCat); ?></span>
            <?php else: ?>
                Tous les <span>services disponibles</span>
            <?php endif; ?>
        </h1>
        <div class="search-bar-wrap">
            <input type="text" id="mainSearch" placeholder="Rechercher un service, un artisan..."
                value="<?php echo htmlspecialchars($searchQ); ?>"
                onkeydown="if(event.key==='Enter') doSearch(this.value)">
            <button class="search-bar-btn" onclick="doSearch(document.getElementById('mainSearch').value)">
                <i class="fas fa-search"></i> Rechercher
            </button>
        </div>
    </div>
</div>

 
<div class="page-layout">

 
    <aside class="sidebar-filters">
        <div class="sf-header">
            <h3><i class="fas fa-sliders-h"></i> Filtres</h3>
            <button class="sf-reset" onclick="resetAll()">Tout effacer</button>
        </div>

 
        <div class="sf-section">
            <div class="sf-label"><i class="fas fa-map-marker-alt"></i> Wilaya</div>
            <select class="sf-select" id="sideWilaya" onchange="applyFilters()">
                <option value="">Toutes les wilayas</option>
            </select>
        </div>

 
        <div class="sf-section">
            <div class="sf-label"><i class="fas fa-th-large"></i> Catégorie</div>
            <div class="cat-pills" id="catPills">
                <div class="cat-pill <?php echo $filterCat===''?'active':''; ?>" data-cat="" onclick="selectCat(this, '')">
                    <span class="pill-icon"><i class="fas fa-border-all"></i></span>
                    Toutes
                </div>
                <?php foreach ($catMeta as $name => $meta): ?>
                <div class="cat-pill <?php echo $filterCat===$name?'active':''; ?>"
                     data-cat="<?php echo htmlspecialchars($name); ?>"
                     onclick="selectCat(this, '<?php echo htmlspecialchars($name, ENT_QUOTES); ?>')">
                    <span class="pill-icon" style="color:<?php echo $meta['color']; ?>"><i class="<?php echo $meta['icon']; ?>"></i></span>
                    <?php echo htmlspecialchars($name); ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

 
        <div class="sf-section">
            <div class="sf-label"><i class="fas fa-sort"></i> Trier par</div>
            <div class="sort-btns" id="sortBtns">
                <div class="sort-btn <?php echo $sortBy==='rating'?'active':''; ?>" data-sort="rating" onclick="selectSort(this,'rating')">
                    <i class="fas fa-star"></i> Mieux notés
                </div>
                <div class="sort-btn <?php echo $sortBy==='newest'?'active':''; ?>" data-sort="newest" onclick="selectSort(this,'newest')">
                    <i class="fas fa-clock"></i> Plus récents
                </div>
                <div class="sort-btn <?php echo $sortBy==='price_asc'?'active':''; ?>" data-sort="price_asc" onclick="selectSort(this,'price_asc')">
                    <i class="fas fa-arrow-up"></i> Prix croissant
                </div>
                <div class="sort-btn <?php echo $sortBy==='price_desc'?'active':''; ?>" data-sort="price_desc" onclick="selectSort(this,'price_desc')">
                    <i class="fas fa-arrow-down"></i> Prix décroissant
                </div>
            </div>
        </div>
    </aside>

 
    <div class="results-area">
        <div class="results-header">
            <div class="results-count">
                <span id="visibleCount"><?php echo $total; ?></span> service<?php echo $total!==1?'s':''; ?> trouvé<?php echo $total!==1?'s':''; ?>
            </div>
            <div class="active-filters" id="activeTags"></div>
        </div>

        <div class="cards-grid" id="cardsGrid">
            <?php if (empty($services)): ?>
            <div class="no-results">
                <i class="fas fa-search"></i>
                <h3>Aucun service trouvé</h3>
                <p>Essayez d'autres mots-clés ou modifiez les filtres.</p>
            </div>
            <?php else: ?>
            <?php foreach ($services as $svc): ?>
            <a href="service-detail.php?id=<?php echo $svc['ServiceID']; ?>"
               class="svc-card"
               data-category="<?php echo htmlspecialchars($svc['Category'] ?? ''); ?>"
               data-wilaya="<?php echo htmlspecialchars($svc['ArtisanState'] ?? ''); ?>"
               data-price="<?php echo floatval($svc['Price']); ?>"
               data-rating="<?php echo floatval($svc['Rating'] ?? 0); ?>">

                <div class="svc-img-wrap">
                    <?php if (!empty($svc['ImageURL'])): ?>
                        <img src="<?php echo $svc['ImageURL']; ?>" alt="<?php echo htmlspecialchars($svc['Title']); ?>" class="svc-img">
                    <?php else: ?>
                        <div class="svc-img-placeholder"><i class="fas fa-briefcase"></i></div>
                    <?php endif; ?>
                    <?php if (!empty($svc['Category'])): ?>
                    <?php $cm = $catMeta[$svc['Category']] ?? null; ?>
                    <span class="svc-cat-badge" style="color:<?php echo $cm?$cm['color']:'#6b7280'; ?>">
                        <?php if ($cm): ?><i class="<?php echo $cm['icon']; ?>"></i> <?php endif; ?>
                        <?php echo htmlspecialchars($svc['Category']); ?>
                    </span>
                    <?php endif; ?>
                </div>

                <div class="svc-body">
                    <div class="svc-title"><?php echo htmlspecialchars($svc['Title']); ?></div>

                    <div class="svc-artisan-row">
                        <div class="svc-artisan-avatar">
                            <?php if (!empty($svc['ArtisanPhoto'])): ?>
                                <img src="data:image/jpeg;base64,<?php echo $svc['ArtisanPhoto']; ?>" alt="">
                            <?php else: ?>
                                <?php echo strtoupper(substr($svc['ArtisanName'], 0, 1)); ?>
                            <?php endif; ?>
                        </div>
                        <div>
                            <div class="svc-artisan-name"><?php echo htmlspecialchars($svc['ArtisanName']); ?></div>
                            <?php if (!empty($svc['Specialty'])): ?>
                            <div class="svc-artisan-spec"><?php echo htmlspecialchars($svc['Specialty']); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <?php if (!empty($svc['ArtisanState'])): ?>
                    <div class="svc-meta-row">
                        <i class="fas fa-map-marker-alt loc"></i>
                        <?php echo htmlspecialchars($svc['ArtisanState']); ?>
                    </div>
                    <?php endif; ?>

                    <?php if (!empty($svc['YearsOfExperience'])): ?>
                    <div class="svc-meta-row">
                        <i class="fas fa-briefcase exp"></i>
                        <?php echo $svc['YearsOfExperience']; ?> ans d'expérience
                    </div>
                    <?php endif; ?>

                    <div class="svc-footer">
                        <div class="svc-price">
                            <?php if ($svc['Price'] > 0): ?>
                                <?php echo number_format($svc['Price'], 0, ',', ' '); ?> DA
                                <small>/ intervention</small>
                            <?php else: ?>
                                Sur devis
                            <?php endif; ?>
                        </div>
                        <?php if (!empty($svc['Rating'])): ?>
                        <div class="svc-rating">
                            <i class="fas fa-star"></i>
                            <?php echo number_format($svc['Rating'], 1); ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </a>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>

 
        <div id="jsNoResults" style="display:none; text-align:center; padding:4rem 2rem; color:#a0aec0;">
            <i class="fas fa-search" style="font-size:3rem;opacity:0.25;display:block;margin-bottom:1rem;"></i>
            <h3 style="font-size:1.1rem;font-weight:700;color:#2d3748;margin-bottom:0.5rem;">Aucun résultat</h3>
            <p>Modifiez les filtres pour trouver un service.</p>
        </div>
    </div>
</div>

<script src="locations.js"></script>
<script>
 
let activeWilaya   = '<?php echo addslashes($filterWil); ?>';
let activeCategory = '<?php echo addslashes($filterCat); ?>';
let activeSort     = '<?php echo addslashes($sortBy); ?>';

 
document.addEventListener('DOMContentLoaded', function () {
    const sel = document.getElementById('sideWilaya');
    if (sel && typeof getAllStates === 'function') {
        getAllStates().forEach(function (w) {
            const opt = document.createElement('option');
            opt.value = w;
            opt.textContent = w;
            if (w === activeWilaya) opt.selected = true;
            sel.appendChild(opt);
        });
    }
    renderActiveTags();
    applyFilters();
});

 
function selectCat(el, cat) {
    document.querySelectorAll('.cat-pill').forEach(p => p.classList.remove('active'));
    el.classList.add('active');
    activeCategory = cat;
    applyFilters();
}

function selectSort(el, sort) {
    document.querySelectorAll('.sort-btn').forEach(b => b.classList.remove('active'));
    el.classList.add('active');
    activeSort = sort;
    applyFilters();
}

 
function applyFilters() {
    activeWilaya = document.getElementById('sideWilaya').value.trim().toLowerCase();

    const cards   = Array.from(document.querySelectorAll('#cardsGrid .svc-card'));
    let   visible = 0;

    cards.forEach(function (card) {
        const cw = (card.dataset.wilaya   || '').trim().toLowerCase();
        const cc = (card.dataset.category || '').trim().toLowerCase();

        const matchW = !activeWilaya   || cw === activeWilaya;
        const matchC = !activeCategory || cc === activeCategory.toLowerCase();

        card.style.display = (matchW && matchC) ? '' : 'none';
        if (matchW && matchC) visible++;
    });

     
    sortCards(cards.filter(c => c.style.display !== 'none'));

     
    document.getElementById('visibleCount').textContent = visible;

 
    document.getElementById('jsNoResults').style.display = visible === 0 ? 'block' : 'none';

    renderActiveTags();
}

function sortCards(visibleCards) {
    const grid = document.getElementById('cardsGrid');
    visibleCards.sort(function (a, b) {
        if (activeSort === 'price_asc') {
            return parseFloat(a.dataset.price) - parseFloat(b.dataset.price);
        } else if (activeSort === 'price_desc') {
            return parseFloat(b.dataset.price) - parseFloat(a.dataset.price);
        } else if (activeSort === 'newest') {
            return parseInt(b.dataset.id || 0) - parseInt(a.dataset.id || 0);
        } else {
            return parseFloat(b.dataset.rating) - parseFloat(a.dataset.rating);
        }
    });
    visibleCards.forEach(c => grid.appendChild(c));
}

 
function renderActiveTags() {
    const wrap = document.getElementById('activeTags');
    wrap.innerHTML = '';

    const w = document.getElementById('sideWilaya').value;
    if (w) {
        wrap.innerHTML += `<span class="filter-tag"><i class="fas fa-map-marker-alt"></i> ${w}
            <button onclick="clearWilaya()">×</button></span>`;
    }
    if (activeCategory) {
        wrap.innerHTML += `<span class="filter-tag"><i class="fas fa-th-large"></i> ${activeCategory}
            <button onclick="clearCategory()">×</button></span>`;
    }
}

function clearWilaya() {
    document.getElementById('sideWilaya').value = '';
    activeWilaya = '';
    applyFilters();
}

function clearCategory() {
    activeCategory = '';
    document.querySelectorAll('.cat-pill').forEach(p => p.classList.remove('active'));
    document.querySelector('.cat-pill[data-cat=""]').classList.add('active');
    applyFilters();
}

function resetAll() {
    document.getElementById('sideWilaya').value = '';
    activeWilaya   = '';
    activeCategory = '';
    activeSort     = 'rating';
    document.querySelectorAll('.cat-pill').forEach(p => p.classList.remove('active'));
    document.querySelector('.cat-pill[data-cat=""]').classList.add('active');
    document.querySelectorAll('.sort-btn').forEach(b => b.classList.remove('active'));
    document.querySelector('.sort-btn[data-sort="rating"]').classList.add('active');
    applyFilters();
}

 
function doSearch(q) {
    q = q.trim();
    const params = new URLSearchParams();
    if (q)             params.set('q', q);
    if (activeCategory) params.set('category', activeCategory);
    if (activeWilaya)   params.set('wilaya', activeWilaya);
    if (activeSort !== 'rating') params.set('sort', activeSort);
    window.location.href = 'search-results.php?' + params.toString();
}

document.getElementById('mainSearch').addEventListener('input', function() {
    document.getElementById('navSearchInput').value = this.value;
});
</script>
</body>
</html>