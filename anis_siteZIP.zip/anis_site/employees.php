<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Artisan') {
    header("Location: index1.php");
    exit();
}

$host = 'localhost';
$dbname = 'anis';
$username = 'root';
$password = '';

ini_set('display_errors', 1);
error_reporting(E_ALL);

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

$userID = $_SESSION['user_id'];

 
$stmt = $pdo->prepare("SELECT * FROM Artisans WHERE UserID = :userID");
$stmt->execute(['userID' => $userID]);
$artisanData = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$artisanData) {
    die("Artisan non trouvé.");
}

$success = '';
$error = '';

 
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'addEmployee') {
    $fullName   = trim($_POST['fullName']);
    $phone      = trim($_POST['phone']);
    $email      = trim($_POST['email']);
    $specialty  = trim($_POST['specialty']);
    $experience = intval($_POST['experience'] ?? 0);
    $notes      = trim($_POST['notes']);

    if (empty($fullName) || empty($phone)) {
        $error = "Le nom et le téléphone sont obligatoires.";
    } else {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO Employees (ArtisanID, FullName, PhoneNumber, Email, Specialty, YearsOfExperience, Notes)
                VALUES (:artisanID, :fullName, :phone, :email, :specialty, :experience, :notes)
            ");
            $stmt->execute([
                'artisanID'  => $artisanData['ArtisanID'],
                'fullName'   => $fullName,
                'phone'      => $phone,
                'email'      => $email ?: null,
                'specialty'  => $specialty ?: null,
                'experience' => $experience,
                'notes'      => $notes ?: null,
            ]);
            $success = "Employé ajouté avec succès !";
        } catch (PDOException $e) {
            $error = "Erreur : " . $e->getMessage();
        }
    }
}

 
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'deleteEmployee') {
    $empID = intval($_POST['employeeID']);
    try {
        $stmt = $pdo->prepare("DELETE FROM Employees WHERE EmployeeID = :id AND ArtisanID = :artisanID");
        $stmt->execute(['id' => $empID, 'artisanID' => $artisanData['ArtisanID']]);
        $success = "Employé supprimé.";
    } catch (PDOException $e) {
        $error = "Erreur lors de la suppression.";
    }
}

 
$stmt = $pdo->prepare("SELECT * FROM Employees WHERE ArtisanID = :artisanID ORDER BY EmployeeID DESC");
$stmt->execute(['artisanID' => $artisanData['ArtisanID']]);
$employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Employés</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Cairo', sans-serif;
            background: #f0f4ff;
            color: #2d3748;
            min-height: 100vh;
        }

 
        .nav-header {
            background: white;
            box-shadow: 0 2px 12px rgba(0,0,0,0.07);
            padding: 0 2rem;
            position: sticky;
            top: 0;
            z-index: 100;
        }
        .nav-header-content {
            max-width: 1100px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 64px;
        }
        .nav-brand { font-size: 1.4rem; font-weight: 900; color: #3b66f5; text-decoration: none; }
        .nav-links a {
            color: #4a5568;
            text-decoration: none;
            margin-left: 1.5rem;
            font-size: 0.9rem;
            font-weight: 500;
            transition: color 0.2s;
        }
        .nav-links a:hover { color: #3b66f5; }

 
        .main-wrapper {
            max-width: 1000px;
            margin: 2rem auto;
            padding: 0 1.5rem 4rem;
        }

 
        .header-card {
            background: linear-gradient(135deg, #3b66f5, #6c8fff);
            color: white;
            border-radius: 20px;
            padding: 2rem 2.5rem;
            display: flex;
            align-items: center;
            gap: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 8px 30px rgba(59,102,245,0.3);
        }
        .header-card > i { font-size: 2.5rem; opacity: 0.9; }
        .header-card h1 { font-size: 1.6rem; font-weight: 700; }
        .header-card p { opacity: 0.85; font-size: 0.95rem; margin-top: 0.25rem; }

 
        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            color: #718096;
            text-decoration: none;
            font-size: 0.9rem;
            margin-bottom: 1.5rem;
            transition: color 0.2s;
        }
        .back-link:hover { color: #3b66f5; }

 
        .message {
            padding: 1rem 1.5rem;
            border-radius: 12px;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-weight: 500;
            font-size: 0.95rem;
        }
        .message.success { background: #d1fae5; color: #065f46; }
        .message.error   { background: #fee2e2; color: #991b1b; }

 
        .card {
            background: white;
            border-radius: 16px;
            box-shadow: 0 2px 16px rgba(0,0,0,0.06);
            padding: 2rem;
            margin-bottom: 2rem;
        }
        .card-title {
            font-size: 1.1rem;
            font-weight: 700;
            color: #2d3748;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.6rem;
        }
        .card-title i { color: #3b66f5; }

 
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        .form-group { margin-bottom: 1rem; }
        .form-group label {
            display: block;
            font-size: 0.85rem;
            font-weight: 600;
            color: #4a5568;
            margin-bottom: 0.4rem;
        }
        .form-field {
            width: 100%;
            padding: 0.7rem 1rem;
            border: 1.5px solid #e2e8f0;
            border-radius: 10px;
            font-family: 'Cairo', sans-serif;
            font-size: 0.95rem;
            color: #2d3748;
            background: #f8faff;
            transition: border-color 0.2s, box-shadow 0.2s;
            outline: none;
        }
        .form-field:focus {
            border-color: #3b66f5;
            box-shadow: 0 0 0 3px rgba(59,102,245,0.1);
            background: white;
        }
        textarea.form-field { resize: vertical; }

        .btn-submit {
            background: linear-gradient(135deg, #3b66f5, #6c8fff);
            color: white;
            border: none;
            padding: 0.8rem 2rem;
            border-radius: 10px;
            font-family: 'Cairo', sans-serif;
            font-size: 0.95rem;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: opacity 0.2s, transform 0.1s;
            margin-top: 0.5rem;
        }
        .btn-submit:hover { opacity: 0.92; transform: translateY(-1px); }

 
        .grid-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 1.25rem;
        }

        .emp-card {
            background: white;
            border: 1.5px solid #e8eeff;
            border-radius: 14px;
            padding: 1.25rem;
            transition: box-shadow 0.2s, transform 0.2s;
            position: relative;
        }
        .emp-card:hover {
            box-shadow: 0 6px 20px rgba(59,102,245,0.12);
            transform: translateY(-2px);
        }

        .emp-avatar {
            width: 46px;
            height: 46px;
            border-radius: 50%;
            background: linear-gradient(135deg, #3b66f5, #6c8fff);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            font-weight: 700;
            flex-shrink: 0;
        }

        .emp-header {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin-bottom: 0.9rem;
        }

        .emp-name { font-weight: 700; font-size: 1rem; color: #2d3748; }
        .emp-specialty {
            font-size: 0.8rem;
            background: #eef2ff;
            color: #3b66f5;
            padding: 0.2rem 0.6rem;
            border-radius: 999px;
            font-weight: 600;
            display: inline-block;
            margin-top: 2px;
        }

        .emp-details { font-size: 0.85rem; color: #4a5568; line-height: 2; }
        .emp-details i { width: 16px; color: #3b66f5; margin-right: 4px; }

        .emp-notes {
            font-size: 0.82rem;
            color: #718096;
            background: #f8faff;
            border-radius: 8px;
            padding: 0.5rem 0.75rem;
            margin-top: 0.75rem;
            border-left: 3px solid #3b66f5;
        }

        .btn-delete {
            position: absolute;
            top: 1rem;
            right: 1rem;
            background: none;
            border: none;
            color: #fc8181;
            cursor: pointer;
            font-size: 0.85rem;
            padding: 4px 8px;
            border-radius: 6px;
            transition: background 0.2s;
        }
        .btn-delete:hover { background: #fff5f5; }

 
        .empty-placeholder {
            text-align: center;
            padding: 3rem 1rem;
            color: #a0aec0;
        }
        .empty-placeholder i { font-size: 3.5rem; margin-bottom: 1rem; display: block; opacity: 0.4; }
        .empty-placeholder h2 { font-size: 1.1rem; font-weight: 600; margin-bottom: 0.4rem; color: #718096; }
        .empty-placeholder p { font-size: 0.9rem; }

 
        .stats-bar {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            flex-wrap: wrap;
        }
        .stat-item {
            background: white;
            border-radius: 12px;
            padding: 1rem 1.5rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            flex: 1;
            min-width: 140px;
            text-align: center;
        }
        .stat-item .stat-num { font-size: 1.8rem; font-weight: 800; color: #3b66f5; }
        .stat-item .stat-label { font-size: 0.8rem; color: #718096; margin-top: 2px; }

        @media (max-width: 600px) {
            .form-row { grid-template-columns: 1fr; }
            .header-card { flex-direction: column; text-align: center; }
        }
    </style>
</head>
<body>

 
    <nav class="nav-header">
        <div class="nav-header-content">
                     <a href="Home.php" class="nav-brand">  <i class="fas fa-screwdriver-wrench" style="color:#3b66f5; margin-right:8px;"></i>Services <span>Artisans</span></a>

            <div class="nav-links">
                <a href="profile.php"><i class="fas fa-user"></i> Mon Profil</a>
                <a href="profile.php?logout=1"><i class="fas fa-sign-out-alt"></i> Déconnexion</a>
            </div>
        </div>
    </nav>

    <div class="main-wrapper">

        <a href="profile.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Retour au profil
        </a>

        <div class="header-card">
            <i class="fas fa-users"></i>
            <div class="header-info">
                <h1>Gestion des Employés</h1>
                <p>Gérez vos collaborateurs et assignez-les à vos projets</p>
            </div>
        </div>

        <?php if ($success): ?>
            <div class="message success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="message error"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

 
        <div class="stats-bar">
            <div class="stat-item">
                <div class="stat-num"><?php echo count($employees); ?></div>
                <div class="stat-label">Total employés</div>
            </div>
            <div class="stat-item">
                <div class="stat-num">
                    <?php
                        $totalExp = array_sum(array_column($employees, 'YearsOfExperience'));
                        echo count($employees) > 0 ? round($totalExp / count($employees)) : 0;
                    ?>
                </div>
                <div class="stat-label">Moy. années exp.</div>
            </div>
            <div class="stat-item">
                <div class="stat-num">
                    <?php echo count(array_unique(array_filter(array_column($employees, 'Specialty')))); ?>
                </div>
                <div class="stat-label">Spécialités</div>
            </div>
        </div>

 
        <div class="card">
            <div class="card-title"><i class="fas fa-user-plus"></i> Ajouter un nouvel employé</div>
            <form method="POST">
                <input type="hidden" name="action" value="addEmployee">
                <div class="form-row">
                    <div class="form-group">
                        <label>Nom complet *</label>
                        <input type="text" name="fullName" class="form-field" placeholder="Ex: Ahmed Benali" required>
                    </div>
                    <div class="form-group">
                        <label>Téléphone *</label>
                        <input type="tel" name="phone" class="form-field" placeholder="Ex: 0550 123 456" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Email <span style="color:#a0aec0; font-weight:400;">(optionnel)</span></label>
                        <input type="email" name="email" class="form-field" placeholder="Ex: ahmed@email.com">
                    </div>
                    <div class="form-group">
                        <label>Spécialité</label>
                        <select name="specialty" class="form-field">
                            <option value="">Sélectionner</option>
                            <option value="Plombier">Plombier</option>
                            <option value="Menuisier">Menuisier</option>
                            <option value="Électricien">Électricien</option>
                            <option value="Maçon">Maçon</option>
                            <option value="Soudeur">Soudeur</option>
                            <option value="Peintre">Peintre</option>
                            <option value="Autre">Autre</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Années d'expérience</label>
                        <input type="number" name="experience" class="form-field" min="0" value="0">
                    </div>
                    <div class="form-group">
                        <label>Notes / Observations</label>
                        <input type="text" name="notes" class="form-field" placeholder="Informations supplémentaires...">
                    </div>
                </div>
                <button type="submit" class="btn-submit">
                    <i class="fas fa-plus"></i> Ajouter l'employé
                </button>
            </form>
        </div>

 
        <div class="card">
            <div class="card-title">
                <i class="fas fa-list"></i> Mes employés
                <span style="background:#eef2ff; color:#3b66f5; font-size:0.8rem; padding:2px 10px; border-radius:999px; margin-left:auto;">
                    <?php echo count($employees); ?>
                </span>
            </div>

            <?php if (empty($employees)): ?>
                <div class="empty-placeholder">
                    <i class="fas fa-users"></i>
                    <h2>Aucun employé enregistré</h2>
                    <p>Commencez par ajouter votre premier employé ci-dessus</p>
                </div>
            <?php else: ?>
                <div class="grid-container">
                    <?php foreach ($employees as $emp): ?>
                    <div class="emp-card">
 
                        <form method="POST" style="display:inline;" onsubmit="return confirm('Supprimer cet employé ?');">
                            <input type="hidden" name="action" value="deleteEmployee">
                            <input type="hidden" name="employeeID" value="<?php echo $emp['EmployeeID']; ?>">
                            <button type="submit" class="btn-delete" title="Supprimer">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </form>

                        <div class="emp-header">
                            <div class="emp-avatar">
                                <?php echo strtoupper(substr($emp['FullName'], 0, 1)); ?>
                            </div>
                            <div>
                                <div class="emp-name"><?php echo htmlspecialchars($emp['FullName']); ?></div>
                                <?php if (!empty($emp['Specialty'])): ?>
                                    <span class="emp-specialty"><?php echo htmlspecialchars($emp['Specialty']); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="emp-details">
                            <div><i class="fas fa-phone-alt"></i> <?php echo htmlspecialchars($emp['PhoneNumber']); ?></div>
                            <?php if (!empty($emp['Email'])): ?>
                                <div><i class="fas fa-envelope"></i> <?php echo htmlspecialchars($emp['Email']); ?></div>
                            <?php endif; ?>
                            <?php if (!is_null($emp['YearsOfExperience'])): ?>
                                <div><i class="fas fa-briefcase"></i> <?php echo $emp['YearsOfExperience']; ?> ans d'expérience</div>
                            <?php endif; ?>
                        </div>

                        <?php if (!empty($emp['Notes'])): ?>
                            <div class="emp-notes">
                                <i class="fas fa-sticky-note" style="color:#3b66f5; margin-right:4px;"></i>
                                <?php echo htmlspecialchars($emp['Notes']); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

    </div>
</body>
</html>