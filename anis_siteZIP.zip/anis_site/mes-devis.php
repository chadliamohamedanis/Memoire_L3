<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Artisan') {
    header("Location: index1.php"); exit();
}

$host = 'localhost'; $dbname = 'anis'; $dbuser = 'root'; $dbpass = '';
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $dbuser, $dbpass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) { die("DB error: " . $e->getMessage()); }

$userID = $_SESSION['user_id'];

 
$aStmt = $pdo->prepare("SELECT * FROM Artisans WHERE UserID=:uid");
$aStmt->execute(['uid'=>$userID]);
$artisan = $aStmt->fetch(PDO::FETCH_ASSOC);
if (!$artisan) { header("Location: profile.php"); exit(); }
$artisanID = $artisan['ArtisanID'];

 
$uStmt = $pdo->prepare("SELECT FullName, ProfilePictureURL FROM Users WHERE UserID=:uid");
$uStmt->execute(['uid'=>$userID]);
$userData = $uStmt->fetch(PDO::FETCH_ASSOC);

$success = $error = '';

 
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'respondDevis') {
    $devisID  = intval($_POST['devis_id']);
    $status   = in_array($_POST['status'], ['accepted','refused','completed']) ? $_POST['status'] : 'pending';
    $response = trim($_POST['response_text'] ?? '');

    if (empty($response)) {
        $error = "Veuillez écrire un message de réponse.";
    } else {
        $pdo->prepare("UPDATE DevisRequests SET Status=:st, ArtisanResponse=:resp, RespondedAt=NOW() WHERE DevisID=:did AND ArtisanID=:aid")
            ->execute(['st'=>$status,'resp'=>$response,'did'=>$devisID,'aid'=>$artisanID]);
        $success = "Réponse envoyée au client.";
    }
}

 
$filterStatus = $_GET['status'] ?? 'all';
$validStatuses = ['all','pending','accepted','refused','completed'];
if (!in_array($filterStatus, $validStatuses)) $filterStatus = 'all';

$whereClause = "WHERE d.ArtisanID = :aid";
$params = ['aid' => $artisanID];
if ($filterStatus !== 'all') {
    $whereClause .= " AND d.Status = :st";
    $params['st'] = $filterStatus;
}

$devisRequests = $pdo->prepare("
    SELECT d.*, 
           u.FullName AS ClientName, u.ProfilePictureURL AS ClientPhoto,
           s.Title AS ServiceTitle, s.Category AS ServiceCategory
    FROM DevisRequests d
    JOIN Users u ON d.ClientUserID = u.UserID
    JOIN Services s ON d.ServiceID = s.ServiceID
    $whereClause
    ORDER BY d.CreatedAt DESC
");
$devisRequests->execute($params);
$requests = $devisRequests->fetchAll(PDO::FETCH_ASSOC);

 
$statsStmt = $pdo->prepare("SELECT Status, COUNT(*) as cnt FROM DevisRequests WHERE ArtisanID=:aid GROUP BY Status");
$statsStmt->execute(['aid'=>$artisanID]);
$stats = ['pending'=>0,'accepted'=>0,'refused'=>0,'completed'=>0];
foreach ($statsStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $stats[$row['Status']] = $row['cnt'];
}
$totalRequests = array_sum($stats);

$statusConfig = [
    'pending'   => ['label'=>'En attente',  'color'=>'#f59e0b', 'bg'=>'#fffbeb', 'border'=>'#fde68a', 'icon'=>'fas fa-clock'],
    'accepted'  => ['label'=>'Accepté',     'color'=>'#10b981', 'bg'=>'#ecfdf5', 'border'=>'#a7f3d0', 'icon'=>'fas fa-check-circle'],
    'refused'   => ['label'=>'Refusé',      'color'=>'#ef4444', 'bg'=>'#fef2f2', 'border'=>'#fca5a5', 'icon'=>'fas fa-times-circle'],
    'completed' => ['label'=>'Terminé',     'color'=>'#3b66f5', 'bg'=>'#eef2ff', 'border'=>'#c3d0ff', 'icon'=>'fas fa-flag-checkered'],
];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mes Demandes de Devis — Services Artisans</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }
        :root {
            --primary: #1e3a5f; --accent: #3b66f5; --accent2: #f97316;
            --success: #10b981; --danger: #ef4444;
            --bg: #f4f7fe; --white: #fff; --text: #1a202c;
            --muted: #718096; --border: #e2e8f0;
            --radius: 14px; --shadow: 0 4px 24px rgba(0,0,0,0.07);
        }
        body { font-family: 'Cairo', sans-serif; background: var(--bg); color: var(--text); }

 
        .nav { background: var(--white); padding: 0 5%; position: sticky; top: 0; z-index: 100; box-shadow: 0 2px 16px rgba(0,0,0,0.06); }
        .nav-inner { max-width: 1300px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; height: 70px; gap: 1.5rem; }
        .nav-brand { font-size: 1.5rem; font-weight: 900; color: var(--accent); text-decoration: none; white-space: nowrap; }
        .nav-brand span { color: var(--accent2); }
        .nav-links { display: flex; gap: 0.5rem; align-items: center; }
        .nav-links a { color: var(--muted); text-decoration: none; font-weight: 600; font-size: 0.88rem; padding: 0.45rem 0.9rem; border-radius: 999px; transition: all 0.2s; display: flex; align-items: center; gap: 0.4rem; }
        .nav-links a:hover, .nav-links a.active { background: #eef2ff; color: var(--accent); }
        .user-chip { display: flex; align-items: center; gap: 0.5rem; background: var(--bg); border: 1.5px solid var(--border); border-radius: 999px; padding: 0.3rem 1rem 0.3rem 0.3rem; text-decoration: none; color: var(--text); font-weight: 600; font-size: 0.85rem; }
        .user-avatar { width: 30px; height: 30px; border-radius: 50%; background: linear-gradient(135deg,var(--accent),#6c8fff); display: flex; align-items: center; justify-content: center; color: white; font-size: 0.8rem; font-weight: 700; overflow: hidden; flex-shrink: 0; }
        .user-avatar img { width: 100%; height: 100%; object-fit: cover; }

 
        .page-header { background: linear-gradient(135deg, var(--primary), #2d4f7c); padding: 2.5rem 5%; color: white; }
        .page-header-inner { max-width: 1300px; margin: 0 auto; }
        .page-header h1 { font-size: 1.75rem; font-weight: 900; margin-bottom: 0.3rem; display: flex; align-items: center; gap: 0.7rem; }
        .page-header p { opacity: 0.75; font-size: 0.95rem; }

 
        .stats-row { max-width: 1300px; margin: -1.5rem auto 2rem; padding: 0 5%; display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 1rem; position: relative; z-index: 2; }
        .stat-card { background: white; border-radius: var(--radius); padding: 1.25rem 1rem; text-align: center; box-shadow: var(--shadow); border: 1.5px solid var(--border); cursor: pointer; transition: transform 0.2s, box-shadow 0.2s; text-decoration: none; display: block; }
        .stat-card:hover { transform: translateY(-3px); box-shadow: 0 8px 32px rgba(0,0,0,0.1); }
        .stat-card.active { border-color: var(--accent); background: #eef2ff; }
        .stat-icon { font-size: 1.5rem; margin-bottom: 0.5rem; }
        .stat-num { font-size: 2rem; font-weight: 900; line-height: 1; }
        .stat-label { font-size: 0.78rem; color: var(--muted); margin-top: 3px; font-weight: 600; }

 
        .main-content { max-width: 1300px; margin: 0 auto; padding: 0 5% 4rem; }
        .section-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 0.75rem; }
        .section-title { font-size: 1.1rem; font-weight: 800; color: var(--primary); }
        .results-count { font-size: 0.88rem; color: var(--muted); }

 
        .requests-list { display: flex; flex-direction: column; gap: 1.25rem; }
        .request-card {
            background: white; border-radius: 18px; border: 1.5px solid var(--border);
            box-shadow: var(--shadow); overflow: hidden;
            transition: box-shadow 0.2s;
        }
        .request-card:hover { box-shadow: 0 8px 32px rgba(0,0,0,0.1); }
        .request-card.pending   { border-left: 4px solid #f59e0b; }
        .request-card.accepted  { border-left: 4px solid #10b981; }
        .request-card.refused   { border-left: 4px solid #ef4444; }
        .request-card.completed { border-left: 4px solid #3b66f5; }

        .card-top { display: flex; align-items: center; gap: 1rem; padding: 1.25rem 1.5rem; flex-wrap: wrap; }
        .client-avatar { width: 48px; height: 48px; border-radius: 50%; background: linear-gradient(135deg,var(--accent),#6c8fff); display: flex; align-items: center; justify-content: center; color: white; font-weight: 700; font-size: 1.1rem; overflow: hidden; flex-shrink: 0; }
        .client-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .client-info { flex: 1; min-width: 0; }
        .client-name { font-weight: 700; font-size: 1rem; color: var(--text); }
        .client-meta { font-size: 0.8rem; color: var(--muted); margin-top: 2px; display: flex; align-items: center; gap: 0.75rem; flex-wrap: wrap; }
        .client-meta i { color: var(--accent); }
        .status-badge { display: inline-flex; align-items: center; gap: 0.35rem; padding: 0.3rem 0.9rem; border-radius: 999px; font-size: 0.78rem; font-weight: 700; white-space: nowrap; }

        .card-body { padding: 0 1.5rem 1.25rem; }
        .detail-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 0.75rem; margin-bottom: 1rem; }
        .detail-item { background: var(--bg); border-radius: 10px; padding: 0.75rem 1rem; }
        .detail-label { font-size: 0.72rem; font-weight: 700; color: var(--muted); text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 3px; }
        .detail-value { font-size: 0.9rem; font-weight: 600; color: var(--text); }
        .desc-box { background: var(--bg); border-radius: 10px; padding: 0.85rem 1rem; margin-bottom: 1rem; }
        .desc-box .detail-label { margin-bottom: 5px; }
        .desc-box p { font-size: 0.9rem; color: #4a5568; line-height: 1.7; }

 
        .response-given { background: #ecfdf5; border: 1.5px solid #a7f3d0; border-radius: 12px; padding: 1rem 1.25rem; margin-bottom: 1rem; }
        .response-given .resp-label { font-size: 0.78rem; font-weight: 700; color: #065f46; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 4px; display: flex; align-items: center; gap: 0.4rem; }
        .response-given p { font-size: 0.9rem; color: #065f46; }
        .response-refused { background: #fef2f2; border-color: #fca5a5; }
        .response-refused .resp-label, .response-refused p { color: #991b1b; }

 
        .respond-form { background: #f8faff; border-radius: 12px; border: 1.5px dashed #c3d0ff; padding: 1.25rem; }
        .respond-form label { font-size: 0.83rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 0.5rem; }
        .respond-form textarea { width: 100%; padding: 0.75rem 1rem; border: 1.5px solid var(--border); border-radius: 10px; font-family: 'Cairo',sans-serif; font-size: 0.9rem; color: var(--text); background: white; outline: none; resize: vertical; transition: border-color 0.2s; }
        .respond-form textarea:focus { border-color: var(--accent); }
        .respond-actions { display: flex; gap: 0.6rem; margin-top: 0.75rem; flex-wrap: wrap; }
        .btn-accept  { background: linear-gradient(135deg,#10b981,#34d399); color: white; border: none; padding: 0.6rem 1.25rem; border-radius: 8px; font-family: 'Cairo',sans-serif; font-size: 0.88rem; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 0.4rem; transition: opacity 0.2s; }
        .btn-accept:hover { opacity: 0.9; }
        .btn-refuse  { background: linear-gradient(135deg,#f56565,#fc8181); color: white; border: none; padding: 0.6rem 1.25rem; border-radius: 8px; font-family: 'Cairo',sans-serif; font-size: 0.88rem; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 0.4rem; transition: opacity 0.2s; }
        .btn-refuse:hover { opacity: 0.9; }
        .btn-complete { background: linear-gradient(135deg,var(--accent),#6c8fff); color: white; border: none; padding: 0.6rem 1.25rem; border-radius: 8px; font-family: 'Cairo',sans-serif; font-size: 0.88rem; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 0.4rem; transition: opacity 0.2s; }
        .btn-complete:hover { opacity: 0.9; }

 
        .service-tag { display: inline-flex; align-items: center; gap: 0.35rem; background: #eef2ff; color: var(--accent); font-size: 0.75rem; font-weight: 700; padding: 0.2rem 0.75rem; border-radius: 999px; }

 
        .empty-state { text-align: center; padding: 5rem 2rem; }
        .empty-state i { font-size: 4rem; color: #c3d0ff; display: block; margin-bottom: 1.25rem; }
        .empty-state h3 { font-size: 1.2rem; font-weight: 700; color: var(--primary); margin-bottom: 0.5rem; }
        .empty-state p { color: var(--muted); font-size: 0.9rem; }

 
        .msg { padding: 1rem 1.25rem; border-radius: 12px; display: flex; align-items: center; gap: 0.75rem; font-weight: 500; margin-bottom: 1.5rem; }
        .msg.success { background: #d1fae5; color: #065f46; }
        .msg.error   { background: #fee2e2; color: #991b1b; }

        @media (max-width: 768px) {
            .card-top { gap: 0.75rem; }
            .detail-grid { grid-template-columns: 1fr; }
            .respond-actions { flex-direction: column; }
        }
    </style>
</head>
<body>

 
<nav class="nav">
    <div class="nav-inner">
                 <a href="Home.php" class="nav-brand">  <i class="fas fa-screwdriver-wrench" style="color:#3b66f5; margin-right:8px;"></i>Services <span>Artisans</span></a>

        <div class="nav-links">
            <a href="Home.php"><i class="fas fa-home"></i> Accueil</a>
            <a href="services.php"><i class="fas fa-briefcase"></i> Mes services</a>
            <a href="mes-devis.php" class="active"><i class="fas fa-inbox"></i> Devis</a>
            <a href="profile.php" class="user-chip">
                <div class="user-avatar">
                    <?php if (!empty($userData['ProfilePictureURL'])): ?>
                        <img src="data:image/jpeg;base64,<?php echo $userData['ProfilePictureURL']; ?>" alt="">
                    <?php else: ?>
                        <?php echo strtoupper(substr($userData['FullName']??'A',0,1)); ?>
                    <?php endif; ?>
                </div>
                <?php echo htmlspecialchars($userData['FullName'] ?? 'Artisan'); ?>
            </a>
        </div>
    </div>
</nav>

 
<div class="page-header">
    <div class="page-header-inner">
        <h1><i class="fas fa-inbox"></i> Demandes de devis</h1>
        <p>Gérez les demandes envoyées par vos clients</p>
    </div>
</div>

 
<div class="stats-row">
    <a href="?status=all" class="stat-card <?php echo $filterStatus==='all'?'active':''; ?>">
        <div class="stat-icon" style="color:var(--accent);">📋</div>
        <div class="stat-num" style="color:var(--accent);"><?php echo $totalRequests; ?></div>
        <div class="stat-label">Total</div>
    </a>
    <?php foreach ($statusConfig as $sk => $sc): ?>
    <a href="?status=<?php echo $sk; ?>" class="stat-card <?php echo $filterStatus===$sk?'active':''; ?>">
        <div class="stat-icon"><i class="<?php echo $sc['icon']; ?>" style="color:<?php echo $sc['color']; ?>;"></i></div>
        <div class="stat-num" style="color:<?php echo $sc['color']; ?>;"><?php echo $stats[$sk]; ?></div>
        <div class="stat-label"><?php echo $sc['label']; ?></div>
    </a>
    <?php endforeach; ?>
</div>

 
<div class="main-content">

    <?php if ($success): ?>
        <div class="msg success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="msg error"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <div class="section-bar">
        <div class="section-title">
            <?php echo $filterStatus==='all' ? 'Toutes les demandes' : ('Demandes : '.$statusConfig[$filterStatus]['label']); ?>
        </div>
        <div class="results-count"><?php echo count($requests); ?> demande<?php echo count($requests)!==1?'s':''; ?></div>
    </div>

    <?php if (empty($requests)): ?>
    <div class="empty-state">
        <i class="fas fa-inbox"></i>
        <h3>Aucune demande<?php echo $filterStatus!=='all'?' '.$statusConfig[$filterStatus]['label']:''; ?></h3>
        <p>Les demandes de devis envoyées par vos clients apparaîtront ici.</p>
    </div>
    <?php else: ?>
    <div class="requests-list">
        <?php foreach ($requests as $req): ?>
        <?php $sc = $statusConfig[$req['Status']]; ?>
        <div class="request-card <?php echo $req['Status']; ?>">

            <div class="card-top">
 
                <div class="client-avatar">
                    <?php if (!empty($req['ClientPhoto'])): ?>
                        <img src="data:image/jpeg;base64,<?php echo $req['ClientPhoto']; ?>" alt="">
                    <?php else: ?>
                        <?php echo strtoupper(substr($req['ClientName'],0,1)); ?>
                    <?php endif; ?>
                </div>

                <div class="client-info">
                    <div class="client-name"><?php echo htmlspecialchars($req['ClientName']); ?></div>
                    <div class="client-meta">
                        <span><i class="fas fa-calendar-alt"></i> Reçue le <?php echo date('d/m/Y à H:i', strtotime($req['CreatedAt'])); ?></span>
                        <span><i class="fas fa-briefcase"></i>
                            <span class="service-tag"><?php echo htmlspecialchars($req['ServiceTitle']); ?></span>
                        </span>
                    </div>
                </div>

                <span class="status-badge"
                    style="background:<?php echo $sc['bg']; ?>;color:<?php echo $sc['color']; ?>;border:1px solid <?php echo $sc['border']; ?>;">
                    <i class="<?php echo $sc['icon']; ?>"></i> <?php echo $sc['label']; ?>
                </span>
            </div>

            <div class="card-body">
 
                <div class="detail-grid">
                    <div class="detail-item">
                        <div class="detail-label"><i class="fas fa-map-marker-alt" style="color:#f97316;"></i> Wilaya</div>
                        <div class="detail-value"><?php echo htmlspecialchars($req['Wilaya']); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label"><i class="fas fa-calendar" style="color:#3b66f5;"></i> Date souhaitée</div>
                        <div class="detail-value"><?php echo date('d/m/Y', strtotime($req['PreferredDate'])); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label"><i class="fas fa-phone" style="color:#10b981;"></i> Téléphone</div>
                        <div class="detail-value">
                            <a href="tel:<?php echo htmlspecialchars($req['PhoneNumber']); ?>" style="color:var(--accent);text-decoration:none;font-weight:700;">
                                <?php echo htmlspecialchars($req['PhoneNumber']); ?>
                            </a>
                        </div>
                    </div>
                </div>

 
                <div class="desc-box">
                    <div class="detail-label"><i class="fas fa-align-left"></i> Description du travail</div>
                    <p><?php echo nl2br(htmlspecialchars($req['Description'])); ?></p>
                </div>

 
                <?php if ($req['ArtisanResponse']): ?>
                <div class="response-given <?php echo $req['Status']==='refused'?'response-refused':''; ?>">
                    <div class="resp-label">
                        <i class="fas fa-reply"></i>
                        Votre réponse (<?php echo date('d/m/Y', strtotime($req['RespondedAt'])); ?>)
                    </div>
                    <p><?php echo nl2br(htmlspecialchars($req['ArtisanResponse'])); ?></p>
                </div>
                <?php endif; ?>

 
                <?php if ($req['Status'] === 'pending' || $req['Status'] === 'accepted'): ?>
                <div class="respond-form">
                    <form method="POST">
                        <input type="hidden" name="action" value="respondDevis">
                        <input type="hidden" name="devis_id" value="<?php echo $req['DevisID']; ?>">
                        <label>
                            <?php if ($req['Status']==='pending'): ?>
                                <i class="fas fa-pen"></i> Votre réponse au client *
                            <?php else: ?>
                                <i class="fas fa-pen"></i> Mettre à jour ou marquer comme terminé
                            <?php endif; ?>
                        </label>
                        <textarea name="response_text" rows="3" placeholder="Écrivez votre message au client..."><?php echo htmlspecialchars($req['ArtisanResponse'] ?? ''); ?></textarea>
                        <div class="respond-actions">
                            <?php if ($req['Status']==='pending'): ?>
                            <button type="submit" name="status" value="accepted" class="btn-accept">
                                <i class="fas fa-check"></i> Accepter
                            </button>
                            <button type="submit" name="status" value="refused" class="btn-refuse"
                                onclick="return confirm('Refuser cette demande ?')">
                                <i class="fas fa-times"></i> Refuser
                            </button>
                            <?php endif; ?>
                            <?php if ($req['Status']==='accepted'): ?>
                            <button type="submit" name="status" value="completed" class="btn-complete">
                                <i class="fas fa-flag-checkered"></i> Marquer comme terminé
                            </button>
                            <button type="submit" name="status" value="refused" class="btn-refuse"
                                onclick="return confirm('Annuler cette demande acceptée ?')">
                                <i class="fas fa-ban"></i> Annuler
                            </button>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

</body>
</html>