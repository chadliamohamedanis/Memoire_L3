<?php
session_start();

$host        = 'localhost';
$dbname      = 'anis';
$db_username = 'root';
$db_password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $db_username, $db_password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    $pdo = null;
}

$isLoggedIn = isset($_SESSION['user_id']);
$userRole   = $_SESSION['role'] ?? null;
$userName   = $_SESSION['username'] ?? null;

$userPhoto    = null;
$userFullName = $userName;
if ($isLoggedIn && $pdo) {
    $stmt = $pdo->prepare("SELECT ProfilePictureURL, FullName FROM Users WHERE UserID = :uid");
    $stmt->execute(['uid' => $_SESSION['user_id']]);
    $userData     = $stmt->fetch(PDO::FETCH_ASSOC);
    $userPhoto    = $userData['ProfilePictureURL'] ?? null;
    $userFullName = $userData['FullName'] ?? $userName;
}

 
$popularServices = [];
if ($pdo) {
    $stmt = $pdo->query("
        SELECT s.ServiceID, s.Title, s.Description, s.Price, s.Rating, s.ImageURL, s.Category,
               u.FullName AS ArtisanName,
               a.State AS ArtisanState
        FROM Services s
        JOIN Artisans a ON s.ArtisanID = a.ArtisanID
        JOIN Users u ON a.UserID = u.UserID
        ORDER BY s.Rating DESC, s.ServiceID DESC
        LIMIT 8
    ");
    $popularServices = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

 
$categoryCounts = [];
if ($pdo) {
    $stmt = $pdo->query("SELECT Category, COUNT(*) as cnt FROM Services WHERE Category IS NOT NULL GROUP BY Category");
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $categoryCounts[$row['Category']] = $row['cnt'];
    }
}

 
$totalArtisans = $totalServices = $totalReviews = 0;
if ($pdo) {
    $totalArtisans = $pdo->query("SELECT COUNT(*) FROM Artisans")->fetchColumn();
    $totalServices = $pdo->query("SELECT COUNT(*) FROM Services")->fetchColumn();
    $totalReviews  = $pdo->query("SELECT COUNT(*) FROM ServiceReviews")->fetchColumn();
}

$catMeta = [
    'Électricité'   => ['icon' => 'fas fa-bolt',        'color' => '#f59e0b', 'img' => 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?q=80&w=400'],
    'Plomberie'     => ['icon' => 'fas fa-faucet',       'color' => '#3b82f6', 'img' => 'https://cge-news.com/wp-content/uploads/2023/09/Plomberie-5-astuces-de-plombier-a-connaitre.jpg'],
    'Peinture'      => ['icon' => 'fas fa-paint-roller', 'color' => '#ec4899', 'img' => 'https://images.unsplash.com/photo-1589939705384-5185137a7f0f?q=80&w=400'],
    'Maçonnerie'    => ['icon' => 'fas fa-hard-hat',     'color' => '#8b5cf6', 'img' => 'https://www.constructionlabrique.com/wp-content/uploads/2021/02/tout-savoir-sur-la-maconnerie.jpeg'],
    'Menuiserie'    => ['icon' => 'fas fa-hammer',       'color' => '#10b981', 'img' => 'https://images.unsplash.com/photo-1611269154421-4e27233ac5c7?q=80&w=400'],
    'Climatisation' => ['icon' => 'fas fa-snowflake',    'color' => '#06b6d4', 'img' => 'https://cdn.manomano.com/media/edison/4/f/d/4/4fd4c5925ace.jpg'],
    'Soudure'       => ['icon' => 'fas fa-fire',         'color' => '#f97316', 'img' => 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?q=80&w=400'],
    'Autre'         => ['icon' => 'fas fa-tools',        'color' => '#6b7280', 'img' => 'https://images.unsplash.com/photo-1581578731548-c64695cc6952?q=80&w=400'],
];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services Artisans - Trouvez le meilleur artisan</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }

        :root {
            --primary:   #1e3a5f;
            --accent:    #3b66f5;
            --accent2:   #f97316;
            --success:   #10b981;
            --bg:        #f4f7fe;
            --white:     #ffffff;
            --text:      #1a202c;
            --muted:     #718096;
            --border:    #e2e8f0;
            --radius:    16px;
            --shadow:    0 4px 24px rgba(0,0,0,0.07);
            --shadow-lg: 0 12px 40px rgba(0,0,0,0.12);
        }

        body { font-family: 'Cairo', sans-serif; background: var(--bg); color: var(--text); line-height: 1.6; }

 
        .nav { background: var(--white); padding: 0 5%; position: sticky; top: 0; z-index: 100; box-shadow: 0 2px 16px rgba(0,0,0,0.06); }
        .nav-inner { max-width: 1300px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; height: 70px; gap: 2rem; }
        .nav-brand { font-size: 1.5rem; font-weight: 900; color: var(--accent); text-decoration: none; letter-spacing: -0.5px; white-space: nowrap; }
        .nav-brand span { color: var(--accent2); }

        .nav-search { flex: 1; max-width: 420px; position: relative; }
        .nav-search input { width: 100%; padding: 0.6rem 1rem 0.6rem 2.75rem; border: 1.5px solid var(--muted); border-radius: 999px; font-family: 'Cairo', sans-serif; font-size: 0.9rem; outline: none; background: var(--bg); transition: border-color 0.2s; }
        .nav-search input:focus { border-color: var(--accent); background: white; }
        .nav-search i { position: absolute; left: 1rem; top: 50%; transform: translateY(-50%); color: var(--muted); font-size: 0.85rem; }

        .nav-actions { display: flex; gap: 0.75rem; align-items: center; }
        .btn { display: inline-flex; align-items: center; gap: 0.5rem; padding: 0.55rem 1.2rem; border-radius: 999px; font-family: 'Cairo', sans-serif; font-size: 0.9rem; font-weight: 600; cursor: pointer; text-decoration: none; border: none; transition: all 0.2s; }
        .btn-outline { border: 2px solid var(--accent); color: var(--accent); background: transparent; }
        .btn-outline:hover { background: var(--accent); color: white; }
        .btn-filled { background: linear-gradient(135deg, var(--accent), #6c8fff); color: white; }
        .btn-filled:hover { opacity: 0.9; transform: translateY(-1px); box-shadow: 0 4px 14px rgba(59,102,245,0.35); }

        .user-chip { display: flex; align-items: center; gap: 0.6rem; background: var(--bg); border: 1.5px solid var(--border); border-radius: 999px; padding: 0.35rem 1rem 0.35rem 0.35rem; text-decoration: none; color: var(--text); font-weight: 600; font-size: 0.88rem; transition: border-color 0.2s; }
        .user-chip:hover { border-color: var(--accent); }
        .user-avatar { width: 34px; height: 34px; border-radius: 50%; object-fit: cover; background: linear-gradient(135deg, var(--accent), #6c8fff); display: flex; align-items: center; justify-content: center; color: white; font-weight: 700; font-size: 0.9rem; overflow: hidden; flex-shrink: 0; }
        .user-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .btn-logout { color: var(--muted); font-size: 0.85rem; font-weight: 600; background: none; border: none; cursor: pointer; font-family: 'Cairo', sans-serif; padding: 0.4rem 0.75rem; border-radius: 8px; transition: color 0.2s, background 0.2s; }
        .btn-logout:hover { color: #e53e3e; background: #fff5f5; }

.hero {
    background: none;
    padding: 90px 5% 80px;
    text-align: center;
    color: white;
    position: relative;
    overflow: hidden;
}

.hero::after {
    content: '';
    position: absolute;
    inset: 0;
    background: url('https://bauspezi-burgdorf.de/wp-content/uploads/sites/7/2018/09/sanitaer-burgdorf-1450x430.jpg') center/cover no-repeat;
    filter: blur(6px);
    transform: scale(1.05);
    z-index: 0;
}


.hero::before {
    content: '';
    position: absolute;
    inset: 0;
    background: rgba(10, 20, 45, 0.72); 
    z-index: 1;
}

.hero-content {
    position: relative;
    z-index: 2;
}

.hero-content {
    position: relative;
    z-index: 1;
    max-width: 780px;
    margin: 0 auto;
    background: rgba(255, 255, 255, 0.08);
    backdrop-filter: blur(18px) saturate(160%);
    -webkit-backdrop-filter: blur(18px) saturate(160%);
    border: 1px solid rgba(255, 255, 255, 0.18);
    border-radius: 28px;
    padding: 3rem 3.5rem;
    box-shadow:
        0 8px 32px rgba(0, 0, 0, 0.3),
        inset 0 1px 0 rgba(255, 255, 255, 0.2);
}

.hero-search {
    max-width: 620px;
    margin: 0 auto 2rem;
    background: rgba(255, 255, 255, 0.95);
    border-radius: 999px;
    display: flex;
    padding: 6px;
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.25);
    border: 1px solid rgba(255, 255, 255, 0.4);
}

.hero-tag {
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.25);
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    color: white;
    padding: 0.45rem 1.1rem;
    border-radius: 999px;
    font-size: 0.88rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s;
}
.hero-tag:hover {
    background: rgba(255, 255, 255, 0.9);
    color: var(--accent);
    transform: translateY(-2px);
}

.hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    background: rgba(255, 255, 255, 0.12);
    border: 1px solid rgba(255, 255, 255, 0.25);
    backdrop-filter: blur(10px);
    padding: 0.4rem 1.2rem;
    border-radius: 999px;
    font-size: 0.85rem;
    font-weight: 600;
    margin-bottom: 1.5rem;
    color: rgba(255, 255, 255, 0.95);
}
        .hero-badge { display: inline-flex; align-items: center; gap: 0.5rem; background: rgba(255,255,255,0.12); border: 1px solid rgba(255,255,255,0.25); backdrop-filter: blur(10px); padding: 0.4rem 1.2rem; border-radius: 999px; font-size: 0.85rem; font-weight: 600; margin-bottom: 1.5rem; color: rgba(255,255,255,0.9); }
        .hero h1 { font-size: clamp(2rem, 5vw, 3.5rem); font-weight: 900; line-height: 1.15; margin-bottom: 1rem; }
        .hero h1 span { color: #fbbf24; }
        .hero p { font-size: 1.1rem; opacity: 0.85; max-width: 520px; margin: 0 auto 2.5rem; }

        .hero-search { max-width: 620px; margin: 0 auto 2rem; background: white; border-radius: 999px; display: flex; padding: 6px; box-shadow: 0 20px 50px rgba(0,0,0,0.2); }
        .hero-search input { flex: 1; border: none; padding: 0.85rem 1.5rem; border-radius: 999px; font-family: 'Cairo', sans-serif; font-size: 1rem; color: var(--text); outline: none; }
        .hero-search-btn { background: linear-gradient(135deg, var(--success), #059669); color: white; border: none; padding: 0.85rem 2rem; border-radius: 999px; font-family: 'Cairo', sans-serif; font-size: 0.95rem; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 0.5rem; transition: opacity 0.2s, transform 0.1s; white-space: nowrap; }
        .hero-search-btn:hover { opacity: 0.92; transform: scale(1.02); }

        .hero-tags { display: flex; justify-content: center; flex-wrap: wrap; gap: 0.6rem; }
        .hero-tag { background: rgba(255,255,255,0.12); border: 1px solid rgba(255,255,255,0.2); backdrop-filter: blur(8px); color: white; padding: 0.45rem 1.1rem; border-radius: 999px; font-size: 0.88rem; font-weight: 600; cursor: pointer; transition: all 0.2s; }
        .hero-tag:hover { background: white; color: var(--accent); transform: translateY(-2px); }

 
        .stats-bar { background: var(--white); border-bottom: 1px solid var(--border); }
        .stats-inner { max-width: 1300px; margin: 0 auto; padding: 1.5rem 5%; display: flex; justify-content: center; gap: 3rem; flex-wrap: wrap; }
        .stat { text-align: center; }
        .stat-num { font-size: 1.8rem; font-weight: 900; color: var(--accent); line-height: 1; }
        .stat-label { font-size: 0.8rem; color: var(--muted); margin-top: 2px; }

 
        .section { max-width: 1300px; margin: 0 auto; padding: 3rem 5% 1rem; }
        .section-head { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 1.75rem; }
        .section-title { font-size: 1.5rem; font-weight: 800; color: var(--primary); }
        .section-title span { display: block; width: 36px; height: 4px; background: var(--accent2); border-radius: 2px; margin-top: 5px; }
        .see-all { color: var(--accent); font-size: 0.9rem; font-weight: 600; text-decoration: none; display: flex; align-items: center; gap: 0.3rem; transition: gap 0.2s; }
        .see-all:hover { gap: 0.6rem; }

 
        .cats-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap: 1rem; }
        .cat-card { background: white; border-radius: var(--radius); overflow: hidden; border: 1.5px solid var(--border); cursor: pointer; transition: transform 0.2s, box-shadow 0.2s, border-color 0.2s; text-decoration: none; }
        .cat-card:hover { transform: translateY(-5px); box-shadow: var(--shadow-lg); border-color: var(--accent); }
        .cat-img { width: 100%; height: 110px; object-fit: cover; display: block; }
        .cat-body { padding: 0.75rem; text-align: center; }
        .cat-icon { font-size: 1.3rem; margin-bottom: 0.3rem; }
        .cat-name { font-size: 0.85rem; font-weight: 700; color: var(--text); }
        .cat-count { font-size: 0.75rem; color: var(--muted); margin-top: 2px; }

 
        .filter-bar {
            display: flex;
            gap: 1rem;
            align-items: flex-end;
            flex-wrap: wrap;
            background: white;
            border-radius: 16px;
            padding: 1.25rem 1.5rem;
            box-shadow: 0 2px 12px rgba(0,0,0,0.06);
            margin-bottom: 2rem;
            border: 1.5px solid var(--border);
        }
        .filter-group { display: flex; flex-direction: column; gap: 0.4rem; min-width: 200px; flex: 1; }
        .filter-group label { font-size: 0.82rem; font-weight: 700; color: #4a5568; display: flex; align-items: center; gap: 0.4rem; }
        .filter-group label i { color: var(--accent); }
        .filter-group select {
            padding: 0.65rem 1rem;
            border: 1.5px solid var(--border);
            border-radius: 10px;
            font-family: 'Cairo', sans-serif;
            font-size: 0.9rem;
            color: var(--text);
            background: #f8faff;
            outline: none;
            cursor: pointer;
            transition: border-color 0.2s;
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23718096' d='M6 8L1 3h10z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 1rem center;
            padding-right: 2.5rem;
        }
        .filter-group select:focus { border-color: var(--accent); background-color: white; }
        .filter-reset {
            padding: 0.65rem 1.4rem;
            border: 1.5px solid var(--border);
            border-radius: 10px;
            background: white;
            color: var(--muted);
            font-family: 'Cairo', sans-serif;
            font-size: 0.9rem;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.4rem;
            transition: all 0.2s;
            align-self: flex-end;
            white-space: nowrap;
        }
        .filter-reset:hover { border-color: #f56565; color: #f56565; background: #fff5f5; }

 
        .filter-active-badge {
            display: none;
            background: var(--accent);
            color: white;
            font-size: 0.75rem;
            font-weight: 700;
            padding: 0.2rem 0.7rem;
            border-radius: 999px;
            margin-left: auto;
            align-self: center;
        }

 
        .services-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 1.5rem; padding-bottom: 3rem; }

        .svc-card { background: white; border-radius: 20px; overflow: hidden; border: 1.5px solid var(--border); transition: transform 0.2s, box-shadow 0.2s; cursor: pointer; text-decoration: none; color: inherit; display: block; }
        .svc-card:hover { transform: translateY(-5px); box-shadow: var(--shadow-lg); }
        .svc-img { width: 100%; height: 175px; object-fit: cover; display: block; }
        .svc-img-placeholder { width: 100%; height: 175px; background: linear-gradient(135deg, #eef2ff, #e0e7ff); display: flex; align-items: center; justify-content: center; font-size: 3rem; color: #a5b4fc; }
        .svc-body { padding: 1.1rem; }
        .svc-cat { display: inline-block; font-size: 0.72rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; background: #eef2ff; color: var(--accent); padding: 0.2rem 0.65rem; border-radius: 999px; margin-bottom: 0.5rem; }
        .svc-title { font-size: 0.98rem; font-weight: 700; color: var(--text); margin-bottom: 0.3rem; line-height: 1.3; }
        .svc-artisan { font-size: 0.8rem; color: var(--muted); margin-bottom: 0.4rem; display: flex; align-items: center; gap: 0.3rem; }
        .svc-wilaya { font-size: 0.8rem; color: var(--muted); margin-bottom: 0.75rem; display: flex; align-items: center; gap: 0.3rem; }
        .svc-wilaya i { color: #f97316; }
        .svc-footer { display: flex; justify-content: space-between; align-items: center; padding-top: 0.75rem; border-top: 1px solid var(--border); }
        .svc-price { font-size: 1rem; font-weight: 800; color: var(--accent); }
        .svc-price small { font-size: 0.72rem; font-weight: 500; color: var(--muted); }
        .svc-rating { display: flex; align-items: center; gap: 3px; font-size: 0.82rem; font-weight: 700; color: #f59e0b; }

 
        .no-results-msg { text-align: center; padding: 3rem; color: #a0aec0; display: none; }
        .no-results-msg i { font-size: 2.5rem; display: block; margin-bottom: 0.75rem; opacity: 0.4; }

 
        .empty-state { text-align: center; padding: 4rem 1rem; color: var(--muted); }
        .empty-state i { font-size: 3rem; opacity: 0.3; margin-bottom: 1rem; display: block; }

 
        .how-section { background: linear-gradient(135deg, var(--primary), #2d4f7c); color: white; padding: 5rem 5%; margin-top: 2rem; }
        .how-inner { max-width: 1300px; margin: 0 auto; }
        .how-title { font-size: 1.8rem; font-weight: 800; margin-bottom: 0.5rem; text-align: center; }
        .how-sub { text-align: center; opacity: 0.75; margin-bottom: 3rem; }
        .how-steps { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 2rem; }
        .how-step { text-align: center; }
        .how-step-num { width: 56px; height: 56px; border-radius: 50%; background: rgba(255,255,255,0.15); border: 2px solid rgba(255,255,255,0.3); display: flex; align-items: center; justify-content: center; font-size: 1.4rem; font-weight: 900; margin: 0 auto 1rem; }
        .how-step h3 { font-size: 1rem; font-weight: 700; margin-bottom: 0.4rem; }
        .how-step p { font-size: 0.85rem; opacity: 0.75; line-height: 1.6; }

 
        footer { background: var(--primary); color: rgba(255,255,255,0.7); text-align: center; padding: 2rem 5%; font-size: 0.85rem; }
        footer a { color: rgba(255,255,255,0.9); text-decoration: none; margin: 0 0.75rem; }
        footer a:hover { color: white; }

        @media (max-width: 768px) {
            .nav-search { display: none; }
            .hero h1 { font-size: 2rem; }
            .stats-inner { gap: 1.5rem; }
            .hero-search-btn span { display: none; }
            .how-steps { grid-template-columns: 1fr 1fr; }
            .filter-group { min-width: 140px; }
        }
        @media (max-width: 480px) {
            .nav-actions .btn-outline { display: none; }
            .how-steps { grid-template-columns: 1fr; }
            .filter-bar { flex-direction: column; }
            .filter-group { min-width: 100%; }
        }
    </style>
</head>
<body>

 
<nav class="nav">
    <div class="nav-inner">
        <a href="Home.php" class="nav-brand">  <i class="fas fa-screwdriver-wrench" style="color:#3b66f5; margin-right:8px;"></i>Services <span>Artisans</span></a>

      

        <div class="nav-actions">
            <?php if ($isLoggedIn): ?>
                <a href="profile.php" class="user-chip">
                    <div class="user-avatar">
                        <?php if ($userPhoto): ?>
                            <img src="data:image/jpeg;base64,<?php echo $userPhoto; ?>" alt="">
                        <?php else: ?>
                            <?php echo strtoupper(substr($userFullName ?? $userName, 0, 1)); ?>
                        <?php endif; ?>
                    </div>
                    <?php echo htmlspecialchars($userFullName ?? $userName); ?>
                </a>
                <?php if ($userRole === 'Artisan'): ?>
                    <a href="services.php" class="btn btn-outline">
                        <i class="fas fa-briefcase"></i> <span>Mes services</span>
                    </a>
                <?php endif; ?>
                <form method="GET" action="profile.php" style="display:inline;">
                    <input type="hidden" name="logout" value="1">
                    <button type="submit" class="btn-logout"><i class="fas fa-sign-out-alt"></i> Déconnexion</button>
                </form>
            <?php else: ?>
                <a href="index1.php" class="btn btn-outline"><i class="fas fa-sign-in-alt"></i> Connexion</a>
                <a href="register.php" class="btn btn-filled"><i class="fas fa-user-plus"></i> S'inscrire</a>
            <?php endif; ?>
        </div>
    </div>
</nav>

 
<section class="hero">
    <div class="hero-content">
        <div class="hero-badge"><i class="fas fa-shield-alt"></i> Artisans vérifiés &amp; notés par la communauté</div>
        <h1>Trouvez le meilleur<br><span>artisan près de chez vous</span></h1>
        <p>Des milliers d'artisans qualifiés à portée de clic. Comparez, contactez, commandez.</p>

        <div class="hero-search">
            <input type="text" id="heroSearch" placeholder="Service (ex: Peinture, Plomberie, Électricité...)" onkeydown="if(event.key==='Enter') doSearch(this.value)">
            <button class="hero-search-btn" onclick="doSearch(document.getElementById('heroSearch').value)">
                <i class="fas fa-search"></i> <span>Rechercher</span>
            </button>
        </div>

        <div class="hero-tags">
            <div class="hero-tag" onclick="goCategory('Plomberie')">🔧 Plombier</div>
            <div class="hero-tag" onclick="goCategory('Peinture')">🖌️ Peintre</div>
            <div class="hero-tag" onclick="goCategory('Électricité')">⚡ Électricien</div>
            <div class="hero-tag" onclick="goCategory('Menuiserie')">🪚 Menuisier</div>
            <div class="hero-tag" onclick="goCategory('Climatisation')">❄️ Climatisation</div>
        </div>
    </div>
</section>
 
<div class="stats-bar">
    <div class="stats-inner">
        <div class="stat">
            <div class="stat-num"><?php echo number_format($totalArtisans); ?>+</div>
            <div class="stat-label">Artisans inscrits</div>
        </div>
        <div class="stat">
            <div class="stat-num"><?php echo number_format($totalServices); ?>+</div>
            <div class="stat-label">Services disponibles</div>
        </div>
        <div class="stat">
            <div class="stat-num"><?php echo number_format($totalReviews); ?>+</div>
            <div class="stat-label">Avis clients</div>
        </div>
        <div class="stat">
            <div class="stat-num">48</div>
            <div class="stat-label">Wilayas couvertes</div>
        </div>
    </div>
</div>

 
<div class="section">
    <div class="section-head">
        <div class="section-title">Catégories <span></span></div>
        <a href="search-results.php" class="see-all">Tout voir <i class="fas fa-arrow-right"></i></a>
    </div>
    <div class="cats-grid">
        <?php foreach ($catMeta as $name => $meta): ?>
        <a href="search-results.php?category=<?php echo urlencode($name); ?>" class="cat-card">
            <img src="<?php echo $meta['img']; ?>" alt="<?php echo htmlspecialchars($name); ?>" class="cat-img" onerror="this.style.display='none'">
            <div class="cat-body">
                <div class="cat-icon" style="color:<?php echo $meta['color']; ?>"><i class="<?php echo $meta['icon']; ?>"></i></div>
                <div class="cat-name"><?php echo htmlspecialchars($name); ?></div>
                <div class="cat-count">
                    <?php $cnt = $categoryCounts[$name] ?? 0; ?>
                    <?php echo $cnt; ?> service<?php echo $cnt !== 1 ? 's' : ''; ?>
                </div>
            </div>
        </a>
        <?php endforeach; ?>
    </div>
</div>

 
<div class="section">
    <div class="section-head">
        <div class="section-title">Services Populaires <span></span></div>
        <a href="search-results.php" class="see-all">Tout voir <i class="fas fa-arrow-right"></i></a>
    </div>

    <?php if (empty($popularServices)): ?>
        <div class="empty-state">
            <i class="fas fa-briefcase"></i>
            <p>Aucun service disponible pour le moment.</p>
        </div>
    <?php else: ?>

 
        <div class="filter-bar">
            <div class="filter-group">
                <label><i class="fas fa-map-marker-alt"></i> Wilaya</label>
                <select id="filterWilaya" onchange="applyFilters()">
                    <option value="">Toutes les wilayas</option>
                </select>
            </div>
            <div class="filter-group">
                <label><i class="fas fa-th-large"></i> Catégorie</label>
                <select id="filterCategory" onchange="applyFilters()">
                    <option value="">Toutes les catégories</option>
                    <?php foreach ($catMeta as $name => $meta): ?>
                        <option value="<?php echo htmlspecialchars($name); ?>"><?php echo htmlspecialchars($name); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button class="filter-reset" onclick="resetFilters()">
                <i class="fas fa-times"></i> Réinitialiser
            </button>
            <span class="filter-active-badge" id="filterBadge">Filtres actifs</span>
        </div>

        <div class="services-grid" id="servicesGrid">
            <?php foreach ($popularServices as $svc): ?>
            <a href="service-detail.php?id=<?php echo $svc['ServiceID']; ?>"
               class="svc-card"
               data-wilaya="<?php echo htmlspecialchars($svc['ArtisanState'] ?? ''); ?>"
               data-category="<?php echo htmlspecialchars($svc['Category'] ?? ''); ?>">

                <?php if (!empty($svc['ImageURL'])): ?>
                    <img src="<?php echo $svc['ImageURL']; ?>" alt="<?php echo htmlspecialchars($svc['Title']); ?>" class="svc-img">
                <?php else: ?>
                    <div class="svc-img-placeholder"><i class="fas fa-briefcase"></i></div>
                <?php endif; ?>

                <div class="svc-body">
                    <?php if (!empty($svc['Category'])): ?>
                        <span class="svc-cat"><?php echo htmlspecialchars($svc['Category']); ?></span>
                    <?php endif; ?>
                    <div class="svc-title"><?php echo htmlspecialchars($svc['Title']); ?></div>
                    <div class="svc-artisan">
                        <i class="fas fa-user-tie"></i>
                        <?php echo htmlspecialchars($svc['ArtisanName']); ?>
                    </div>
                    <?php if (!empty($svc['ArtisanState'])): ?>
                    <div class="svc-wilaya">
                        <i class="fas fa-map-marker-alt"></i>
                        <?php echo htmlspecialchars($svc['ArtisanState']); ?>
                    </div>
                    <?php endif; ?>
                    <div class="svc-footer">
                        <div class="svc-price">
                            <?php if ($svc['Price'] > 0): ?>
                                <?php echo number_format($svc['Price'], 0, ',', ' '); ?> DA <small>/ intervention</small>
                            <?php else: ?>
                                Sur devis
                            <?php endif; ?>
                        </div>
                        <?php if (!empty($svc['Rating'])): ?>
                        <div class="svc-rating">
                            <i class="fas fa-star"></i>
                            <?php echo number_format($svc['Rating'], 1); ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </a>
            <?php endforeach; ?>
        </div>

        <div class="no-results-msg" id="noResults">
            <i class="fas fa-search"></i>
            <p>Aucun service trouvé pour ces filtres.</p>
            <p style="font-size:0.85rem;margin-top:0.4rem;">Essayez une autre wilaya ou catégorie.</p>
        </div>

    <?php endif; ?>
</div>

 
<div class="how-section">
    <div class="how-inner">
        <div class="how-title">Comment ça marche ?</div>
        <div class="how-sub">Trouvez et contactez un artisan en quelques étapes simples</div>
        <div class="how-steps">
            <div class="how-step">
                <div class="how-step-num">1</div>
                <h3>Recherchez</h3>
                <p>Tapez le service dont vous avez besoin ou parcourez les catégories</p>
            </div>
            <div class="how-step">
                <div class="how-step-num">2</div>
                <h3>Comparez</h3>
                <p>Consultez les profils, avis clients et tarifs des artisans</p>
            </div>
            <div class="how-step">
                <div class="how-step-num">3</div>
                <h3>Contactez</h3>
                <p>Appelez directement ou demandez un devis en un clic</p>
            </div>
            <div class="how-step">
                <div class="how-step-num">4</div>
                <h3>Évaluez</h3>
                <p>Partagez votre expérience pour aider la communauté</p>
            </div>
        </div>
    </div>
</div>

 
<footer>
    <div style="margin-bottom:0.75rem;">
        <a href="Home.php">Accueil</a>
        <a href="search-results.php">Services</a>
        <?php if ($isLoggedIn): ?>
            <a href="profile.php">Mon profil</a>
        <?php else: ?>
            <a href="index1.php">Connexion</a>
            <a href="register.php">S'inscrire</a>
        <?php endif; ?>
    </div>
    <div>&copy; <?php echo date('Y'); ?> Services Artisans — Tous droits réservés</div>
</footer>

 
<script src="locations.js"></script>
<script>
 
document.addEventListener('DOMContentLoaded', function () {
    const sel = document.getElementById('filterWilaya');
    if (!sel) return;

    if (typeof getAllStates === 'function') {
        getAllStates().forEach(function (w) {
            const opt = document.createElement('option');
            opt.value = w;
            opt.textContent = w;
            sel.appendChild(opt);
        });
    }
});

 
function applyFilters() {
    const wilaya   = document.getElementById('filterWilaya').value.trim().toLowerCase();
    const category = document.getElementById('filterCategory').value.trim().toLowerCase();
    const cards    = document.querySelectorAll('#servicesGrid .svc-card');
    const badge    = document.getElementById('filterBadge');
    let   visible  = 0;

    cards.forEach(function (card) {
        const cw = (card.dataset.wilaya   || '').trim().toLowerCase();
        const cc = (card.dataset.category || '').trim().toLowerCase();

        const matchW = !wilaya   || cw === wilaya;
        const matchC = !category || cc === category;

        if (matchW && matchC) {
            card.style.display = '';
            visible++;
        } else {
            card.style.display = 'none';
        }
    });

 
    const noRes = document.getElementById('noResults');
    if (noRes) noRes.style.display = visible === 0 ? 'block' : 'none';

     
    if (badge) badge.style.display = (wilaya || category) ? 'inline-block' : 'none';
}

function resetFilters() {
    document.getElementById('filterWilaya').value   = '';
    document.getElementById('filterCategory').value = '';
    applyFilters();
}

 
function doSearch(query) {
    query = query.trim();
    window.location.href = query
        ? 'search-results.php?q=' + encodeURIComponent(query)
        : 'search-results.php';
}

function goCategory(cat) {
    window.location.href = 'search-results.php?category=' + encodeURIComponent(cat);
}

 
document.getElementById('heroSearch').addEventListener('input', function () {
    document.getElementById('navSearch').value = this.value;
});
document.getElementById('navSearch').addEventListener('input', function () {
    document.getElementById('heroSearch').value = this.value;
});
</script>

</body>
</html>