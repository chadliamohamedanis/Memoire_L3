<?php
session_start();

$host = 'localhost';
$dbname = 'anis';
$username = 'root';
$password = '';

ini_set('display_errors', 1);
error_reporting(E_ALL);

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

$serviceID = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$serviceID) { header("Location: Home.php"); exit(); }

$stmt = $pdo->prepare("
    SELECT s.*, a.UserID as ArtisanUserID, a.ArtisanID, u.FullName as ArtisanName, u.PhoneNumber, u.ProfilePictureURL,
           a.State, a.Municipality, a.YearsOfExperience, a.Specialty
    FROM Services s
    JOIN Artisans a ON s.ArtisanID = a.ArtisanID
    JOIN Users u ON a.UserID = u.UserID
    WHERE s.ServiceID = :serviceID
");
$stmt->execute(['serviceID' => $serviceID]);
$service = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$service) { header("Location: Home.php"); exit(); }

$isLoggedIn    = isset($_SESSION['user_id']);
$currentUserID = $isLoggedIn ? $_SESSION['user_id'] : null;
$isOwner       = $isLoggedIn && $currentUserID == $service['ArtisanUserID'];

$success = '';
$error   = '';

 
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'deleteServiceOwner') {
    if ($isOwner) {
        $pdo->prepare("DELETE FROM Services WHERE ServiceID=:sid AND ArtisanID=:aid")
            ->execute(['sid' => $serviceID, 'aid' => $service['ArtisanID']]);
        header("Location: services.php"); exit();
    }
}

 
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'editService') {
    if ($isOwner) {
        $title       = trim($_POST['title']);
        $description = trim($_POST['description']);
        $category    = trim($_POST['category']);
        $price       = floatval($_POST['price']);
        $imageBase64 = $service['ImageURL'];

        if (!empty($_FILES['serviceImage']['name'])) {
            $fileTmpPath  = $_FILES['serviceImage']['tmp_name'];
            $fileType     = strtolower(pathinfo($_FILES['serviceImage']['name'], PATHINFO_EXTENSION));
            $allowedTypes = ['jpg','jpeg','png','gif','webp'];
            if (in_array($fileType, $allowedTypes) && $_FILES['serviceImage']['size'] <= 5*1024*1024) {
                $mimeMap     = ['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','gif'=>'image/gif','webp'=>'image/webp'];
                $imageBase64 = 'data:'.$mimeMap[$fileType].';base64,'.base64_encode(file_get_contents($fileTmpPath));
            } else {
                $error = "Image invalide ou trop lourde (max 5 Mo).";
            }
        }

        if (empty($error)) {
            if (empty($title) || empty($category)) {
                $error = "Le titre et la catégorie sont obligatoires.";
            } else {
                $pdo->prepare("UPDATE Services SET Title=:title,Description=:description,Category=:category,Price=:price,ImageURL=:img WHERE ServiceID=:sid AND ArtisanID=:aid")
                    ->execute(['title'=>$title,'description'=>$description?:null,'category'=>$category,'price'=>$price,'img'=>$imageBase64,'sid'=>$serviceID,'aid'=>$service['ArtisanID']]);
                $success = "Service mis à jour avec succès !";
                $stmt2 = $pdo->prepare("SELECT s.*, a.UserID as ArtisanUserID, a.ArtisanID, u.FullName as ArtisanName, u.PhoneNumber, u.ProfilePictureURL, a.State, a.Municipality, a.YearsOfExperience, a.Specialty FROM Services s JOIN Artisans a ON s.ArtisanID=a.ArtisanID JOIN Users u ON a.UserID=u.UserID WHERE s.ServiceID=:sid");
                $stmt2->execute(['sid'=>$serviceID]);
                $service = $stmt2->fetch(PDO::FETCH_ASSOC);
            }
        }
    }
}

 
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'addReview') {
    if (!$isLoggedIn) {
        $error = "Vous devez être connecté pour laisser un avis.";
    } elseif ($isOwner) {
        $error = "Vous ne pouvez pas évaluer votre propre service.";
    } else {
        $rating  = intval($_POST['rating'] ?? 0);
        $comment = trim($_POST['comment'] ?? '');
        if ($rating < 1 || $rating > 5) {
            $error = "Veuillez sélectionner une note entre 1 et 5.";
        } elseif (empty($comment)) {
            $error = "Le commentaire ne peut pas être vide.";
        } else {
            $chk = $pdo->prepare("SELECT ReviewID FROM ServiceReviews WHERE ServiceID=:sid AND UserID=:uid");
            $chk->execute(['sid'=>$serviceID,'uid'=>$currentUserID]);
            if ($chk->fetch()) {
                $pdo->prepare("UPDATE ServiceReviews SET Rating=:r,Comment=:c,CreatedAt=NOW() WHERE ServiceID=:sid AND UserID=:uid")
                    ->execute(['r'=>$rating,'c'=>$comment,'sid'=>$serviceID,'uid'=>$currentUserID]);
                $success = "Votre avis a été mis à jour !";
            } else {
                $pdo->prepare("INSERT INTO ServiceReviews (ServiceID,UserID,Rating,Comment) VALUES (:sid,:uid,:r,:c)")
                    ->execute(['sid'=>$serviceID,'uid'=>$currentUserID,'r'=>$rating,'c'=>$comment]);
                $success = "Votre avis a été publié !";
            }
            $pdo->prepare("UPDATE Services SET Rating=(SELECT AVG(Rating) FROM ServiceReviews WHERE ServiceID=:sid) WHERE ServiceID=:sid")
                ->execute(['sid'=>$serviceID]);
            $stmt3 = $pdo->prepare("SELECT s.*, a.UserID as ArtisanUserID, a.ArtisanID, u.FullName as ArtisanName, u.PhoneNumber, u.ProfilePictureURL, a.State, a.Municipality, a.YearsOfExperience, a.Specialty FROM Services s JOIN Artisans a ON s.ArtisanID=a.ArtisanID JOIN Users u ON a.UserID=u.UserID WHERE s.ServiceID=:sid");
            $stmt3->execute(['sid'=>$serviceID]);
            $service = $stmt3->fetch(PDO::FETCH_ASSOC);
        }
    }
}

 
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'deleteReview') {
    $pdo->prepare("DELETE FROM ServiceReviews WHERE ReviewID=:rid AND UserID=:uid")
        ->execute(['rid'=>intval($_POST['reviewID']),'uid'=>$currentUserID]);
    $pdo->prepare("UPDATE Services SET Rating=(SELECT COALESCE(AVG(Rating),NULL) FROM ServiceReviews WHERE ServiceID=:sid) WHERE ServiceID=:sid")
        ->execute(['sid'=>$serviceID]);
    $success = "Avis supprimé.";
}

 
$stmt4 = $pdo->prepare("SELECT r.*, u.FullName, u.ProfilePictureURL FROM ServiceReviews r JOIN Users u ON r.UserID=u.UserID WHERE r.ServiceID=:sid ORDER BY r.CreatedAt DESC");
$stmt4->execute(['sid'=>$serviceID]);
$reviews = $stmt4->fetchAll(PDO::FETCH_ASSOC);

$myReview = null;
if ($isLoggedIn && !$isOwner) {
    foreach ($reviews as $r) { if ($r['UserID'] == $currentUserID) { $myReview = $r; break; } }
}

$avgRating    = count($reviews) > 0 ? array_sum(array_column($reviews,'Rating')) / count($reviews) : 0;
$totalReviews = count($reviews);
$dist = [5=>0,4=>0,3=>0,2=>0,1=>0];
foreach ($reviews as $r) $dist[intval($r['Rating'])]++;

$categories = ['Plomberie','Électricité','Menuiserie','Maçonnerie','Peinture','Soudure','Climatisation','Autre'];

 
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'submitDevis') {
    if (!$isLoggedIn) {
        $error = "Vous devez être connecté pour envoyer une demande.";
    } elseif ($isOwner) {
        $error = "Vous ne pouvez pas demander un devis pour votre propre service.";
    } else {
        $desc      = trim($_POST['devis_description'] ?? '');
        $wilaya    = trim($_POST['devis_wilaya']       ?? '');
        $date      = trim($_POST['devis_date']         ?? '');
        $phone     = trim($_POST['devis_phone']        ?? '');
        if (empty($desc) || empty($wilaya) || empty($date) || empty($phone)) {
            $error = "Tous les champs de la demande sont obligatoires.";
            $openDevisModal = true;
        } else {
             
            $chkD = $pdo->prepare("SELECT DevisID FROM DevisRequests WHERE ServiceID=:sid AND ClientUserID=:uid AND Status='pending'");
            $chkD->execute(['sid'=>$serviceID,'uid'=>$currentUserID]);
            if ($chkD->fetch()) {
                $error = "Vous avez déjà une demande en attente pour ce service.";
            } else {
                $pdo->prepare("INSERT INTO DevisRequests (ServiceID,ClientUserID,ArtisanID,Description,Wilaya,PreferredDate,PhoneNumber) VALUES (:sid,:uid,:aid,:desc,:wil,:dt,:ph)")
                    ->execute(['sid'=>$serviceID,'uid'=>$currentUserID,'aid'=>$service['ArtisanID'],'desc'=>$desc,'wil'=>$wilaya,'dt'=>$date,'ph'=>$phone]);
                $success = "Demande de devis envoyée ! L'artisan vous répondra prochainement.";
            }
        }
    }
}

 
$myDevis = null;
if ($isLoggedIn && !$isOwner) {
    $dStmt = $pdo->prepare("SELECT * FROM DevisRequests WHERE ServiceID=:sid AND ClientUserID=:uid ORDER BY CreatedAt DESC LIMIT 1");
    $dStmt->execute(['sid'=>$serviceID,'uid'=>$currentUserID]);
    $myDevis = $dStmt->fetch(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($service['Title']); ?> - Services Artisans</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Cairo', sans-serif; background: #f4f7fe; color: #2d3748; }

        .nav-header { background: white; box-shadow: 0 2px 12px rgba(0,0,0,0.07); padding: 0 2rem; position: sticky; top: 0; z-index: 200; }
        .nav-inner { max-width: 1200px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; height: 64px; }
        .nav-brand { font-size: 1.4rem; font-weight: 900; color: #3b66f5; text-decoration: none; }
        .nav-links a { color: #4a5568; text-decoration: none; margin-left: 1.5rem; font-size: 0.9rem; font-weight: 500; transition: color 0.2s; }
        .nav-links a:hover { color: #3b66f5; }

        .breadcrumb { background: white; border-bottom: 1px solid #e8eeff; padding: 0.75rem 2rem; font-size: 0.85rem; color: #718096; }
        .breadcrumb a { color: #3b66f5; text-decoration: none; }

        .page-wrapper { max-width: 1200px; margin: 2rem auto; padding: 0 1.5rem 5rem; }

        .owner-bar { display: flex; gap: 0.75rem; margin-bottom: 1.5rem; flex-wrap: wrap; background: white; border-radius: 14px; padding: 1rem 1.5rem; box-shadow: 0 2px 12px rgba(0,0,0,0.06); border-left: 4px solid #3b66f5; align-items: center; }
        .owner-bar .owner-label { font-size: 0.9rem; font-weight: 600; color: #4a5568; margin-right: auto; }
        .owner-bar .owner-label i { color: #3b66f5; margin-right: 5px; }
        .btn-edit { background: linear-gradient(135deg,#3b66f5,#6c8fff); color: white; border: none; padding: 0.65rem 1.4rem; border-radius: 10px; font-family: 'Cairo',sans-serif; font-size: 0.9rem; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 0.5rem; transition: opacity 0.2s,transform 0.1s; }
        .btn-edit:hover { opacity: 0.9; transform: translateY(-1px); }
        .btn-del { background: linear-gradient(135deg,#f56565,#fc8181); color: white; border: none; padding: 0.65rem 1.4rem; border-radius: 10px; font-family: 'Cairo',sans-serif; font-size: 0.9rem; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 0.5rem; transition: opacity 0.2s,transform 0.1s; }
        .btn-del:hover { opacity: 0.9; transform: translateY(-1px); }

        .layout { display: grid; grid-template-columns: 1fr 360px; gap: 2rem; align-items: start; }
        .service-main { display: flex; flex-direction: column; gap: 1.5rem; }

        .service-hero { background: white; border-radius: 20px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.07); }
        .service-hero-img { width: 100%; height: 380px; object-fit: cover; display: block; }
        .service-hero-placeholder { width: 100%; height: 380px; background: linear-gradient(135deg,#eef2ff,#e0e7ff); display: flex; flex-direction: column; align-items: center; justify-content: center; color: #a5b4fc; gap: 1rem; }
        .service-hero-placeholder i { font-size: 4rem; }
        .service-body { padding: 2rem; }
        .service-category-badge { display: inline-block; background: #eef2ff; color: #3b66f5; font-size: 0.8rem; font-weight: 700; padding: 0.3rem 0.9rem; border-radius: 999px; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 0.75rem; }
        .service-title { font-size: 1.8rem; font-weight: 800; color: #1a202c; margin-bottom: 1rem; line-height: 1.3; }
        .service-meta { display: flex; align-items: center; gap: 1.5rem; flex-wrap: wrap; margin-bottom: 1.5rem; padding-bottom: 1.5rem; border-bottom: 1px solid #f0f0f0; }
        .stars-display { display: flex; gap: 3px; }
        .star { color: #e2e8f0; font-size: 1.1rem; }
        .star.filled { color: #f59e0b; }
        .rating-text { font-weight: 700; color: #2d3748; }
        .review-count { color: #718096; font-size: 0.9rem; }
        .service-desc { color: #4a5568; line-height: 1.9; font-size: 1rem; }

        .message { padding: 1rem 1.5rem; border-radius: 12px; margin-bottom: 1.5rem; display: flex; align-items: center; gap: 0.75rem; font-weight: 500; }
        .message.success { background: #d1fae5; color: #065f46; }
        .message.error   { background: #fee2e2; color: #991b1b; }

        .section-card { background: white; border-radius: 20px; padding: 2rem; box-shadow: 0 4px 20px rgba(0,0,0,0.07); }
        .section-title { font-size: 1.2rem; font-weight: 800; color: #1a202c; margin-bottom: 1.5rem; display: flex; align-items: center; gap: 0.6rem; }
        .section-title i { color: #3b66f5; }

        .rating-summary { display: flex; gap: 2rem; align-items: center; margin-bottom: 2rem; padding-bottom: 1.5rem; border-bottom: 1px solid #f0f0f0; flex-wrap: wrap; }
        .big-rating { text-align: center; min-width: 100px; }
        .big-rating .num { font-size: 3.5rem; font-weight: 900; color: #f59e0b; line-height: 1; }
        .big-rating .total { font-size: 0.85rem; color: #718096; margin-top: 4px; }
        .rating-bars { flex: 1; min-width: 200px; }
        .rating-bar-row { display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.4rem; font-size: 0.85rem; }
        .rating-bar-row .label { width: 30px; color: #718096; text-align: right; }
        .bar-track { flex: 1; height: 8px; background: #f0f0f0; border-radius: 999px; overflow: hidden; }
        .bar-fill { height: 100%; background: linear-gradient(90deg,#f59e0b,#fbbf24); border-radius: 999px; }
        .rating-bar-row .count { width: 24px; color: #a0aec0; font-size: 0.8rem; }

 
        .review-form { margin-bottom: 2rem; }
        .star-picker { display: flex; flex-direction: row; gap: 4px; margin-bottom: 0.4rem; }
        .star-picker label {
            font-size: 2.4rem;
            color: #6b6c6d;
            cursor: pointer;
            transition: color 0.1s, transform 0.1s;
            line-height: 1;
            user-select: none;
        }
        .star-picker label:hover { transform: scale(1.2); }
        .star-picker label.on { color: #f59e0b; }
        .star-hint { font-size: 0.82rem; color: #a0aec0; margin-bottom: 1rem; min-height: 1.1em; font-weight: 500; }

        .form-field { width: 100%; padding: 0.8rem 1rem; border: 1.5px solid #e2e8f0; border-radius: 12px; font-family: 'Cairo',sans-serif; font-size: 0.95rem; color: #2d3748; background: #f8faff; outline: none; transition: border-color 0.2s; resize: vertical; }
        .form-field:focus { border-color: #3b66f5; box-shadow: 0 0 0 3px rgba(59,102,245,0.1); background: white; }

        .btn-primary { background: linear-gradient(135deg,#3b66f5,#6c8fff); color: white; border: none; padding: 0.8rem 1.8rem; border-radius: 10px; font-family: 'Cairo',sans-serif; font-size: 0.95rem; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 0.5rem; margin-top: 0.75rem; transition: opacity 0.2s,transform 0.1s; }
        .btn-primary:hover { opacity: 0.9; transform: translateY(-1px); }

        .btn-danger { background: none; border: 1px solid #fc8181; color: #fc8181; padding: 0.3rem 0.8rem; border-radius: 8px; font-family: 'Cairo',sans-serif; font-size: 0.8rem; cursor: pointer; transition: all 0.2s; }
        .btn-danger:hover { background: #fc8181; color: white; }

        .login-prompt { background: #f8faff; border: 1.5px dashed #c3d0ff; border-radius: 12px; padding: 1.5rem; text-align: center; color: #718096; font-size: 0.95rem; }
        .login-prompt a { color: #3b66f5; font-weight: 600; text-decoration: none; }

        .reviews-list { display: flex; flex-direction: column; gap: 1.25rem; }
        .review-card { background: #f8faff; border-radius: 14px; padding: 1.25rem; border: 1.5px solid #e8eeff; position: relative; }
        .review-card.mine { border-color: #3b66f5; background: #eef2ff; }
        .review-header { display: flex; align-items: flex-start; gap: 0.75rem; margin-bottom: 0.75rem; }
        .reviewer-avatar { width: 40px; height: 40px; border-radius: 50%; flex-shrink: 0; background: linear-gradient(135deg,#3b66f5,#6c8fff); display: flex; align-items: center; justify-content: center; color: white; font-weight: 700; font-size: 1rem; overflow: hidden; }
        .reviewer-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .reviewer-info { flex: 1; }
        .reviewer-name { font-weight: 700; color: #2d3748; font-size: 0.95rem; }
        .review-date { font-size: 0.78rem; color: #a0aec0; margin-top: 2px; }
        .review-stars { display: flex; gap: 2px; margin-bottom: 0.5rem; }
        .review-stars .star { font-size: 0.9rem; }
        .review-text { color: #4a5568; font-size: 0.9rem; line-height: 1.7; }
        .mine-badge { position: absolute; top: 0.75rem; right: 0.75rem; background: #3b66f5; color: white; font-size: 0.7rem; font-weight: 700; padding: 2px 8px; border-radius: 999px; }
        .no-reviews { text-align: center; padding: 2rem; color: #a0aec0; }
        .no-reviews i { font-size: 2.5rem; margin-bottom: 0.75rem; display: block; opacity: 0.4; }

        .sidebar { display: flex; flex-direction: column; gap: 1.25rem; }
        .side-card { background: white; border-radius: 16px; padding: 1.5rem; box-shadow: 0 4px 20px rgba(0,0,0,0.07); }
        .price-big { font-size: 2.2rem; font-weight: 900; color: #3b66f5; text-align: center; margin: 0.5rem 0 0.25rem; }
        .price-label { text-align: center; color: #718096; font-size: 0.85rem; margin-bottom: 1.25rem; }
        .cta-btn { width: 100%; padding: 0.9rem; border: none; border-radius: 12px; font-family: 'Cairo',sans-serif; font-size: 0.95rem; font-weight: 700; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 0.5rem; margin-bottom: 0.6rem; transition: opacity 0.2s,transform 0.1s; text-decoration: none; }
        .cta-btn:hover { opacity: 0.9; transform: translateY(-1px); }
        .cta-btn.blue  { background: linear-gradient(135deg,#3b66f5,#6c8fff); color: white; }
        .cta-btn.green { background: linear-gradient(135deg,#10b981,#34d399); color: white; }
        .artisan-info { display: flex; align-items: center; gap: 0.75rem; margin-bottom: 1rem; }
        .artisan-avatar { width: 52px; height: 52px; border-radius: 50%; background: linear-gradient(135deg,#3b66f5,#6c8fff); display: flex; align-items: center; justify-content: center; color: white; font-weight: 700; font-size: 1.2rem; flex-shrink: 0; overflow: hidden; }
        .artisan-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .artisan-name { font-weight: 700; color: #1a202c; }
        .artisan-spec { font-size: 0.82rem; color: #718096; margin-top: 2px; }
        .info-row { display: flex; align-items: center; gap: 0.6rem; padding: 0.5rem 0; font-size: 0.9rem; color: #4a5568; border-bottom: 1px solid #f0f0f0; }
        .info-row:last-child { border-bottom: none; }
        .info-row i { color: #3b66f5; width: 16px; }

        .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.55); z-index: 999; align-items: center; justify-content: center; padding: 1rem; }
        .modal-overlay.open { display: flex; }
        .modal-box { background: white; border-radius: 20px; padding: 2rem; width: 100%; max-width: 600px; max-height: 90vh; overflow-y: auto; position: relative; box-shadow: 0 20px 60px rgba(0,0,0,0.2); animation: slideUp 0.25s ease; }
        @keyframes slideUp { from { transform: translateY(30px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        .modal-close { position: absolute; top: 1rem; right: 1rem; background: #f0f4ff; border: none; width: 32px; height: 32px; border-radius: 50%; font-size: 1.1rem; cursor: pointer; color: #718096; display: flex; align-items: center; justify-content: center; transition: background 0.2s; }
        .modal-close:hover { background: #e0e7ff; color: #3b66f5; }
        .modal-title { font-size: 1.2rem; font-weight: 800; color: #1a202c; margin-bottom: 1.5rem; display: flex; align-items: center; gap: 0.6rem; }
        .modal-title i { color: #3b66f5; }
        .modal-group { margin-bottom: 1rem; }
        .modal-group label { display: block; font-size: 0.85rem; font-weight: 600; color: #4a5568; margin-bottom: 0.4rem; }
        .modal-field { width: 100%; padding: 0.7rem 1rem; border: 1.5px solid #e2e8f0; border-radius: 10px; font-family: 'Cairo',sans-serif; font-size: 0.95rem; color: #2d3748; background: #f8faff; outline: none; transition: border-color 0.2s; }
        .modal-field:focus { border-color: #3b66f5; background: white; }
        textarea.modal-field { resize: vertical; }
        .modal-row { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
        .modal-footer { display: flex; gap: 0.75rem; margin-top: 1.5rem; }
        .btn-save { flex: 1; background: linear-gradient(135deg,#3b66f5,#6c8fff); color: white; border: none; padding: 0.85rem; border-radius: 10px; font-family: 'Cairo',sans-serif; font-size: 0.95rem; font-weight: 700; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 0.5rem; transition: opacity 0.2s; }
        .btn-save:hover { opacity: 0.9; }
        .btn-cancel-modal { background: #f0f4ff; color: #4a5568; border: none; padding: 0.85rem 1.5rem; border-radius: 10px; font-family: 'Cairo',sans-serif; font-size: 0.95rem; font-weight: 600; cursor: pointer; transition: background 0.2s; }
        .btn-cancel-modal:hover { background: #e0e7ff; }
        .img-preview-modal { display: none; margin-top: 0.75rem; }
        .img-preview-modal img { width: 100%; height: 130px; object-fit: cover; border-radius: 10px; }
 
        .modal-box.devis-box .modal-title i { color: #10b981; }
        .modal-box.devis-box .btn-save { background: linear-gradient(135deg,#10b981,#34d399); }
        .devis-service-preview { display:flex; align-items:center; gap:0.75rem; background:#f0fdf4; border:1.5px solid #a7f3d0; border-radius:12px; padding:0.85rem 1rem; margin-bottom:1.25rem; }
        .devis-service-preview .svc-icon { width:42px;height:42px;border-radius:10px;background:linear-gradient(135deg,#10b981,#34d399);display:flex;align-items:center;justify-content:center;color:white;font-size:1.1rem;flex-shrink:0; }
        .devis-service-preview .svc-info .svc-name { font-weight:700;color:#065f46;font-size:0.95rem; }
        .devis-service-preview .svc-info .svc-artisan { font-size:0.8rem;color:#059669;margin-top:2px; }

        @media (max-width: 900px) {
            .layout { grid-template-columns: 1fr; }
            .sidebar { order: -1; }
            .modal-row { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<nav class="nav-header">
    <div class="nav-inner">
                 <a href="Home.php" class="nav-brand">  <i class="fas fa-screwdriver-wrench" style="color:#3b66f5; margin-right:8px;"></i>Services <span>Artisans</span></a>

        <div class="nav-links">
            <a href="Home.php"><i class="fas fa-home"></i> Accueil</a>
            <a href="search-results.php"><i class="fas fa-search"></i> Recherche</a>
            <?php if ($isLoggedIn): ?>
                <a href="profile.php"><i class="fas fa-user"></i> Profil</a>
                <a href="profile.php?logout=1"><i class="fas fa-sign-out-alt"></i> Déconnexion</a>
            <?php else: ?>
                <a href="index1.php"><i class="fas fa-sign-in-alt"></i> Connexion</a>
            <?php endif; ?>
        </div>
    </div>
</nav>

<div class="breadcrumb">
    <a href="Home.php">Accueil</a> /
    <a href="search-results.php">Services</a> /
    <span><?php echo htmlspecialchars($service['Title']); ?></span>
</div>

<div class="page-wrapper">

    <?php if ($success): ?>
        <div class="message success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="message error"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <?php if ($isOwner): ?>
    <div class="owner-bar">
        <span class="owner-label"><i class="fas fa-shield-alt"></i> Vous êtes le propriétaire de ce service</span>
        <button class="btn-edit" onclick="document.getElementById('editModal').classList.add('open')">
            <i class="fas fa-edit"></i> Modifier
        </button>
        <form method="POST" onsubmit="return confirm('Supprimer ce service définitivement ?');" style="margin:0;">
            <input type="hidden" name="action" value="deleteServiceOwner">
            <button type="submit" class="btn-del"><i class="fas fa-trash-alt"></i> Supprimer</button>
        </form>
    </div>
    <?php endif; ?>

    <div class="layout">
        <div class="service-main">

            <div class="service-hero">
                <?php if (!empty($service['ImageURL'])): ?>
                    <img src="<?php echo $service['ImageURL']; ?>" alt="<?php echo htmlspecialchars($service['Title']); ?>" class="service-hero-img">
                <?php else: ?>
                    <div class="service-hero-placeholder"><i class="fas fa-briefcase"></i><span>Aucune image disponible</span></div>
                <?php endif; ?>
                <div class="service-body">
                    <?php if (!empty($service['Category'])): ?>
                        <span class="service-category-badge"><?php echo htmlspecialchars($service['Category']); ?></span>
                    <?php endif; ?>
                    <h1 class="service-title"><?php echo htmlspecialchars($service['Title']); ?></h1>
                    <div class="service-meta">
                        <div class="stars-display">
                            <?php for ($i=1;$i<=5;$i++): ?>
                                <i class="fas fa-star star <?php echo $i<=round($avgRating)?'filled':''; ?>"></i>
                            <?php endfor; ?>
                        </div>
                        <span class="rating-text"><?php echo $totalReviews>0?number_format($avgRating,1):'—'; ?></span>
                        <span class="review-count"><?php echo $totalReviews; ?> avis</span>
                        <?php if (!empty($service['CreatedAt'])): ?>
                            <span style="color:#a0aec0;font-size:0.85rem;">
                                <i class="far fa-calendar-alt"></i> Publié le <?php echo date('d/m/Y',strtotime($service['CreatedAt'])); ?>
                            </span>
                        <?php endif; ?>
                    </div>
                    <?php if (!empty($service['Description'])): ?>
                        <p class="service-desc"><?php echo nl2br(htmlspecialchars($service['Description'])); ?></p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="section-card">
                <div class="section-title"><i class="fas fa-star"></i> Avis clients</div>

                <?php if ($totalReviews > 0): ?>
                <div class="rating-summary">
                    <div class="big-rating">
                        <div class="num"><?php echo number_format($avgRating,1); ?></div>
                        <div class="stars-display" style="justify-content:center;margin:0.4rem 0;">
                            <?php for ($i=1;$i<=5;$i++): ?>
                                <i class="fas fa-star star <?php echo $i<=round($avgRating)?'filled':''; ?>" style="font-size:0.9rem;"></i>
                            <?php endfor; ?>
                        </div>
                        <div class="total"><?php echo $totalReviews; ?> avis</div>
                    </div>
                    <div class="rating-bars">
                        <?php for ($s=5;$s>=1;$s--): ?>
                        <div class="rating-bar-row">
                            <span class="label"><?php echo $s; ?> <i class="fas fa-star" style="color:#f59e0b;font-size:0.7rem;"></i></span>
                            <div class="bar-track">
                                <div class="bar-fill" style="width:<?php echo $totalReviews>0?($dist[$s]/$totalReviews*100):0; ?>%"></div>
                            </div>
                            <span class="count"><?php echo $dist[$s]; ?></span>
                        </div>
                        <?php endfor; ?>
                    </div>
                </div>
                <?php endif; ?>

                <?php if ($isOwner): ?>
                    <div class="login-prompt"><i class="fas fa-info-circle" style="color:#3b66f5;margin-right:6px;"></i>Vous ne pouvez pas évaluer votre propre service.</div>
                <?php elseif (!$isLoggedIn): ?>
                    <div class="login-prompt"><i class="fas fa-lock" style="margin-right:6px;"></i><a href="index1.php">Connectez-vous</a> pour laisser un avis.</div>
                <?php else: ?>
                    <div class="review-form">
                        <div class="section-title" style="font-size:1rem;margin-bottom:1rem;">
                            <i class="fas fa-pen"></i> <?php echo $myReview ? 'Modifier votre avis' : 'Laisser un avis'; ?>
                        </div>
                        <form method="POST" id="reviewForm" onsubmit="return validateReview()">
                            <input type="hidden" name="action" value="addReview">
 
                            <input type="hidden" name="rating" id="ratingValue" value="<?php echo $myReview ? intval($myReview['Rating']) : 0; ?>">

                            <label style="font-size:0.85rem;font-weight:600;color:#4a5568;display:block;margin-bottom:0.5rem;">Votre note *</label>

                            <div class="star-picker" id="starPicker">
                                <label data-v="1" title="Très mauvais"><i class="fas fa-star"></i></label>
                                <label data-v="2" title="Mauvais"><i class="fas fa-star"></i></label>
                                <label data-v="3" title="Moyen"><i class="fas fa-star"></i></label>
                                <label data-v="4" title="Bien"><i class="fas fa-star"></i></label>
                                <label data-v="5" title="Excellent"><i class="fas fa-star"></i></label>
                            </div>
                            <div class="star-hint" id="starHint"><?php echo $myReview ? ['','Très mauvais','Mauvais','Moyen','Bien','Excellent'][intval($myReview['Rating'])] : 'Cliquez pour noter'; ?></div>

                            <label style="font-size:0.85rem;font-weight:600;color:#4a5568;display:block;margin-bottom:0.4rem;">Votre commentaire *</label>
                            <textarea name="comment" id="commentField" class="form-field" rows="4"
                                placeholder="Partagez votre expérience avec ce service..."><?php echo $myReview ? htmlspecialchars($myReview['Comment']) : ''; ?></textarea>

                            <button type="submit" class="btn-primary">
                                <i class="fas fa-paper-plane"></i>
                                <?php echo $myReview ? 'Mettre à jour' : "Publier l'avis"; ?>
                            </button>
                        </form>
                    </div>
                <?php endif; ?>

                <?php if (empty($reviews)): ?>
                    <div class="no-reviews">
                        <i class="fas fa-comment-slash"></i>
                        <p>Aucun avis pour ce service.</p>
                        <p style="font-size:0.85rem;margin-top:0.3rem;">Soyez le premier à laisser un avis !</p>
                    </div>
                <?php else: ?>
                    <div class="reviews-list">
                        <?php foreach ($reviews as $review): ?>
                        <div class="review-card <?php echo $review['UserID']==$currentUserID?'mine':''; ?>">
                            <?php if ($review['UserID']==$currentUserID): ?><span class="mine-badge">Mon avis</span><?php endif; ?>
                            <div class="review-header">
                                <div class="reviewer-avatar">
                                    <?php if (!empty($review['ProfilePictureURL'])): ?>
                                        <img src="data:image/jpeg;base64,<?php echo $review['ProfilePictureURL']; ?>" alt="">
                                    <?php else: ?>
                                        <?php echo strtoupper(substr($review['FullName'],0,1)); ?>
                                    <?php endif; ?>
                                </div>
                                <div class="reviewer-info">
                                    <div class="reviewer-name"><?php echo htmlspecialchars($review['FullName']); ?></div>
                                    <div class="review-date"><i class="far fa-clock"></i> <?php echo date('d/m/Y à H:i',strtotime($review['CreatedAt'])); ?></div>
                                </div>
                                <?php if ($review['UserID']==$currentUserID): ?>
                                <form method="POST" onsubmit="return confirm('Supprimer votre avis ?');" style="margin-left:auto;">
                                    <input type="hidden" name="action" value="deleteReview">
                                    <input type="hidden" name="reviewID" value="<?php echo $review['ReviewID']; ?>">
                                    <button type="submit" class="btn-danger"><i class="fas fa-trash-alt"></i> Supprimer</button>
                                </form>
                                <?php endif; ?>
                            </div>
                            <div class="review-stars">
                                <?php for ($i=1;$i<=5;$i++): ?>
                                    <i class="fas fa-star star <?php echo $i<=$review['Rating']?'filled':''; ?>"></i>
                                <?php endfor; ?>
                            </div>
                            <p class="review-text"><?php echo nl2br(htmlspecialchars($review['Comment'])); ?></p>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="sidebar">
            <div class="side-card">
                <div style="text-align:center;color:#718096;font-size:0.85rem;">Prix du service</div>
                <div class="price-big"><?php echo $service['Price']>0?number_format($service['Price'],0,',',' ').' DA':'Sur devis'; ?></div>
                <?php if ($service['Price']>0): ?>
                    <div class="price-label">par intervention</div>
                <?php else: ?>
                    <div class="price-label">Contactez l'artisan pour un devis</div>
                <?php endif; ?>
                <a href="tel:<?php echo htmlspecialchars($service['PhoneNumber']??''); ?>" class="cta-btn blue">
                    <i class="fas fa-phone"></i> Appeler l'artisan
                </a>
                <?php if (!$isLoggedIn): ?>
                    <a href="index1.php" class="cta-btn green"><i class="fas fa-file-alt"></i> Demander un devis</a>
                <?php elseif ($isOwner): ?>
                    <a href="mes-devis.php" class="cta-btn green"><i class="fas fa-inbox"></i> Voir les demandes reçues</a>
                <?php elseif ($myDevis): ?>
                    <?php
                        $statusColors = ['pending'=>'#f59e0b','accepted'=>'#10b981','refused'=>'#ef4444','completed'=>'#3b66f5'];
                        $statusLabels = ['pending'=>'En attente','accepted'=>'Accepté','refused'=>'Refusé','completed'=>'Terminé'];
                        $sc = $statusColors[$myDevis['Status']] ?? '#718096';
                        $sl = $statusLabels[$myDevis['Status']] ?? $myDevis['Status'];
                    ?>
                    <div style="background:#f8faff;border:1.5px solid #e8eeff;border-radius:12px;padding:0.9rem 1rem;text-align:center;font-size:0.88rem;">
                        <div style="font-weight:700;color:#2d3748;margin-bottom:4px;"><i class="fas fa-file-alt" style="color:#3b66f5;"></i> Demande envoyée</div>
                        <span style="background:<?php echo $sc;?>;color:white;padding:2px 10px;border-radius:999px;font-size:0.78rem;font-weight:700;"><?php echo $sl; ?></span>
                        <?php if ($myDevis['ArtisanResponse']): ?>
                        <div style="margin-top:8px;background:white;border-radius:8px;padding:0.6rem 0.8rem;text-align:left;color:#4a5568;font-size:0.83rem;border:1px solid #e2e8f0;">
                            <strong>Réponse :</strong> <?php echo htmlspecialchars($myDevis['ArtisanResponse']); ?>
                        </div>
                        <?php endif; ?>
                        <a href="mes-demandes.php" style="display:block;margin-top:8px;color:#3b66f5;font-size:0.82rem;font-weight:600;">Voir toutes mes demandes →</a>
                    </div>
                <?php else: ?>
                    <button class="cta-btn green" onclick="document.getElementById('devisModal').classList.add('open')">
                        <i class="fas fa-file-alt"></i> Demander un devis
                    </button>
                <?php endif; ?>
            </div>

            <div class="side-card">
                <div class="section-title" style="margin-bottom:1rem;"><i class="fas fa-user-tie"></i> L'artisan</div>
                <div class="artisan-info">
                    <div class="artisan-avatar">
                        <?php if (!empty($service['ProfilePictureURL'])): ?>
                            <img src="data:image/jpeg;base64,<?php echo $service['ProfilePictureURL']; ?>" alt="">
                        <?php else: ?>
                            <?php echo strtoupper(substr($service['ArtisanName'],0,1)); ?>
                        <?php endif; ?>
                    </div>
                    <div>
                        <div class="artisan-name"><?php echo htmlspecialchars($service['ArtisanName']); ?></div>
                        <div class="artisan-spec"><?php echo htmlspecialchars($service['Specialty']??'Artisan'); ?></div>
                    </div>
                </div>
                <?php if (!empty($service['State'])): ?>
                <div class="info-row">
                    <i class="fas fa-map-marker-alt"></i>
                    <?php echo htmlspecialchars($service['State']); ?>
                    <?php if (!empty($service['Municipality'])): ?> — <?php echo htmlspecialchars($service['Municipality']); ?><?php endif; ?>
                </div>
                <?php endif; ?>
                <?php if (!empty($service['YearsOfExperience'])): ?>
                <div class="info-row"><i class="fas fa-briefcase"></i> <?php echo $service['YearsOfExperience']; ?> ans d'expérience</div>
                <?php endif; ?>
                <?php if (!empty($service['PhoneNumber'])): ?>
                <div class="info-row"><i class="fas fa-phone"></i> <?php echo htmlspecialchars($service['PhoneNumber']); ?></div>
                <?php endif; ?>
                <div class="info-row">
                    <i class="fas fa-star"></i>
                    <?php echo $totalReviews>0?number_format($avgRating,1).'/5 ('.$totalReviews.' avis)':'Pas encore évalué'; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if ($isOwner): ?>
<div class="modal-overlay" id="editModal">
    <div class="modal-box">
        <button class="modal-close" onclick="document.getElementById('editModal').classList.remove('open')">&times;</button>
        <div class="modal-title"><i class="fas fa-edit"></i> Modifier le service</div>
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="editService">
            <div class="modal-group">
                <label>Titre *</label>
                <input type="text" name="title" class="modal-field" value="<?php echo htmlspecialchars($service['Title']); ?>" required>
            </div>
            <div class="modal-group">
                <label>Catégorie *</label>
                <select name="category" class="modal-field" required>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?php echo $cat; ?>" <?php echo $service['Category']===$cat?'selected':''; ?>><?php echo $cat; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="modal-group">
                <label>Description</label>
                <textarea name="description" class="modal-field" rows="4"><?php echo htmlspecialchars($service['Description']??''); ?></textarea>
            </div>
            <div class="modal-row">
                <div class="modal-group">
                    <label>Prix (DA)</label>
                    <input type="number" name="price" class="modal-field" value="<?php echo $service['Price']; ?>" min="0" step="100">
                </div>
                <div class="modal-group">
                    <label>Nouvelle image <span style="color:#a0aec0;font-weight:400;">(optionnel)</span></label>
                    <input type="file" name="serviceImage" id="modalImageInput" accept="image/*" class="modal-field" style="padding:0.45rem;">
                    <div class="img-preview-modal" id="modalImgPreview">
                        <img id="modalPreviewImg" src="" alt="Aperçu">
                    </div>
                </div>
            </div>
            <?php if (!empty($service['ImageURL'])): ?>
            <div class="modal-group">
                <label style="font-size:0.8rem;color:#718096;">Image actuelle</label>
                <img src="<?php echo $service['ImageURL']; ?>" style="width:100%;height:110px;object-fit:cover;border-radius:10px;border:1.5px solid #e2e8f0;">
            </div>
            <?php endif; ?>
            <div class="modal-footer">
                <button type="submit" class="btn-save"><i class="fas fa-save"></i> Enregistrer les modifications</button>
                <button type="button" class="btn-cancel-modal" onclick="document.getElementById('editModal').classList.remove('open')">Annuler</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>


<?php if ($isLoggedIn && !$isOwner && !$myDevis): ?>
 
<div class="modal-overlay" id="devisModal">
    <div class="modal-box devis-box" style="max-width:540px;">
        <button class="modal-close" onclick="document.getElementById('devisModal').classList.remove('open')">&times;</button>
        <div class="modal-title"><i class="fas fa-file-alt"></i> Demande de devis</div>

        <div class="devis-service-preview">
            <div class="svc-icon"><i class="fas fa-briefcase"></i></div>
            <div class="svc-info">
                <div class="svc-name"><?php echo htmlspecialchars($service['Title']); ?></div>
                <div class="svc-artisan">Artisan : <?php echo htmlspecialchars($service['ArtisanName']); ?></div>
            </div>
        </div>

        <form method="POST">
            <input type="hidden" name="action" value="submitDevis">

            <div class="modal-group">
                <label><i class="fas fa-align-left" style="color:#10b981;"></i> Description du travail *</label>
                <textarea name="devis_description" class="modal-field" rows="4"
                    placeholder="Décrivez le travail à effectuer, les détails importants..."
                    required><?php echo htmlspecialchars($_POST['devis_description'] ?? ''); ?></textarea>
            </div>

            <div class="modal-row">
                <div class="modal-group">
                    <label><i class="fas fa-map-marker-alt" style="color:#f97316;"></i> Wilaya *</label>
                    <select name="devis_wilaya" id="devisWilaya" class="modal-field" required>
                        <option value="">Sélectionner</option>
                    </select>
                </div>
                <div class="modal-group">
                    <label><i class="fas fa-calendar-alt" style="color:#3b66f5;"></i> Date souhaitée *</label>
                    <input type="date" name="devis_date" class="modal-field"
                        min="<?php echo date('Y-m-d'); ?>"
                        value="<?php echo htmlspecialchars($_POST['devis_date'] ?? ''); ?>" required>
                </div>
            </div>

            <div class="modal-group">
                <label><i class="fas fa-phone" style="color:#10b981;"></i> Votre numéro de téléphone *</label>
                <input type="tel" name="devis_phone" class="modal-field"
                    placeholder="Ex: 0555 123 456"
                    value="<?php echo htmlspecialchars($_POST['devis_phone'] ?? ''); ?>" required>
            </div>

            <div class="modal-footer">
                <button type="submit" class="btn-save"><i class="fas fa-paper-plane"></i> Envoyer la demande</button>
                <button type="button" class="btn-cancel-modal" onclick="document.getElementById('devisModal').classList.remove('open')">Annuler</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>
<script src="locations.js"></script>
<script>
 
(function () {
    const picker  = document.getElementById('starPicker');
    if (!picker) return;

    const labels  = Array.from(picker.querySelectorAll('label'));
    const hidden  = document.getElementById('ratingValue');
    const hint    = document.getElementById('starHint');
    const hints   = ['', 'Très mauvais', 'Mauvais', 'Moyen', 'Bien', 'Excellent'];
    let selected  = parseInt(hidden.value) || 0;

    function paint(upTo) {
        labels.forEach(l => l.classList.toggle('on', parseInt(l.dataset.v) <= upTo));
    }

    paint(selected);  

    labels.forEach(label => {
        const v = parseInt(label.dataset.v);

        label.addEventListener('mouseenter', () => {
            paint(v);
            hint.textContent = hints[v];
        });

        label.addEventListener('mouseleave', () => {
            paint(selected);
            hint.textContent = selected ? hints[selected] : 'Cliquez pour noter';
        });

        label.addEventListener('click', () => {
            selected = v;
            hidden.value = v;
            paint(selected);
            hint.textContent = hints[selected];
        });
    });
})();

 
function validateReview() {
    const r = parseInt(document.getElementById('ratingValue').value);
    const c = document.getElementById('commentField').value.trim();
    if (!r || r < 1 || r > 5) {
        alert('Veuillez sélectionner une note (1 à 5 étoiles).');
        return false;
    }
    if (!c) {
        alert('Le commentaire ne peut pas être vide.');
        return false;
    }
    return true;
}

<?php if ($isOwner): ?>
 
document.getElementById('editModal').addEventListener('click', function(e) {
    if (e.target === this) this.classList.remove('open');
});
document.getElementById('modalImageInput').addEventListener('change', function() {
    const file = this.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = e => {
        document.getElementById('modalPreviewImg').src = e.target.result;
        document.getElementById('modalImgPreview').style.display = 'block';
    };
    reader.readAsDataURL(file);
});
<?php if ($error && isset($_POST['action']) && $_POST['action'] === 'editService'): ?>
document.getElementById('editModal').classList.add('open');
<?php endif; ?>
<?php endif; ?>

 
(function() {
    const devisMod = document.getElementById('devisModal');
    if (!devisMod) return;

    devisMod.addEventListener('click', function(e) { 
        if (e.target === this) this.classList.remove('open'); 
    });

    const sel = document.getElementById('devisWilaya');
    if (!sel) return;

    getAllStates().forEach(state => {
        const option = document.createElement('option');
        option.value = state;
        option.textContent = state;
        sel.appendChild(option);
    });

    <?php if (!empty($_POST['devis_wilaya'])): ?>
    sel.value = '<?php echo addslashes($_POST['devis_wilaya']); ?>';
    <?php endif; ?>

    <?php if (!empty($openDevisModal)): ?>
    devisMod.classList.add('open');
    <?php endif; ?>
})();
</script>

</body>
</html>