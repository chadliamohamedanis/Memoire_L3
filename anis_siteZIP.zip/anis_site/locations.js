 

const algeriaLocations = {
    'Annaba': {
        name: 'Annaba',
        municipalities: [
            'Annaba',
            'Bouni',
            'El Bouni',
            'El Hadjar',
            'Seraidi',
            'Ain Berda',
            'Chetaibi',
            'Sidi Amar',
            'Oued El Aneb',
            'Berrahal',
            'El Eulma',
            'El Kala'
        ]
    },
    'Alger': {
        name: 'Alger',
        municipalities: [
            'Alger Centre',
            'Sidi M\'Hamed',
            'El Madania',
            'Bab El Oued',
            'Bologhine',
            'Casbah',
            'Oued Koriche',
            'Bir Mourad Raïs',
            'El Biar',
            'Bouzareah',
            'Birkhadem',
            'Dély Ibrahim',
            'Draria',
            'El Harrach',
            'Hussein Dey',
            'Kouba',
            'Mohammadia',
            'Rouiba',
            'Staoueli',
            'Zéralda'
        ]
    },
    'Oran': {
        name: 'Oran',
        municipalities: [
            'Oran',
            'Bir El Djir',
            'Es Senia',
            'Aïn El Turk',
            'Arzew',
            'Bethioua',
            'Mers El Kébir',
            'Bousfer',
            'El Ançor',
            'Oued Tlelat',
            'Gdyel',
            'Hassi Ben Okba',
            'Hassi Mefsoukh',
            'Mersat Hadjadj',
            'Sidi Chami',
            'Sidi Ben Yebka'
        ]
    },
    'Constantine': {
        name: 'Constantine',
        municipalities: [
            'Constantine',
            'El Khroub',
            'Aïn Abid',
            'Aïn Smara',
            'Beni Hamiden',
            'Didouche Mourad',
            'Hamma Bouziane',
            'Ibn Ziad',
            'Mila',
            'Ouled Rahmoune',
            'Zighoud Youcef'
        ]
    },
    'Blida': {
        name: 'Blida',
        municipalities: [
            'Blida',
            'Boufarik',
            'Bouinan',
            'El Affroun',
            'Larbaa',
            'Médéa',
            'Oued El Alleug',
            'Ouled Yaïch',
            'Soumaa'
        ]
    },
    'Tizi Ouzou': {
        name: 'Tizi Ouzou',
        municipalities: [
            'Tizi Ouzou',
            'Aïn El Hammam',
            'Azazga',
            'Béni Douala',
            'Boghni',
            'Boudjima',
            'Draâ Ben Khedda',
            'Draâ El Mizan',
            'Freha',
            'Iferhounène',
            'Larbaâ Nath Irathen',
            'Mâatkas',
            'Makouda',
            'Mekla',
            'Ouadhias',
            'Ouaguenoun',
            'Tigzirt',
            'Tirmitine',
            'Tizi Ghenif',
            'Yakouren'
        ]
    },
    'Béjaïa': {
        name: 'Béjaïa',
        municipalities: [
            'Béjaïa',
            'Adekar',
            'Aït R\'zine',
            'Akbou',
            'Amizour',
            'Aokas',
            'Barbacha',
            'Boudjellil',
            'Chemini',
            'Darguina',
            'El Kseur',
            'Ighil Ali',
            'Kherrata',
            'Seddouk',
            'Sidi Aïch',
            'Souk El Tenine',
            'Tazmalt',
            'Timezrit',
            'Tichy',
            'Toudja'
        ]
    },
    'Sétif': {
        name: 'Sétif',
        municipalities: [
            'Sétif',
            'Aïn Arnat',
            'Aïn Azel',
            'Aïn El Kebira',
            'Aïn Oulmene',
            'Amoucha',
            'Babor',
            'Béni Aziz',
            'Béni Ourtilane',
            'Bouandas',
            'Bougaâ',
            'Bousselam',
            'Dehamcha',
            'El Eulma',
            'Guenzet',
            'Hammam Guergour',
            'Hammam Souhna',
            'Maoklane',
            'Ouled Tebben',
            'Talaifacene'
        ]
    },
    'Batna': {
        name: 'Batna',
        municipalities: [
            'Batna',
            'Aïn Djasser',
            'Aïn Touta',
            'Arris',
            'Barika',
            'Bouzina',
            'Chemora',
            'Djezzar',
            'El Madher',
            'Fesdis',
            'Ghassira',
            'Ichmoul',
            'Menaâ',
            'Merouana',
            'N\'Gaous',
            'Oued El Ma',
            'Ouled Si Slimane',
            'Ras El Aioun',
            'Seggana',
            'Seriana',
            'Tazoult',
            'Théniet El Abed',
            'Timgad',
            'Zanat El Beida'
        ]
    },
    'Djelfa': {
        name: 'Djelfa',
        municipalities: [
            'Djelfa',
            'Aïn El Ibel',
            'Aïn Oussara',
            'Amourah',
            'Benhar',
            'Birine',
            'Bouira Lahdab',
            'Charef',
            'Dar Chioukh',
            'Deldoul',
            'El Guedid',
            'El Idrissia',
            'El Khemis',
            'Faidh El Botma',
            'Guettara',
            'Hassi Bahbah',
            'Hassi Fedoul',
            'Messaad',
            'M\'Liliha',
            'Oum Laadham',
            'Sed Rahal',
            'Selmana',
            'Sidi Baïzed',
            'Zaafrane',
            'Zaccar'
        ]
    }
};

 
function getAllStates() {
    return Object.keys(algeriaLocations).sort();
}

 
function getMunicipalitiesByState(stateName) {
    if (algeriaLocations[stateName]) {
        return algeriaLocations[stateName].municipalities.sort();
    }
    return [];
}

 
function stateExists(stateName) {
    return algeriaLocations.hasOwnProperty(stateName);
}

 
function municipalityExists(stateName, municipalityName) {
    if (!stateExists(stateName)) return false;
    return algeriaLocations[stateName].municipalities.includes(municipalityName);
}
