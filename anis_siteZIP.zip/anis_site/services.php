<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Artisan') {
    header("Location: index1.php");
    exit();
}

$host = 'localhost';
$dbname = 'anis';
$username = 'root';
$password = '';

ini_set('display_errors', 1);
error_reporting(E_ALL);

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

$userID = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT * FROM Artisans WHERE UserID = :userID");
$stmt->execute(['userID' => $userID]);
$artisanData = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$artisanData) die("Artisan non trouvé.");

$success = '';
$error = '';

 
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'addService') {
    $title       = trim($_POST['title']);
    $description = trim($_POST['description']);
    $category    = trim($_POST['category']);
    $price       = floatval($_POST['price']);
    $imageBase64 = null;

    if (!empty($_FILES['serviceImage']['name'])) {
        $fileTmpPath = $_FILES['serviceImage']['tmp_name'];
        $fileType    = strtolower(pathinfo($_FILES['serviceImage']['name'], PATHINFO_EXTENSION));
        $allowedTypes = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

        if (in_array($fileType, $allowedTypes) && $_FILES['serviceImage']['size'] <= 5 * 1024 * 1024) {
           $mimeMap = ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif', 'webp' => 'image/webp'];
$mime = $mimeMap[$fileType] ?? 'image/jpeg';
$imageBase64 = 'data:' . $mime . ';base64,' . base64_encode(file_get_contents($fileTmpPath));
        } else {
            $error = "Image invalide ou trop lourde (max 5 Mo).";
        }
    }

    if (empty($title) || empty($category)) {
        $error = "Le titre et la catégorie sont obligatoires.";
    } elseif (empty($error)) {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO Services (ArtisanID, Title, Description, Category, Price, ImageURL, CreatedAt)
                VALUES (:artisanID, :title, :description, :category, :price, :imageURL, NOW())
            ");
            $stmt->execute([
                'artisanID'   => $artisanData['ArtisanID'],
                'title'       => $title,
                'description' => $description ?: null,
                'category'    => $category,
                'price'       => $price,
                'imageURL'    => $imageBase64,
            ]);
            $success = "Service ajouté avec succès !";
        } catch (PDOException $e) {
            $error = "Erreur : " . $e->getMessage();
        }
    }
}

 
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'deleteService') {
    $svcID = intval($_POST['serviceID']);
    try {
        $stmt = $pdo->prepare("DELETE FROM Services WHERE ServiceID = :id AND ArtisanID = :artisanID");
        $stmt->execute(['id' => $svcID, 'artisanID' => $artisanData['ArtisanID']]);
        $success = "Service supprimé.";
    } catch (PDOException $e) {
        $error = "Erreur lors de la suppression.";
    }
}

 
$stmt = $pdo->prepare("SELECT * FROM Services WHERE ArtisanID = :artisanID ORDER BY ServiceID DESC");
$stmt->execute(['artisanID' => $artisanData['ArtisanID']]);
$services = $stmt->fetchAll(PDO::FETCH_ASSOC);

$categories = ['Plomberie','Électricité','Menuiserie','Maçonnerie','Peinture','Soudure','Climatisation','Autre'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mes Services</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Cairo', sans-serif;
            background: #f0f4ff;
            color: #2d3748;
            min-height: 100vh;
        }

 
        .nav-header {
            background: white;
            box-shadow: 0 2px 12px rgba(0,0,0,0.07);
            padding: 0 2rem;
            position: sticky;
            top: 0;
            z-index: 100;
        }
        .nav-header-content {
            max-width: 1100px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 64px;
        }
        .nav-brand { font-size: 1.4rem; font-weight: 900; color: #3b66f5; text-decoration: none; }
        .nav-links a {
            color: #4a5568;
            text-decoration: none;
            margin-left: 1.5rem;
            font-size: 0.9rem;
            font-weight: 500;
            transition: color 0.2s;
        }
        .nav-links a:hover { color: #3b66f5; }

        .main-wrapper {
            max-width: 1100px;
            margin: 2rem auto;
            padding: 0 1.5rem 5rem;
        }

 
        .header-card {
            background: linear-gradient(135deg, #3b66f5, #6c8fff);            
            color: white;
            border-radius: 20px;
            padding: 2rem 2.5rem;
            display: flex;
            align-items: center;
            gap: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 8px 30px rgba(249,115,22,0.3);
        }
        .header-card > i { font-size: 2.5rem; opacity: 0.9; }
        .header-card h1 { font-size: 1.6rem; font-weight: 700; }
        .header-card p  { opacity: 0.85; font-size: 0.95rem; margin-top: 0.25rem; }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            color: #718096;
            text-decoration: none;
            font-size: 0.9rem;
            margin-bottom: 1.5rem;
            transition: color 0.2s;
        }
        .back-link:hover { color: #3b66f5; }

 
        .message {
            padding: 1rem 1.5rem;
            border-radius: 12px;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-weight: 500;
        }
        .message.success { background: #d1fae5; color: #065f46; }
        .message.error   { background: #fee2e2; color: #991b1b; }

 
        .stats-bar {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            flex-wrap: wrap;
        }
        .stat-item {
            background: white;
            border-radius: 12px;
            padding: 1rem 1.5rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            flex: 1;
            min-width: 140px;
            text-align: center;
        }
        .stat-item .stat-num  { font-size: 1.8rem; font-weight: 800; color: #3b66f5; }
        .stat-item .stat-label { font-size: 0.8rem; color: #718096; margin-top: 2px; }

 
        .card {
            background: white;
            border-radius: 16px;
            box-shadow: 0 2px 16px rgba(0,0,0,0.06);
            padding: 2rem;
            margin-bottom: 2rem;
        }
        .card-title {
            font-size: 1.1rem;
            font-weight: 700;
            color: #2d3748;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.6rem;
        }
        .card-title i { color: #3b66f5; }

 
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        .form-row-3 {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 1rem;
        }
        .form-group { margin-bottom: 1rem; }
        .form-group label {
            display: block;
            font-size: 0.85rem;
            font-weight: 600;
            color: #4a5568;
            margin-bottom: 0.4rem;
        }
        .form-field {
            width: 100%;
            padding: 0.7rem 1rem;
            border: 1.5px solid #e2e8f0;
            border-radius: 10px;
            font-family: 'Cairo', sans-serif;
            font-size: 0.95rem;
            color: #2d3748;
            background: #f8faff;
            transition: border-color 0.2s, box-shadow 0.2s;
            outline: none;
        }
        .form-field:focus {
            border-color: #3b66f5;
            box-shadow: 0 0 0 3px rgba(249,115,22,0.1);
            background: white;
        }
        textarea.form-field { resize: vertical; }

 
        .image-upload-area {
            border: 2px dashed #e2e8f0;
            border-radius: 12px;
            padding: 1.5rem;
            text-align: center;
            cursor: pointer;
            transition: border-color 0.2s, background 0.2s;
            background: #f8faff;
            position: relative;
        }
        .image-upload-area:hover {
            border-color: #3b66f5;
            background: #fff7ed;
        }
        .image-upload-area input[type="file"] {
            position: absolute;
            inset: 0;
            opacity: 0;
            cursor: pointer;
            width: 100%;
            height: 100%;
        }
        .image-upload-area i { font-size: 2rem; color: #3b66f5; margin-bottom: 0.5rem; display: block; }
        .image-upload-area p { font-size: 0.85rem; color: #718096; }
        .image-upload-area strong { color: #3b66f5; }

        #imagePreview {
            display: none;
            margin-top: 1rem;
            border-radius: 10px;
            overflow: hidden;
            max-height: 180px;
        }
        #imagePreview img {
            width: 100%;
            height: 180px;
            object-fit: cover;
            border-radius: 10px;
        }

        .btn-submit {
            background: linear-gradient(135deg, #3b66f5, #6c8fff);
            color: white;
            border: none;
            padding: 0.85rem 2rem;
            border-radius: 10px;
            font-family: 'Cairo', sans-serif;
            font-size: 0.95rem;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: opacity 0.2s, transform 0.1s;
            margin-top: 0.5rem;
        }
        .btn-submit:hover { opacity: 0.92; transform: translateY(-1px); }

 
        .filter-bar {
            display: flex;
            gap: 0.5rem;
            flex-wrap: wrap;
            margin-bottom: 1.5rem;
        }
        .filter-btn {
            padding: 0.4rem 1rem;
            border-radius: 999px;
            border: 1.5px solid #e2e8f0;
            background: white;
            font-family: 'Cairo', sans-serif;
            font-size: 0.85rem;
            font-weight: 600;
            color: #718096;
            cursor: pointer;
            transition: all 0.2s;
        }
        .filter-btn:hover, .filter-btn.active {
            background: #3b66f5;
            border-color: #3b66f5;
            color: white;
        }

 
        .services-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1.5rem;
        }

        .service-card {
            background: white;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 2px 12px rgba(0,0,0,0.06);
            border: 1.5px solid #f0f0f0;
            transition: transform 0.2s, box-shadow 0.2s;
            position: relative;
        }
        .service-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 28px rgba(249,115,22,0.15);
        }

        .service-img {
            width: 100%;
            height: 180px;
            object-fit: cover;
            display: block;
        }

        .service-img-placeholder {
            width: 100%;
            height: 180px;
            background: linear-gradient(135deg, #fff7ed, #ffedd5);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            color: #3b66f5;
            gap: 0.5rem;
        }
        .service-img-placeholder i { font-size: 2.5rem; opacity: 0.5; }
        .service-img-placeholder span { font-size: 0.8rem; opacity: 0.6; }

        .service-body { padding: 1.25rem; }

        .service-category {
            display: inline-block;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            background: #fff7ed;
            color: #3b66f5;
            padding: 0.2rem 0.7rem;
            border-radius: 999px;
            margin-bottom: 0.6rem;
        }

        .service-title {
            font-size: 1rem;
            font-weight: 700;
            color: #2d3748;
            margin-bottom: 0.4rem;
        }

        .service-desc {
            font-size: 0.85rem;
            color: #718096;
            line-height: 1.6;
            margin-bottom: 0.75rem;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .service-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding-top: 0.75rem;
            border-top: 1px solid #f0f0f0;
        }

        .service-price {
            font-size: 1.1rem;
            font-weight: 800;
            color: #3b66f5;
        }
        .service-price span { font-size: 0.75rem; font-weight: 500; color: #a0aec0; }

        .service-rating {
            display: flex;
            align-items: center;
            gap: 4px;
            font-size: 0.85rem;
            color: #3b66f5;
            font-weight: 600;
        }

        .service-date {
            font-size: 0.75rem;
            color: #a0aec0;
            margin-top: 0.4rem;
        }

        .btn-delete-svc {
            position: absolute;
            top: 0.75rem;
            right: 0.75rem;
            background: rgba(255,255,255,0.95);
            border: none;
            color: #fc8181;
            cursor: pointer;
            font-size: 0.85rem;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            transition: background 0.2s, color 0.2s;
        }
        .btn-delete-svc:hover { background: #fc8181; color: white; }

 
        .empty-placeholder {
            text-align: center;
            padding: 3rem 1rem;
            color: #a0aec0;
        }
        .empty-placeholder i { font-size: 3.5rem; margin-bottom: 1rem; display: block; opacity: 0.35; }
        .empty-placeholder h2 { font-size: 1.1rem; font-weight: 600; margin-bottom: 0.4rem; color: #718096; }
        .empty-placeholder p { font-size: 0.9rem; }

        @media (max-width: 650px) {
            .form-row, .form-row-3 { grid-template-columns: 1fr; }
            .header-card { flex-direction: column; text-align: center; }
            .services-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<nav class="nav-header">
    <div class="nav-header-content">
                 <a href="Home.php" class="nav-brand">  <i class="fas fa-screwdriver-wrench" style="color:#3b66f5; margin-right:8px;"></i>Services <span>Artisans</span></a>

        <div class="nav-links">
            <a href="profile.php"><i class="fas fa-user"></i> Mon Profil</a>
            <a href="employees.php"><i class="fas fa-users"></i> Employés</a>
            <a href="profile.php?logout=1"><i class="fas fa-sign-out-alt"></i> Déconnexion</a>
        </div>
    </div>
</nav>

<div class="main-wrapper">

    <a href="profile.php" class="back-link">
        <i class="fas fa-arrow-left"></i> Retour au profil
    </a>

    <div class="header-card">
        <i class="fas fa-briefcase"></i>
        <div>
            <h1>Mes Services</h1>
            <p>Publiez et gérez vos offres de services</p>
        </div>
    </div>

    <?php if ($success): ?>
        <div class="message success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="message error"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

 
    <div class="stats-bar">
        <div class="stat-item">
            <div class="stat-num"><?php echo count($services); ?></div>
            <div class="stat-label">Total services</div>
        </div>
        <div class="stat-item">
            <div class="stat-num">
                <?php
                    $prices = array_filter(array_column($services, 'Price'));
                    echo count($prices) > 0 ? number_format(array_sum($prices) / count($prices), 0) . ' DA' : '—';
                ?>
            </div>
            <div class="stat-label">Prix moyen</div>
        </div>
        <div class="stat-item">
            <div class="stat-num">
                <?php
                    $ratings = array_filter(array_column($services, 'Rating'));
                    echo count($ratings) > 0 ? number_format(array_sum($ratings) / count($ratings), 1) . ' ★' : '—';
                ?>
            </div>
            <div class="stat-label">Note moyenne</div>
        </div>
        <div class="stat-item">
            <div class="stat-num"><?php echo count(array_unique(array_filter(array_column($services, 'Category')))); ?></div>
            <div class="stat-label">Catégories</div>
        </div>
    </div>

 
    <div class="card">
        <div class="card-title"><i class="fas fa-plus-circle"></i> Ajouter un nouveau service</div>
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="addService">

            <div class="form-row">
                <div class="form-group">
                    <label>Titre du service *</label>
                    <input type="text" name="title" class="form-field" placeholder="Ex: Réparation de fuite d'eau" required>
                </div>
                <div class="form-group">
                    <label>Catégorie *</label>
                    <select name="category" class="form-field" required>
                        <option value="">Sélectionner</option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?php echo $cat; ?>"><?php echo $cat; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label>Description</label>
                <textarea name="description" class="form-field" rows="3" placeholder="Décrivez votre service en détail..."></textarea>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Prix (DA)</label>
                    <input type="number" name="price" class="form-field" min="0" step="100" placeholder="Ex: 3000">
                </div>
                <div class="form-group">
                    <label>Image du service</label>
                    <div class="image-upload-area" id="uploadArea">
                        <input type="file" name="serviceImage" id="serviceImageInput" accept="image/*">
                        <i class="fas fa-cloud-upload-alt"></i>
                        <p><strong>Cliquez</strong> pour uploader une image</p>
                        <p>JPG, PNG, WEBP — max 5 Mo</p>
                    </div>
                    <div id="imagePreview">
                        <img id="previewImg" src="" alt="Aperçu">
                    </div>
                </div>
            </div>

            <button type="submit" class="btn-submit">
                <i class="fas fa-plus"></i> Publier le service
            </button>
        </form>
    </div>

 
    <div class="card">
        <div class="card-title">
            <i class="fas fa-th-large"></i> Mes services publiés
            <span style="background:#fff7ed; color:#f97316; font-size:0.8rem; padding:2px 10px; border-radius:999px; margin-left:auto;">
                <?php echo count($services); ?>
            </span>
        </div>

 
        <?php if (!empty($services)): ?>
        <div class="filter-bar" id="filterBar">
            <button class="filter-btn active" onclick="filterServices('all', this)">Tous</button>
            <?php
                $usedCats = array_unique(array_filter(array_column($services, 'Category')));
                foreach ($usedCats as $cat):
            ?>
                <button class="filter-btn" onclick="filterServices('<?php echo htmlspecialchars($cat); ?>', this)">
                    <?php echo htmlspecialchars($cat); ?>
                </button>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <?php if (empty($services)): ?>
            <div class="empty-placeholder">
                <i class="fas fa-briefcase"></i>
                <h2>Aucun service publié</h2>
                <p>Commencez par ajouter votre premier service ci-dessus</p>
            </div>
        <?php else: ?>
            <div class="services-grid" id="servicesGrid">
                <?php foreach ($services as $svc): ?>
<div class="service-card" data-category="<?php echo htmlspecialchars($svc['Category'] ?? ''); ?>" onclick="window.location='service-detail.php?id=<?php echo $svc['ServiceID']; ?>'" style="cursor:pointer;">
                   

 
                    <?php if (!empty($svc['ImageURL'])): ?>
                        <img src="<?php echo $svc['ImageURL']; ?>" alt="<?php echo htmlspecialchars($svc['Title']); ?>" class="service-img">
                    <?php else: ?>
                        <div class="service-img-placeholder">
                            <i class="fas fa-image"></i>
                            <span>Aucune image</span>
                        </div>
                    <?php endif; ?>

                    <div class="service-body">
                        <?php if (!empty($svc['Category'])): ?>
                            <span class="service-category"><?php echo htmlspecialchars($svc['Category']); ?></span>
                        <?php endif; ?>

                        <div class="service-title"><?php echo htmlspecialchars($svc['Title']); ?></div>

                        <?php if (!empty($svc['Description'])): ?>
                            <div class="service-desc"><?php echo htmlspecialchars($svc['Description']); ?></div>
                        <?php endif; ?>

                        <div class="service-footer">
                            <div class="service-price">
                                <?php echo $svc['Price'] > 0 ? number_format($svc['Price'], 0, ',', ' ') . ' DA' : 'Sur devis'; ?>
                                <?php if ($svc['Price'] > 0): ?><span> / intervention</span><?php endif; ?>
                            </div>
                            <?php if (!empty($svc['Rating'])): ?>
                                <div class="service-rating">
                                    <i class="fas fa-star"></i>
                                    <?php echo number_format($svc['Rating'], 1); ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <?php if (!empty($svc['CreatedAt'])): ?>
                            <div class="service-date">
                                <i class="far fa-calendar-alt"></i>
                                Publié le <?php echo date('d/m/Y', strtotime($svc['CreatedAt'])); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

</div>

<script>
     
    document.getElementById('serviceImageInput').addEventListener('change', function() {
        const file = this.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (e) => {
            document.getElementById('previewImg').src = e.target.result;
            document.getElementById('imagePreview').style.display = 'block';
        };
        reader.readAsDataURL(file);
    });

     
    function filterServices(category, btn) {
        document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        document.querySelectorAll('.service-card').forEach(card => {
            if (category === 'all' || card.dataset.category === category) {
                card.style.display = '';
            } else {
                card.style.display = 'none';
            }
        });
    }
</script>
</body>
</html>