<?php
session_start();

$host = 'localhost';
$dbname = 'anis';
$username_db = 'root';
$password_db = '';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    if (empty($username) || empty($password)) {
        $_SESSION['login_error'] = "Veuillez remplir tous les champs.";
        header("Location: index1.php");
        exit();
    }

    $stmt = $pdo->prepare("SELECT * FROM Users WHERE Username = :username");
    $stmt->execute(['username' => $username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['PasswordHash'])) {

        $_SESSION['user_id']  = $user['UserID'];
        $_SESSION['username'] = $user['Username'];
        $_SESSION['role']     = $user['Role'];

        $logStmt = $pdo->prepare("INSERT INTO ActivityLogs (UserID, Action) VALUES (:userID, :action)");
        $logStmt->execute([
            'userID' => $user['UserID'],
            'action' => 'login'
        ]);

        if ($user['Role'] === 'Artisan') {
            header("Location: profile.php");
            exit();
        } elseif ($user['Role'] === 'Client') {
            header("Location: profile.php");
            exit();
        }

    } else {

        if ($user) {
            $logStmt = $pdo->prepare("INSERT INTO ActivityLogs (UserID, Action) VALUES (:userID, :action)");
            $logStmt->execute([
                'userID' => $user['UserID'],
                'action' => 'login_failed'
            ]);
        }

        $_SESSION['login_error'] = "Nom d'utilisateur ou mot de passe incorrect.";
        header("Location: index1.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="fr" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion - Système de Gestion des Employés</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>👷</text></svg">
</head>
<body>
    <div class="container">
        <div class="login-container">
            <div class="login-form">
                <div class="card">
                    <div class="card-header">
                        <h2 style="color:black"><i class="fas fa-sign-in-alt"></i> Connexion</h2>
                        <p style="opacity: 0.9; margin-top: 10px; color:black">Connectez-vous pour piloter vos projets et vos équipes</p>
                    </div>
                    
                    <div class="card-body">
                        <form id="loginForm" method="POST" action="index1.php">
                            <div id="loginMessage">
                                <?php
                                if (isset($_SESSION['login_error'])) {
                                    echo '<div class="message info">' . htmlspecialchars($_SESSION['login_error']) . '</div>';
                                    unset($_SESSION['login_error']);
                                }
                                ?>
                            </div>
                            
                            <div class="form-group">
                                <label for="username" class="form-label">
                                    <i class="fas fa-user-hard-hat"></i> Nom d'utilisateur
                                </label>
                                <input type="text" id="username" name="username" class="form-control" 
                                       placeholder="Entrer votre nom d'utilisateur" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="password" class="form-label">
                                    <i class="fas fa-lock"></i> Mot de passe
                                </label>
                                <div class="input-group">
                                    <input type="password" id="password" name="password" class="form-control" 
                                           placeholder="Entrer votre mot de passe" required>
                                    <button type="button" id="togglePassword" class="toggle-password">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                            
                            <div class="checkbox-group">
                                <input type="checkbox" id="rememberMe">
                                <label for="rememberMe">Se souvenir de moi</label>
                            </div>
                            
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-sign-in-alt"></i> Se connecter
                            </button>
                            
                            <div class="divider">
                                <span>Ou</span>
                            </div>
                            
                            <div style="text-align: center; margin-top: 25px;">
                                <p style="color: var(--text-light); margin-bottom: 15px;">
                                    Vous n'avez pas de compte ?
                                    <a href="register.php" class="link">Créer un compte</a>
                                </p>
                                <a href="forgot-password.html" class="link" style="font-size: 14px;">
                                    <i class="fas fa-key"></i> Mot de passe oublié ?
                                </a>
                                <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid var(--bg-gray);">
                                    <a href="Home.php" class="link">
                                        <i class="fas fa-home"></i> Retour à l'accueil
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <div style="margin-top: 30px; text-align: center; display:none">
                    <div class="message info">
                        <i class="fas fa-info-circle"></i>
                        <span>Données de test</span>
                    </div>
                </div>
            </div>
            
            <div class="login-info">
                <div class="login-info-content">
                    <h2 style="color:black">Plateforme Numérique pour la Gestion des Artisans et Suivi des Tâches</h2>
                    <p style="color:black">Innovons ensemble la gestion de vos métiers et le suivi de vos équipes
</p>
                    
                    <ul class="features-list">
                        <li>
                            <i class="fas fa-shield-alt"></i>
                            <div>
                                <a href="privacy.html" style="color:black">
                                    <strong>Système de Sécurité Avancé</strong>
                                    <p style="color:black">Protection de vos données selon les plus hauts standards de sécurité</p>
                                </a>
                            </div>
                        </li>
                        <li>
                            <i class="fas fa-mobile-alt"></i>
                            <div>
                                <a href="compatibility.html" style="color:black">
                                    <strong>Compatible avec tous les appareils</strong>
                                    <p style="color:black">Compatible avec ordinateurs, tablettes et smartphones</p>
                                </a>
                            </div>
                        </li>
                    </ul>
                    
                    <div style="margin-top: 40px; padding: 20px; background: rgba(255, 255, 255, 0.1); border-radius: var(--radius-md);">
                        <h3 style="margin-bottom: 15px; font-size: 18px; color:black;">
                            <i class="fas fa-lightbulb"></i> Conseils de sécurité
                        </h3>
                        <ul style="list-style: none; font-size: 14px; opacity: 0.9;">
                            <li style="margin-bottom: 8px; color:black;">• Utilisez des mots de passe robustes</li>
                            <li style="margin-bottom: 8px; color:black;">• Ne partagez jamais vos identifiants avec des tiers</li>
                            <li style="margin-bottom: 8px; color:black;">• Déconnectez-vous après chaque utilisation</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="app.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        togglePasswordVisibility('password', 'togglePassword');
    });
</script>
</body>
</html>