<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: index1.php"); exit();
}

$host = 'localhost'; $dbname = 'anis'; $dbuser = 'root'; $dbpass = '';
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $dbuser, $dbpass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) { die("DB error"); }

$userID   = $_SESSION['user_id'];
$userRole = $_SESSION['role'] ?? '';

 
$uStmt = $pdo->prepare("SELECT FullName, ProfilePictureURL FROM Users WHERE UserID=:uid");
$uStmt->execute(['uid'=>$userID]);
$userData = $uStmt->fetch(PDO::FETCH_ASSOC);

$success = $error = '';

 
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'cancelDevis') {
    $devisID = intval($_POST['devis_id']);
    $pdo->prepare("DELETE FROM DevisRequests WHERE DevisID=:did AND ClientUserID=:uid AND Status='pending'")
        ->execute(['did'=>$devisID,'uid'=>$userID]);
    $success = "Demande annulée.";
}

 
$filterStatus = $_GET['status'] ?? 'all';
$validStatuses = ['all','pending','accepted','refused','completed'];
if (!in_array($filterStatus, $validStatuses)) $filterStatus = 'all';

$whereClause = "WHERE d.ClientUserID = :uid";
$params = ['uid' => $userID];
if ($filterStatus !== 'all') {
    $whereClause .= " AND d.Status = :st";
    $params['st'] = $filterStatus;
}

$dStmt = $pdo->prepare("
    SELECT d.*,
           s.Title AS ServiceTitle, s.Category AS ServiceCategory, s.ImageURL AS ServiceImage,
           s.ServiceID,
           u.FullName AS ArtisanName, u.ProfilePictureURL AS ArtisanPhoto,
           a.State AS ArtisanState, a.Specialty AS ArtisanSpecialty
    FROM DevisRequests d
    JOIN Services s ON d.ServiceID = s.ServiceID
    JOIN Artisans a ON d.ArtisanID = a.ArtisanID
    JOIN Users u ON a.UserID = u.UserID
    $whereClause
    ORDER BY d.CreatedAt DESC
");
$dStmt->execute($params);
$requests = $dStmt->fetchAll(PDO::FETCH_ASSOC);

 
$statsStmt = $pdo->prepare("SELECT Status, COUNT(*) as cnt FROM DevisRequests WHERE ClientUserID=:uid GROUP BY Status");
$statsStmt->execute(['uid'=>$userID]);
$stats = ['pending'=>0,'accepted'=>0,'refused'=>0,'completed'=>0];
foreach ($statsStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $stats[$row['Status']] = $row['cnt'];
}
$totalRequests = array_sum($stats);

$statusConfig = [
    'pending'   => ['label'=>'En attente',  'color'=>'#f59e0b', 'bg'=>'#fffbeb', 'border'=>'#fde68a', 'icon'=>'fas fa-clock',
                    'msg' => "L'artisan n'a pas encore répondu."],
    'accepted'  => ['label'=>'Accepté',     'color'=>'#10b981', 'bg'=>'#ecfdf5', 'border'=>'#a7f3d0', 'icon'=>'fas fa-check-circle',
                    'msg' => "L'artisan a accepté votre demande !"],
    'refused'   => ['label'=>'Refusé',      'color'=>'#ef4444', 'bg'=>'#fef2f2', 'border'=>'#fca5a5', 'icon'=>'fas fa-times-circle',
                    'msg' => "L'artisan n'est pas disponible pour cette demande."],
    'completed' => ['label'=>'Terminé',     'color'=>'#3b66f5', 'bg'=>'#eef2ff', 'border'=>'#c3d0ff', 'icon'=>'fas fa-flag-checkered',
                    'msg' => "Le travail est terminé."],
];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mes Demandes — Services Artisans</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }
        :root {
            --primary: #1e3a5f; --accent: #3b66f5; --accent2: #f97316;
            --success: #10b981; --danger: #ef4444;
            --bg: #f4f7fe; --white: #fff; --text: #1a202c;
            --muted: #718096; --border: #e2e8f0;
            --radius: 14px; --shadow: 0 4px 24px rgba(0,0,0,0.07);
        }
        body { font-family: 'Cairo', sans-serif; background: var(--bg); color: var(--text); }

 
        .nav { background: var(--white); padding: 0 5%; position: sticky; top: 0; z-index: 100; box-shadow: 0 2px 16px rgba(0,0,0,0.06); }
        .nav-inner { max-width: 1300px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; height: 70px; gap: 1.5rem; }
        .nav-brand { font-size: 1.5rem; font-weight: 900; color: var(--accent); text-decoration: none; white-space: nowrap; }
        .nav-brand span { color: var(--accent2); }
        .nav-links { display: flex; gap: 0.5rem; align-items: center; }
        .nav-links a { color: var(--muted); text-decoration: none; font-weight: 600; font-size: 0.88rem; padding: 0.45rem 0.9rem; border-radius: 999px; transition: all 0.2s; display: flex; align-items: center; gap: 0.4rem; }
        .nav-links a:hover, .nav-links a.active { background: #eef2ff; color: var(--accent); }
        .user-chip { display: flex; align-items: center; gap: 0.5rem; background: var(--bg); border: 1.5px solid var(--border); border-radius: 999px; padding: 0.3rem 1rem 0.3rem 0.3rem; text-decoration: none; color: var(--text); font-weight: 600; font-size: 0.85rem; }
        .user-avatar { width: 30px; height: 30px; border-radius: 50%; background: linear-gradient(135deg,var(--accent),#6c8fff); display: flex; align-items: center; justify-content: center; color: white; font-size: 0.8rem; font-weight: 700; overflow: hidden; flex-shrink: 0; }
        .user-avatar img { width: 100%; height: 100%; object-fit: cover; }

 
        .page-header { background: linear-gradient(135deg, #2d4f7c, var(--accent)); padding: 2.5rem 5%; color: white; }
        .page-header-inner { max-width: 1300px; margin: 0 auto; }
        .page-header h1 { font-size: 1.75rem; font-weight: 900; margin-bottom: 0.3rem; display: flex; align-items: center; gap: 0.7rem; }
        .page-header p { opacity: 0.75; font-size: 0.95rem; }

 
        .stats-row { max-width: 1300px; margin: -1.5rem auto 2rem; padding: 0 5%; display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; position: relative; z-index: 2; }
        .stat-card { background: white; border-radius: var(--radius); padding: 1.25rem 1rem; text-align: center; box-shadow: var(--shadow); border: 1.5px solid var(--border); cursor: pointer; transition: transform 0.2s; text-decoration: none; display: block; }
        .stat-card:hover { transform: translateY(-3px); }
        .stat-card.active { border-color: var(--accent); background: #eef2ff; }
        .stat-icon { font-size: 1.4rem; margin-bottom: 0.4rem; }
        .stat-num { font-size: 1.9rem; font-weight: 900; line-height: 1; }
        .stat-label { font-size: 0.78rem; color: var(--muted); margin-top: 3px; font-weight: 600; }

 
        .main-content { max-width: 1300px; margin: 0 auto; padding: 0 5% 4rem; }
        .section-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 0.5rem; }
        .section-title { font-size: 1.1rem; font-weight: 800; color: var(--primary); }
        .results-count { font-size: 0.88rem; color: var(--muted); }

 
        .requests-list { display: flex; flex-direction: column; gap: 1.5rem; }
        .request-card { background: white; border-radius: 18px; border: 1.5px solid var(--border); box-shadow: var(--shadow); overflow: hidden; }
        .request-card.pending   { border-left: 4px solid #f59e0b; }
        .request-card.accepted  { border-left: 4px solid #10b981; }
        .request-card.refused   { border-left: 4px solid #ef4444; }
        .request-card.completed { border-left: 4px solid #3b66f5; }

 
        .svc-banner { display: flex; align-items: center; gap: 1rem; padding: 1.1rem 1.5rem; background: var(--bg); border-bottom: 1px solid var(--border); }
        .svc-thumb { width: 56px; height: 56px; border-radius: 10px; object-fit: cover; background: linear-gradient(135deg,#eef2ff,#e0e7ff); display: flex; align-items: center; justify-content: center; color: #a5b4fc; font-size: 1.4rem; flex-shrink: 0; overflow: hidden; }
        .svc-thumb img { width: 100%; height: 100%; object-fit: cover; }
        .svc-info { flex: 1; min-width: 0; }
        .svc-title { font-weight: 700; color: var(--primary); font-size: 0.98rem; }
        .svc-cat { font-size: 0.78rem; color: var(--muted); margin-top: 2px; }
        .view-svc-link { color: var(--accent); font-size: 0.82rem; font-weight: 600; text-decoration: none; white-space: nowrap; display: flex; align-items: center; gap: 0.3rem; }
        .view-svc-link:hover { text-decoration: underline; }

 
        .card-body { padding: 1.25rem 1.5rem; }

 
        .artisan-row { display: flex; align-items: center; gap: 0.75rem; margin-bottom: 1rem; padding-bottom: 1rem; border-bottom: 1px solid #f0f4ff; }
        .artisan-avatar { width: 40px; height: 40px; border-radius: 50%; background: linear-gradient(135deg,var(--accent),#6c8fff); display: flex; align-items: center; justify-content: center; color: white; font-weight: 700; overflow: hidden; flex-shrink: 0; }
        .artisan-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .artisan-name { font-weight: 700; font-size: 0.95rem; }
        .artisan-meta { font-size: 0.78rem; color: var(--muted); display: flex; gap: 0.6rem; margin-top: 2px; }
        .status-badge { margin-left: auto; display: inline-flex; align-items: center; gap: 0.35rem; padding: 0.3rem 0.9rem; border-radius: 999px; font-size: 0.78rem; font-weight: 700; }

 
        .details-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 0.75rem; margin-bottom: 1rem; }
        .detail-item { background: var(--bg); border-radius: 10px; padding: 0.7rem 0.9rem; }
        .detail-label { font-size: 0.7rem; font-weight: 700; color: var(--muted); text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 3px; }
        .detail-value { font-size: 0.88rem; font-weight: 600; color: var(--text); }

        .desc-box { background: var(--bg); border-radius: 10px; padding: 0.8rem 1rem; margin-bottom: 1rem; }
        .desc-box .detail-label { margin-bottom: 4px; }
        .desc-box p { font-size: 0.88rem; color: #4a5568; line-height: 1.7; }

 
        .artisan-response { border-radius: 12px; padding: 1rem 1.25rem; margin-bottom: 1rem; }
        .artisan-response .resp-head { font-size: 0.8rem; font-weight: 700; display: flex; align-items: center; gap: 0.4rem; margin-bottom: 5px; }
        .artisan-response p { font-size: 0.9rem; line-height: 1.7; }
        .resp-accepted { background: #ecfdf5; border: 1.5px solid #a7f3d0; }
        .resp-accepted .resp-head, .resp-accepted p { color: #065f46; }
        .resp-refused  { background: #fef2f2; border: 1.5px solid #fca5a5; }
        .resp-refused .resp-head, .resp-refused p  { color: #991b1b; }
        .resp-completed { background: #eef2ff; border: 1.5px solid #c3d0ff; }
        .resp-completed .resp-head, .resp-completed p { color: #1e40af; }
        .resp-pending { background: #fffbeb; border: 1.5px dashed #fde68a; }
        .resp-pending .resp-head, .resp-pending p { color: #92400e; }

 
        .btn-cancel-req { background: none; border: 1.5px solid #fca5a5; color: #ef4444; padding: 0.5rem 1.1rem; border-radius: 8px; font-family: 'Cairo',sans-serif; font-size: 0.85rem; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 0.4rem; transition: all 0.2s; }
        .btn-cancel-req:hover { background: #fef2f2; }

 
        .msg { padding: 1rem 1.25rem; border-radius: 12px; display: flex; align-items: center; gap: 0.75rem; font-weight: 500; margin-bottom: 1.5rem; }
        .msg.success { background: #d1fae5; color: #065f46; }
        .msg.error   { background: #fee2e2; color: #991b1b; }

 
        .empty-state { text-align: center; padding: 5rem 2rem; }
        .empty-state i { font-size: 4rem; color: #c3d0ff; display: block; margin-bottom: 1.25rem; }
        .empty-state h3 { font-size: 1.2rem; font-weight: 700; color: var(--primary); margin-bottom: 0.5rem; }
        .empty-state p { color: var(--muted); font-size: 0.9rem; margin-bottom: 1.5rem; }
        .btn-browse { display: inline-flex; align-items: center; gap: 0.5rem; background: linear-gradient(135deg,var(--accent),#6c8fff); color: white; padding: 0.75rem 1.75rem; border-radius: 999px; font-weight: 700; text-decoration: none; font-size: 0.95rem; transition: opacity 0.2s; }
        .btn-browse:hover { opacity: 0.9; }

        @media (max-width: 600px) {
            .svc-banner { flex-wrap: wrap; }
            .details-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

 
<nav class="nav">
    <div class="nav-inner">
                 <a href="Home.php" class="nav-brand">  <i class="fas fa-screwdriver-wrench" style="color:#3b66f5; margin-right:8px;"></i>Services <span>Artisans</span></a>

        <div class="nav-links">
            <a href="Home.php"><i class="fas fa-home"></i> Accueil</a>
            <a href="search-results.php"><i class="fas fa-search"></i> Recherche</a>
            <a href="mes-demandes.php" class="active"><i class="fas fa-file-alt"></i> Mes demandes</a>
            <a href="profile.php" class="user-chip">
                <div class="user-avatar">
                    <?php if (!empty($userData['ProfilePictureURL'])): ?>
                        <img src="data:image/jpeg;base64,<?php echo $userData['ProfilePictureURL']; ?>" alt="">
                    <?php else: ?>
                        <?php echo strtoupper(substr($userData['FullName']??'U',0,1)); ?>
                    <?php endif; ?>
                </div>
                <?php echo htmlspecialchars($userData['FullName'] ?? 'Mon compte'); ?>
            </a>
        </div>
    </div>
</nav>

 
<div class="page-header">
    <div class="page-header-inner">
        <h1><i class="fas fa-file-alt"></i> Mes demandes de devis</h1>
        <p>Suivez l'état de vos demandes envoyées aux artisans</p>
    </div>
</div>

 
<div class="stats-row">
    <a href="?status=all" class="stat-card <?php echo $filterStatus==='all'?'active':''; ?>">
        <div class="stat-icon" style="color:var(--accent);">📋</div>
        <div class="stat-num" style="color:var(--accent);"><?php echo $totalRequests; ?></div>
        <div class="stat-label">Total</div>
    </a>
    <?php foreach ($statusConfig as $sk => $sc): ?>
    <a href="?status=<?php echo $sk; ?>" class="stat-card <?php echo $filterStatus===$sk?'active':''; ?>">
        <div class="stat-icon"><i class="<?php echo $sc['icon']; ?>" style="color:<?php echo $sc['color']; ?>;"></i></div>
        <div class="stat-num" style="color:<?php echo $sc['color']; ?>;"><?php echo $stats[$sk]; ?></div>
        <div class="stat-label"><?php echo $sc['label']; ?></div>
    </a>
    <?php endforeach; ?>
</div>

 
<div class="main-content">

    <?php if ($success): ?>
        <div class="msg success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="msg error"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <div class="section-bar">
        <div class="section-title">
            <?php echo $filterStatus==='all' ? 'Toutes mes demandes' : ('Demandes : '.$statusConfig[$filterStatus]['label']); ?>
        </div>
        <div class="results-count"><?php echo count($requests); ?> demande<?php echo count($requests)!==1?'s':''; ?></div>
    </div>

    <?php if (empty($requests)): ?>
    <div class="empty-state">
        <i class="fas fa-file-alt"></i>
        <h3>Aucune demande<?php echo $filterStatus!=='all'?' '.$statusConfig[$filterStatus]['label']:''; ?></h3>
        <p>Vous n'avez pas encore envoyé de demande de devis.<br>Parcourez les services disponibles pour en trouver un.</p>
        <a href="search-results.php" class="btn-browse"><i class="fas fa-search"></i> Parcourir les services</a>
    </div>
    <?php else: ?>
    <div class="requests-list">
        <?php foreach ($requests as $req): ?>
        <?php $sc = $statusConfig[$req['Status']]; ?>
        <div class="request-card <?php echo $req['Status']; ?>">

 
            <div class="svc-banner">
                <div class="svc-thumb">
                    <?php if (!empty($req['ServiceImage'])): ?>
                        <img src="<?php echo $req['ServiceImage']; ?>" alt="">
                    <?php else: ?>
                        <i class="fas fa-briefcase"></i>
                    <?php endif; ?>
                </div>
                <div class="svc-info">
                    <div class="svc-title"><?php echo htmlspecialchars($req['ServiceTitle']); ?></div>
                    <div class="svc-cat"><i class="fas fa-tag" style="color:var(--accent);"></i> <?php echo htmlspecialchars($req['ServiceCategory']??''); ?></div>
                </div>
                <a href="service-detail.php?id=<?php echo $req['ServiceID']; ?>" class="view-svc-link">
                    Voir le service <i class="fas fa-arrow-right"></i>
                </a>
            </div>

            <div class="card-body">
 
                <div class="artisan-row">
                    <div class="artisan-avatar">
                        <?php if (!empty($req['ArtisanPhoto'])): ?>
                            <img src="data:image/jpeg;base64,<?php echo $req['ArtisanPhoto']; ?>" alt="">
                        <?php else: ?>
                            <?php echo strtoupper(substr($req['ArtisanName'],0,1)); ?>
                        <?php endif; ?>
                    </div>
                    <div>
                        <div class="artisan-name"><?php echo htmlspecialchars($req['ArtisanName']); ?></div>
                        <div class="artisan-meta">
                            <?php if (!empty($req['ArtisanState'])): ?>
                            <span><i class="fas fa-map-marker-alt" style="color:#f97316;"></i> <?php echo htmlspecialchars($req['ArtisanState']); ?></span>
                            <?php endif; ?>
                            <span><i class="far fa-calendar-alt"></i> Envoyée le <?php echo date('d/m/Y', strtotime($req['CreatedAt'])); ?></span>
                        </div>
                    </div>
                    <span class="status-badge"
                        style="background:<?php echo $sc['bg']; ?>;color:<?php echo $sc['color']; ?>;border:1px solid <?php echo $sc['border']; ?>;">
                        <i class="<?php echo $sc['icon']; ?>"></i> <?php echo $sc['label']; ?>
                    </span>
                </div>

 
                <div class="details-grid">
                    <div class="detail-item">
                        <div class="detail-label"><i class="fas fa-map-marker-alt" style="color:#f97316;"></i> Wilaya</div>
                        <div class="detail-value"><?php echo htmlspecialchars($req['Wilaya']); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label"><i class="fas fa-calendar" style="color:#3b66f5;"></i> Date souhaitée</div>
                        <div class="detail-value"><?php echo date('d/m/Y', strtotime($req['PreferredDate'])); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label"><i class="fas fa-phone" style="color:#10b981;"></i> Téléphone fourni</div>
                        <div class="detail-value"><?php echo htmlspecialchars($req['PhoneNumber']); ?></div>
                    </div>
                </div>

 
                <div class="desc-box">
                    <div class="detail-label"><i class="fas fa-align-left"></i> Votre description</div>
                    <p><?php echo nl2br(htmlspecialchars($req['Description'])); ?></p>
                </div>

 
                <?php
                $respClass = 'resp-'.$req['Status'];
                if ($req['ArtisanResponse']): ?>
                <div class="artisan-response <?php echo $respClass; ?>">
                    <div class="resp-head">
                        <i class="<?php echo $sc['icon']; ?>"></i>
                        Réponse de l'artisan
                        <?php if ($req['RespondedAt']): ?>
                            — <?php echo date('d/m/Y', strtotime($req['RespondedAt'])); ?>
                        <?php endif; ?>
                    </div>
                    <p><?php echo nl2br(htmlspecialchars($req['ArtisanResponse'])); ?></p>
                </div>
                <?php else: ?>
                <div class="artisan-response resp-pending">
                    <div class="resp-head"><i class="fas fa-clock"></i> Statut</div>
                    <p><?php echo $sc['msg']; ?></p>
                </div>
                <?php endif; ?>

 
                <?php if ($req['Status'] === 'pending'): ?>
                <form method="POST" onsubmit="return confirm('Annuler cette demande ?');">
                    <input type="hidden" name="action" value="cancelDevis">
                    <input type="hidden" name="devis_id" value="<?php echo $req['DevisID']; ?>">
                    <button type="submit" class="btn-cancel-req"><i class="fas fa-times"></i> Annuler la demande</button>
                </form>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

</body>
</html>