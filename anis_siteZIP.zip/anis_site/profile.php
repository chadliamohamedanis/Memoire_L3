<?php
session_start();

if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    header("Location: index1.php");
    exit();
}

$host     = 'localhost';
$dbname   = 'anis';
$username = 'root';
$password = '';

ini_set('display_errors', 1);
error_reporting(E_ALL);

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

$userID   = $_SESSION['user_id'];
$userRole = $_SESSION['role'];

$stmt = $pdo->prepare("SELECT * FROM Users WHERE UserID = :uid");
$stmt->execute(['uid' => $userID]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) { session_destroy(); header("Location: index1.php"); exit(); }

$artisanData = null;
if ($userRole === 'Artisan') {
    $stmt = $pdo->prepare("SELECT * FROM Artisans WHERE UserID = :uid");
    $stmt->execute(['uid' => $userID]);
    $artisanData = $stmt->fetch(PDO::FETCH_ASSOC);
}

 
$serviceCount  = 0;
$reviewCount   = 0;
$employeeCount = 0;
if ($userRole === 'Artisan' && $artisanData) {
    $serviceCount  = $pdo->prepare("SELECT COUNT(*) FROM Services WHERE ArtisanID = :aid");
    $serviceCount->execute(['aid' => $artisanData['ArtisanID']]);
    $serviceCount  = $serviceCount->fetchColumn();

    $reviewCount = $pdo->prepare("SELECT COUNT(*) FROM ServiceReviews sr JOIN Services s ON sr.ServiceID=s.ServiceID WHERE s.ArtisanID=:aid");
    $reviewCount->execute(['aid' => $artisanData['ArtisanID']]);
    $reviewCount = $reviewCount->fetchColumn();

    $employeeCount = $pdo->prepare("SELECT COUNT(*) FROM Employees WHERE ArtisanID = :aid");
    $employeeCount->execute(['aid' => $artisanData['ArtisanID']]);
    $employeeCount = $employeeCount->fetchColumn();
}

$success = $error = '';

 
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'uploadPhoto') {
    if (!empty($_FILES['profilePhoto']['name'])) {
        $ext = strtolower(pathinfo($_FILES['profilePhoto']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg','jpeg','png','gif']) && $_FILES['profilePhoto']['size'] <= 5*1024*1024) {
            $b64 = base64_encode(file_get_contents($_FILES['profilePhoto']['tmp_name']));
            $pdo->prepare("UPDATE Users SET ProfilePictureURL=:p WHERE UserID=:uid")->execute(['p'=>$b64,'uid'=>$userID]);
            $_SESSION['success_message'] = "Photo mise à jour !";
            header("Location: profile.php"); exit();
        } else {
            $_SESSION['error_message'] = "Format invalide ou fichier trop lourd (max 5 Mo).";
        }
    }
}

 
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'updateProfile') {
    $fullName = trim($_POST['fullName']);
    $email    = trim($_POST['email']);
    $phone    = trim($_POST['phone']);
    $errs     = [];
    if (empty($fullName)||empty($email)||empty($phone)) $errs[] = "Tous les champs sont requis.";
    if (!filter_var($email, FILTER_VALIDATE_EMAIL))     $errs[] = "Email invalide.";
    $chk = $pdo->prepare("SELECT COUNT(*) FROM Users WHERE Email=:e AND UserID!=:uid");
    $chk->execute(['e'=>$email,'uid'=>$userID]);
    if ($chk->fetchColumn()) $errs[] = "Email déjà utilisé.";

    if (empty($errs)) {
        $pdo->prepare("UPDATE Users SET FullName=:n,Email=:e,PhoneNumber=:p WHERE UserID=:uid")
            ->execute(['n'=>$fullName,'e'=>$email,'p'=>$phone,'uid'=>$userID]);
        if ($userRole==='Artisan' && $artisanData) {
            $pdo->prepare("UPDATE Artisans SET Specialty=:sp,State=:st,Municipality=:mu,DetailedAddress=:ad,YearsOfExperience=:yr WHERE UserID=:uid")
                ->execute(['sp'=>$_POST['specialty']??null,'st'=>$_POST['wilaya']??null,'mu'=>$_POST['municipality']??null,'ad'=>$_POST['address']??null,'yr'=>intval($_POST['experience']??0),'uid'=>$userID]);
        }
        $_SESSION['success_message'] = "Profil mis à jour avec succès !";
        header("Location: profile.php"); exit();
    } else {
        $_SESSION['error_message'] = implode('<br>', $errs);
    }
}

 
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'changePassword') {
    $cur  = $_POST['currentPassword'];
    $new  = $_POST['newPassword'];
    $conf = $_POST['confirmPassword'];
    $errs = [];
    if (!password_verify($cur, $user['PasswordHash'])) $errs[] = "Mot de passe actuel incorrect.";
    if (strlen($new) < 6)                              $errs[] = "Minimum 6 caractères.";
    if ($new !== $conf)                                 $errs[] = "Les mots de passe ne correspondent pas.";
    if (empty($errs)) {
        $pdo->prepare("UPDATE Users SET PasswordHash=:h WHERE UserID=:uid")->execute(['h'=>password_hash($new,PASSWORD_BCRYPT),'uid'=>$userID]);
        $_SESSION['success_message'] = "Mot de passe modifié !";
        header("Location: profile.php"); exit();
    } else {
        $_SESSION['error_message'] = implode('<br>', $errs);
    }
}

 
if (isset($_GET['logout'])) {
    try {
        $pdo->prepare("INSERT INTO ActivityLogs (UserID,Action) VALUES (:uid,'logout')")->execute(['uid'=>$userID]);
    } catch(Exception $e) {}
    session_destroy();
    header("Location: Home.php"); exit();
}

$successMsg = $_SESSION['success_message'] ?? '';
$errorMsg   = $_SESSION['error_message']   ?? '';
unset($_SESSION['success_message'], $_SESSION['error_message']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mon Profil — Services Artisans</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }

        :root {
            --primary:   #1e3a5f;
            --accent:    #3b66f5;
            --accent2:   #f97316;
            --success:   #10b981;
            --danger:    #ef4444;
            --bg:        #f4f7fe;
            --white:     #ffffff;
            --text:      #1a202c;
            --muted:     #718096;
            --border:    #e2e8f0;
            --radius:    14px;
            --shadow:    0 4px 24px rgba(0,0,0,0.07);
            --shadow-lg: 0 12px 40px rgba(0,0,0,0.12);
        }

        body { font-family: 'Cairo', sans-serif; background: var(--bg); color: var(--text); }

 
        .nav { background: var(--white); padding: 0 5%; position: sticky; top: 0; z-index: 100; box-shadow: 0 2px 16px rgba(0,0,0,0.06); }
        .nav-inner { max-width: 1300px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; height: 70px; gap: 2rem; }
        .nav-brand { font-size: 1.5rem; font-weight: 900; color: var(--accent); text-decoration: none; letter-spacing: -0.5px; white-space: nowrap; }
        .nav-brand span { color: var(--accent2); }
        .nav-links { display: flex; gap: 0.5rem; align-items: center; }
        .nav-links a { color: var(--muted); text-decoration: none; font-weight: 600; font-size: 0.9rem; padding: 0.5rem 0.9rem; border-radius: 999px; transition: all 0.2s; display: flex; align-items: center; gap: 0.4rem; }
        .nav-links a:hover { background: var(--bg); color: var(--accent); }
        .btn-logout-nav { color: var(--muted); font-size: 0.88rem; font-weight: 600; background: none; border: 1.5px solid var(--border); cursor: pointer; font-family: 'Cairo', sans-serif; padding: 0.45rem 1rem; border-radius: 999px; transition: all 0.2s; display: flex; align-items: center; gap: 0.4rem; }
        .btn-logout-nav:hover { color: var(--danger); border-color: var(--danger); background: #fff5f5; }

 
        .profile-cover {
            background: linear-gradient(135deg, var(--primary) 0%, #2d4f7c 60%, #3b66f5 100%);
            height: 220px;
            position: relative;
            overflow: hidden;
        }
        .profile-cover::before {
            content: '';
            position: absolute; inset: 0;
            background: url('https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=1400&q=60') center/cover;
            opacity: 0.12;
        }
        .profile-cover::after {
            content: '';
            position: absolute; bottom: 0; left: 0; right: 0;
            height: 80px;
            background: linear-gradient(to bottom, transparent, var(--bg));
        }

        .avatar-wrap {
            position: relative;
            z-index: 2;
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: -70px;
        }
        .avatar-circle {
            width: 130px; height: 130px;
            border-radius: 50%;
            border: 5px solid white;
            background: linear-gradient(135deg, var(--accent), #6c8fff);
            display: flex; align-items: center; justify-content: center;
            color: white; font-size: 3rem; font-weight: 700;
            overflow: hidden; cursor: pointer;
            box-shadow: 0 8px 32px rgba(59,102,245,0.25);
            transition: transform 0.2s, box-shadow 0.2s;
            position: relative;
        }
        .avatar-circle:hover { transform: scale(1.04); box-shadow: 0 12px 40px rgba(59,102,245,0.35); }
        .avatar-circle img { width: 100%; height: 100%; object-fit: cover; }
        .avatar-overlay {
            position: absolute; inset: 0; border-radius: 50%;
            background: rgba(0,0,0,0.45);
            display: flex; align-items: center; justify-content: center;
            opacity: 0; transition: opacity 0.2s;
            font-size: 1.4rem; color: white;
        }
        .avatar-circle:hover .avatar-overlay { opacity: 1; }

        .profile-name-block {
            text-align: center;
            margin-top: 1rem;
            margin-bottom: 2rem;
        }
        .profile-name-block h1 { font-size: 1.75rem; font-weight: 800; color: var(--text); }
        .role-badge {
            display: inline-flex; align-items: center; gap: 0.4rem;
            margin-top: 0.4rem;
            padding: 0.3rem 1rem;
            border-radius: 999px;
            font-size: 0.82rem; font-weight: 700;
            background: linear-gradient(135deg, var(--accent), #6c8fff);
            color: white;
        }
        .role-badge.client { background: linear-gradient(135deg, var(--success), #059669); }

 
        .stats-bar {
            background: white;
            border-radius: 16px;
            border: 1.5px solid var(--border);
            display: flex;
            justify-content: center;
            gap: 0;
            margin: 0 auto 2rem;
            max-width: 700px;
            overflow: hidden;
            box-shadow: var(--shadow);
        }
        .stat-item {
            flex: 1;
            text-align: center;
            padding: 1.25rem 1rem;
            border-right: 1px solid var(--border);
            transition: background 0.2s;
        }
        .stat-item:last-child { border-right: none; }
        .stat-item:hover { background: var(--bg); }
        .stat-num { font-size: 1.8rem; font-weight: 900; color: var(--accent); line-height: 1; }
        .stat-label { font-size: 0.75rem; color: var(--muted); margin-top: 3px; }

 
        .msg-wrap { max-width: 1100px; margin: 0 auto 1rem; padding: 0 5%; }
        .message { padding: 1rem 1.25rem; border-radius: 12px; display: flex; align-items: center; gap: 0.75rem; font-weight: 500; font-size: 0.95rem; }
        .message.success { background: #d1fae5; color: #065f46; }
        .message.error   { background: #fee2e2; color: #991b1b; }

 
        .page-wrap { max-width: 1100px; margin: 0 auto; padding: 0 5% 5rem; display: grid; grid-template-columns: 1fr 320px; gap: 1.5rem; align-items: start; }

 
        .card { background: white; border-radius: var(--radius); border: 1.5px solid var(--border); padding: 1.75rem; box-shadow: var(--shadow); margin-bottom: 1.5rem; }
        .card:last-child { margin-bottom: 0; }
        .card-title { font-size: 1rem; font-weight: 800; color: var(--primary); margin-bottom: 1.5rem; display: flex; align-items: center; gap: 0.6rem; padding-bottom: 1rem; border-bottom: 2px solid var(--border); }
        .card-title i { color: var(--accent); }

 
        .info-row { display: flex; align-items: center; gap: 1rem; padding: 0.85rem 0; border-bottom: 1px solid #f0f4ff; }
        .info-row:last-child { border-bottom: none; }
        .info-icon { width: 38px; height: 38px; border-radius: 10px; background: #eef2ff; display: flex; align-items: center; justify-content: center; color: var(--accent); font-size: 0.9rem; flex-shrink: 0; }
        .info-label { font-size: 0.78rem; color: var(--muted); margin-bottom: 2px; }
        .info-value { font-weight: 600; color: var(--text); font-size: 0.95rem; }

 
        .btn { display: inline-flex; align-items: center; gap: 0.5rem; padding: 0.7rem 1.4rem; border-radius: 10px; font-family: 'Cairo', sans-serif; font-size: 0.9rem; font-weight: 700; cursor: pointer; text-decoration: none; border: none; transition: all 0.2s; }
        .btn:hover { transform: translateY(-1px); }
        .btn-primary { background: linear-gradient(135deg, var(--accent), #6c8fff); color: white; }
        .btn-primary:hover { box-shadow: 0 4px 14px rgba(59,102,245,0.35); }
        .btn-secondary { background: var(--bg); color: var(--text); border: 1.5px solid var(--border); }
        .btn-secondary:hover { border-color: var(--accent); color: var(--accent); background: #eef2ff; }
        .btn-danger-outline { background: transparent; color: var(--danger); border: 1.5px solid #fca5a5; }
        .btn-danger-outline:hover { background: #fee2e2; }
        .btn-block { width: 100%; justify-content: center; }
        .btn-success { background: linear-gradient(135deg, var(--success), #059669); color: white; }
        .btn-success:hover { box-shadow: 0 4px 14px rgba(16,185,129,0.35); }

 
        .action-list { display: flex; flex-direction: column; gap: 0.6rem; }

 
        .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 999; align-items: center; justify-content: center; padding: 1rem; }
        .modal-overlay.open { display: flex; }
        .modal-box { background: white; border-radius: 20px; padding: 2rem; width: 100%; max-width: 560px; max-height: 90vh; overflow-y: auto; position: relative; box-shadow: 0 20px 60px rgba(0,0,0,0.2); animation: slideUp 0.25s ease; }
        @keyframes slideUp { from { transform: translateY(24px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        .modal-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; padding-bottom: 1rem; border-bottom: 2px solid var(--border); }
        .modal-head h3 { font-size: 1.15rem; font-weight: 800; color: var(--primary); display: flex; align-items: center; gap: 0.5rem; }
        .modal-head h3 i { color: var(--accent); }
        .modal-close-btn { background: #f0f4ff; border: none; width: 32px; height: 32px; border-radius: 50%; font-size: 1.1rem; cursor: pointer; color: var(--muted); display: flex; align-items: center; justify-content: center; transition: background 0.2s; }
        .modal-close-btn:hover { background: #e0e7ff; color: var(--accent); }

 
        .form-group { margin-bottom: 1rem; }
        .form-group label { display: block; font-size: 0.83rem; font-weight: 700; color: #4a5568; margin-bottom: 0.4rem; }
        .form-field { width: 100%; padding: 0.7rem 1rem; border: 1.5px solid var(--border); border-radius: 10px; font-family: 'Cairo', sans-serif; font-size: 0.93rem; color: var(--text); background: #f8faff; outline: none; transition: border-color 0.2s; }
        .form-field:focus { border-color: var(--accent); background: white; box-shadow: 0 0 0 3px rgba(59,102,245,0.1); }
        textarea.form-field { resize: vertical; }
        select.form-field { appearance: none; background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23718096' d='M6 8L1 3h10z'/%3E%3C/svg%3E"); background-repeat: no-repeat; background-position: right 1rem center; background-color: #f8faff; padding-right: 2.5rem; }
        select.form-field:focus { background-color: white; }
        .form-section-title { font-size: 0.85rem; font-weight: 800; color: var(--accent); text-transform: uppercase; letter-spacing: 0.06em; margin: 1.5rem 0 0.75rem; padding-bottom: 0.5rem; border-bottom: 1.5px solid #eef2ff; display: flex; align-items: center; gap: 0.4rem; }
        .modal-footer { display: flex; gap: 0.75rem; margin-top: 1.5rem; }

 
        .pw-wrap { position: relative; }
        .pw-wrap .form-field { padding-right: 3rem; }
        .pw-toggle { position: absolute; right: 0.9rem; top: 50%; transform: translateY(-50%); background: none; border: none; cursor: pointer; color: var(--muted); font-size: 0.95rem; transition: color 0.2s; }
        .pw-toggle:hover { color: var(--accent); }

 
        @media (max-width: 900px) {
            .page-wrap { grid-template-columns: 1fr; }
        }
        @media (max-width: 600px) {
            .nav-links a span { display: none; }
            .stats-bar { flex-wrap: wrap; }
            .stat-item { min-width: 50%; }
        }
    </style>
</head>
<body>

 
<nav class="nav">
    <div class="nav-inner">
                 <a href="Home.php" class="nav-brand">  <i class="fas fa-screwdriver-wrench" style="color:#3b66f5; margin-right:8px;"></i>Services <span>Artisans</span></a>

        <div class="nav-links">
            <a href="Home.php"><i class="fas fa-home"></i> <span>Accueil</span></a>
            <a href="search-results.php"><i class="fas fa-search"></i> <span>Recherche</span></a>
            <?php if ($userRole === 'Artisan'): ?>
                <a href="services.php"><i class="fas fa-briefcase"></i> <span>Mes services</span></a>
                <a href="mes-devis.php"><i class="fas fa-inbox"></i> <span>Devis reçus</span></a>
            <?php else: ?>
                <a href="mes-demandes.php"><i class="fas fa-file-alt"></i> <span>Mes demandes</span></a>
            <?php endif; ?>
            <form method="GET" action="profile.php" style="display:inline;">
                <input type="hidden" name="logout" value="1">
                <button type="submit" class="btn-logout-nav"><i class="fas fa-sign-out-alt"></i> <span>Déconnexion</span></button>
            </form>
        </div>
    </div>
</nav>

 
<div class="profile-cover"></div>

 
<div class="avatar-wrap">
    <div class="avatar-circle" onclick="document.getElementById('photoInput').click()" title="Changer la photo">
        <?php if (!empty($user['ProfilePictureURL'])): ?>
            <img src="data:image/jpeg;base64,<?php echo $user['ProfilePictureURL']; ?>" alt="">
        <?php else: ?>
            <?php echo strtoupper(substr($user['FullName'] ?? 'U', 0, 1)); ?>
        <?php endif; ?>
        <div class="avatar-overlay"><i class="fas fa-camera"></i></div>
    </div>
    <form method="POST" enctype="multipart/form-data" style="display:none;">
        <input type="hidden" name="action" value="uploadPhoto">
        <input type="file" id="photoInput" name="profilePhoto" accept="image/*" onchange="this.form.submit()">
    </form>

    <div class="profile-name-block">
        <h1><?php echo htmlspecialchars($user['FullName'] ?? 'Utilisateur'); ?></h1>
        <span class="role-badge <?php echo $userRole==='Artisan'?'':'client'; ?>">
            <i class="fas fa-<?php echo $userRole==='Artisan'?'hard-hat':'user'; ?>"></i>
            <?php echo $userRole === 'Artisan' ? 'Artisan' : 'Client'; ?>
        </span>
    </div>
</div>

 
<?php if ($userRole === 'Artisan'): ?>
<div style="max-width:700px;margin:0 auto 2rem;padding:0 5%;">
    <div class="stats-bar">
        <div class="stat-item">
            <div class="stat-num"><?php echo $serviceCount; ?></div>
            <div class="stat-label">Services</div>
        </div>
        <div class="stat-item">
            <div class="stat-num"><?php echo $reviewCount; ?></div>
            <div class="stat-label">Avis reçus</div>
        </div>
        <div class="stat-item">
            <div class="stat-num"><?php echo $employeeCount; ?></div>
            <div class="stat-label">Employés</div>
        </div>
        <div class="stat-item">
            <div class="stat-num"><?php echo $artisanData['YearsOfExperience'] ?? 0; ?></div>
            <div class="stat-label">Ans d'exp.</div>
        </div>
    </div>
</div>
<?php endif; ?>

 
<?php if ($successMsg): ?>
<div class="msg-wrap">
    <div class="message success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($successMsg); ?></div>
</div>
<?php endif; ?>
<?php if ($errorMsg): ?>
<div class="msg-wrap">
    <div class="message error"><i class="fas fa-exclamation-circle"></i> <?php echo $errorMsg; ?></div>
</div>
<?php endif; ?>

 
<div class="page-wrap">

 
    <div>
 
        <div class="card">
            <div class="card-title"><i class="fas fa-user"></i> Informations personnelles</div>
            <div class="info-row">
                <div class="info-icon"><i class="fas fa-id-card"></i></div>
                <div><div class="info-label">Nom complet</div><div class="info-value"><?php echo htmlspecialchars($user['FullName'] ?? '—'); ?></div></div>
            </div>
            <div class="info-row">
                <div class="info-icon"><i class="fas fa-at"></i></div>
                <div><div class="info-label">Email</div><div class="info-value"><?php echo htmlspecialchars($user['Email'] ?? '—'); ?></div></div>
            </div>
            <div class="info-row">
                <div class="info-icon"><i class="fas fa-phone"></i></div>
                <div><div class="info-label">Téléphone</div><div class="info-value"><?php echo htmlspecialchars($user['PhoneNumber'] ?? '—'); ?></div></div>
            </div>
            <div class="info-row">
                <div class="info-icon"><i class="fas fa-user-circle"></i></div>
                <div><div class="info-label">Nom d'utilisateur</div><div class="info-value"><?php echo htmlspecialchars($user['Username'] ?? '—'); ?></div></div>
            </div>
            <div class="info-row">
                <div class="info-icon"><i class="fas fa-calendar-alt"></i></div>
                <div><div class="info-label">Membre depuis</div><div class="info-value"><?php echo date('d/m/Y', strtotime($user['CreatedAt'])); ?></div></div>
            </div>
            <div style="margin-top:1.25rem;">
                <button class="btn btn-primary" onclick="openModal('editModal')">
                    <i class="fas fa-edit"></i> Modifier le profil
                </button>
            </div>
        </div>

 
        <?php if ($userRole === 'Artisan' && $artisanData): ?>
        <div class="card">
            <div class="card-title"><i class="fas fa-briefcase"></i> Informations professionnelles</div>
            <div class="info-row">
                <div class="info-icon"><i class="fas fa-tools"></i></div>
                <div><div class="info-label">Spécialité</div><div class="info-value"><?php echo htmlspecialchars(ucfirst($artisanData['Specialty'] ?? '—')); ?></div></div>
            </div>
            <div class="info-row">
                <div class="info-icon" style="background:#fff3eb;color:var(--accent2);"><i class="fas fa-map-marker-alt"></i></div>
                <div><div class="info-label">Wilaya</div><div class="info-value"><?php echo htmlspecialchars($artisanData['State'] ?? '—'); ?></div></div>
            </div>
            <div class="info-row">
                <div class="info-icon" style="background:#fff3eb;color:var(--accent2);"><i class="fas fa-city"></i></div>
                <div><div class="info-label">Commune</div><div class="info-value"><?php echo htmlspecialchars($artisanData['Municipality'] ?? '—'); ?></div></div>
            </div>
            <div class="info-row">
                <div class="info-icon"><i class="fas fa-map-pin"></i></div>
                <div><div class="info-label">Adresse</div><div class="info-value"><?php echo htmlspecialchars($artisanData['DetailedAddress'] ?? '—'); ?></div></div>
            </div>
            <div class="info-row">
                <div class="info-icon" style="background:#ecfdf5;color:var(--success);"><i class="fas fa-star"></i></div>
                <div><div class="info-label">Expérience</div><div class="info-value"><?php echo ($artisanData['YearsOfExperience'] ?? 0); ?> ans</div></div>
            </div>
        </div>
        <?php endif; ?>
    </div>

 
    <div>
        <div class="card">
            <div class="card-title"><i class="fas fa-bolt"></i> Actions rapides</div>
            <div class="action-list">
                <button class="btn btn-secondary btn-block" onclick="openModal('editModal')">
                    <i class="fas fa-user-edit"></i> Modifier le profil
                </button>
                <button class="btn btn-secondary btn-block" onclick="openModal('passwordModal')">
                    <i class="fas fa-key"></i> Changer le mot de passe
                </button>
                <?php if ($userRole === 'Artisan'): ?>
                <hr style="border:none;border-top:1px solid var(--border);margin:0.25rem 0;">
                <a href="services.php" class="btn btn-primary btn-block">
                    <i class="fas fa-briefcase"></i> Mes services
                </a>
                <a href="mes-devis.php" class="btn btn-success btn-block">
                    <i class="fas fa-inbox"></i> Devis reçus
                </a>
                <a href="employees.php" class="btn btn-success btn-block">
                    <i class="fas fa-users"></i> Mes employés
                </a>
                <?php else: ?>
                <hr style="border:none;border-top:1px solid var(--border);margin:0.25rem 0;">
                <a href="mes-demandes.php" class="btn btn-primary btn-block">
                    <i class="fas fa-file-alt"></i> Mes demandes de devis
                </a>
                <?php endif; ?>
                <hr style="border:none;border-top:1px solid var(--border);margin:0.25rem 0;">
                <a href="Home.php" class="btn btn-secondary btn-block">
                    <i class="fas fa-home"></i> Retour à l'accueil
                </a>
                <form method="GET" action="profile.php">
                    <input type="hidden" name="logout" value="1">
                    <button type="submit" class="btn btn-danger-outline btn-block">
                        <i class="fas fa-sign-out-alt"></i> Se déconnecter
                    </button>
                </form>
            </div>
        </div>

 
        <div class="card" style="text-align:center;padding:1.5rem;">
            <div style="font-size:2rem;color:#a5b4fc;margin-bottom:0.75rem;"><i class="fas fa-camera"></i></div>
            <p style="font-size:0.85rem;color:var(--muted);line-height:1.6;">Cliquez sur votre photo de profil pour la modifier.<br><small>JPG, PNG, GIF — max 5 Mo</small></p>
        </div>
    </div>
</div>

 
<div class="modal-overlay" id="editModal">
    <div class="modal-box">
        <div class="modal-head">
            <h3><i class="fas fa-user-edit"></i> Modifier le profil</h3>
            <button class="modal-close-btn" onclick="closeModal('editModal')">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="updateProfile">

            <div class="form-section-title"><i class="fas fa-user"></i> Informations de base</div>

            <div class="form-group">
                <label>Nom complet *</label>
                <input type="text" name="fullName" class="form-field" value="<?php echo htmlspecialchars($user['FullName'] ?? ''); ?>" required>
            </div>
            <div class="form-group">
                <label>Email *</label>
                <input type="email" name="email" class="form-field" value="<?php echo htmlspecialchars($user['Email'] ?? ''); ?>" required>
            </div>
            <div class="form-group">
                <label>Téléphone *</label>
                <input type="tel" name="phone" class="form-field" value="<?php echo htmlspecialchars($user['PhoneNumber'] ?? ''); ?>" required>
            </div>

            <?php if ($userRole === 'Artisan'): ?>
            <div class="form-section-title"><i class="fas fa-briefcase"></i> Informations professionnelles</div>

            <div class="form-group">
                <label>Spécialité</label>
                <select name="specialty" class="form-field">
                    <option value="">Sélectionner</option>
                    <?php
                    $specs = ['plomberie'=>'Plomberie','peinture'=>'Peinture','electricite'=>'Électricité','maconnerie'=>'Maçonnerie','menuiserie'=>'Menuiserie','climatisation'=>'Climatisation','soudure'=>'Soudure','autre'=>'Autre'];
                    foreach ($specs as $v => $l): ?>
                        <option value="<?php echo $v; ?>" <?php echo ($artisanData['Specialty']??'')===$v?'selected':''; ?>><?php echo $l; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label>Wilaya</label>
                <select name="wilaya" id="editWilaya" class="form-field" onchange="onWilayaChange()">
                    <option value="">Sélectionner une wilaya</option>
                </select>
            </div>

            <div class="form-group">
                <label>Commune</label>
                <select name="municipality" id="editMunicipality" class="form-field" disabled>
                    <option value="">Sélectionner d'abord une wilaya</option>
                </select>
            </div>

            <div class="form-group">
                <label>Adresse détaillée</label>
                <textarea name="address" class="form-field" rows="3"><?php echo htmlspecialchars($artisanData['DetailedAddress'] ?? ''); ?></textarea>
            </div>

            <div class="form-group">
                <label>Années d'expérience</label>
                <input type="number" name="experience" class="form-field" min="0" value="<?php echo $artisanData['YearsOfExperience'] ?? 0; ?>">
            </div>
            <?php endif; ?>

            <div class="modal-footer">
                <button type="submit" class="btn btn-primary" style="flex:1;justify-content:center;">
                    <i class="fas fa-save"></i> Enregistrer
                </button>
                <button type="button" class="btn btn-secondary" onclick="closeModal('editModal')">Annuler</button>
            </div>
        </form>
    </div>
</div>

 
<div class="modal-overlay" id="passwordModal">
    <div class="modal-box">
        <div class="modal-head">
            <h3><i class="fas fa-key"></i> Changer le mot de passe</h3>
            <button class="modal-close-btn" onclick="closeModal('passwordModal')">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="changePassword">

            <div class="form-group">
                <label>Mot de passe actuel *</label>
                <div class="pw-wrap">
                    <input type="password" name="currentPassword" id="pw1" class="form-field" required>
                    <button type="button" class="pw-toggle" onclick="togglePw('pw1',this)"><i class="fas fa-eye"></i></button>
                </div>
            </div>
            <div class="form-group">
                <label>Nouveau mot de passe *</label>
                <div class="pw-wrap">
                    <input type="password" name="newPassword" id="pw2" class="form-field" minlength="6" required>
                    <button type="button" class="pw-toggle" onclick="togglePw('pw2',this)"><i class="fas fa-eye"></i></button>
                </div>
            </div>
            <div class="form-group">
                <label>Confirmer le nouveau mot de passe *</label>
                <div class="pw-wrap">
                    <input type="password" name="confirmPassword" id="pw3" class="form-field" required>
                    <button type="button" class="pw-toggle" onclick="togglePw('pw3',this)"><i class="fas fa-eye"></i></button>
                </div>
            </div>

            <div class="modal-footer">
                <button type="submit" class="btn btn-primary" style="flex:1;justify-content:center;">
                    <i class="fas fa-shield-alt"></i> Modifier
                </button>
                <button type="button" class="btn btn-secondary" onclick="closeModal('passwordModal')">Annuler</button>
            </div>
        </form>
    </div>
</div>

<script src="locations.js"></script>
<script>
 
function openModal(id) {
    document.getElementById(id).classList.add('open');
    if (id === 'editModal') initWilayaDropdown();
}
function closeModal(id) {
    document.getElementById(id).classList.remove('open');
}
document.querySelectorAll('.modal-overlay').forEach(function(m) {
    m.addEventListener('click', function(e) {
        if (e.target === this) this.classList.remove('open');
    });
});

 
function initWilayaDropdown() {
    const sel = document.getElementById('editWilaya');
    if (!sel || sel.options.length > 1) return;  
    if (typeof getAllStates !== 'function') return;

    getAllStates().forEach(function(w) {
        const opt = document.createElement('option');
        opt.value = w; opt.textContent = w;
        sel.appendChild(opt);
    });

    const currentWilaya = '<?php echo addslashes($artisanData["State"] ?? ""); ?>';
    if (currentWilaya) {
        sel.value = currentWilaya;
        populateMunicipalities(currentWilaya, '<?php echo addslashes($artisanData["Municipality"] ?? ""); ?>');
    }
}

function onWilayaChange() {
    const w = document.getElementById('editWilaya').value;
    populateMunicipalities(w, '');
}

function populateMunicipalities(wilaya, preselect) {
    const sel = document.getElementById('editMunicipality');
    sel.innerHTML = '<option value="">Sélectionner une commune</option>';
    if (!wilaya || typeof getMunicipalitiesByState !== 'function') {
        sel.disabled = true; return;
    }
    getMunicipalitiesByState(wilaya).forEach(function(m) {
        const opt = document.createElement('option');
        opt.value = m; opt.textContent = m;
        if (m === preselect) opt.selected = true;
        sel.appendChild(opt);
    });
    sel.disabled = false;
}

 
function togglePw(id, btn) {
    const input = document.getElementById(id);
    const isText = input.type === 'text';
    input.type = isText ? 'password' : 'text';
    btn.innerHTML = isText ? '<i class="fas fa-eye"></i>' : '<i class="fas fa-eye-slash"></i>';
}
</script>
</body>
</html>