
 

class Database {
    constructor() {
        this.storageKey = 'employees_system_db';
        this.init();
    }

    init() {
 
        if (!localStorage.getItem(this.storageKey)) {
            const defaultData = {
                users: [
                    {
                        id: 1,
                        username: 'admin',
                        password: '123456', 
                        email: 'admin@example.com',
                        fullname: 'Administrateur',
                        phone: '',
                        accountType: 'admin',
                        createdAt: new Date().toISOString()
                    }
                ],
                sessions: [],
                activities: []
            };
            this.save(defaultData);
        }
    }

 
    getAll() {
        const data = localStorage.getItem(this.storageKey);
        return data ? JSON.parse(data) : null;
    }

 
    save(data) {
        localStorage.setItem(this.storageKey, JSON.stringify(data));
    }

     
    getUserByUsername(username) {
        const data = this.getAll();
        if (!data || !data.users) return null;
        return data.users.find(user => user.username === username);
    }

    getUserByEmail(email) {
        const data = this.getAll();
        if (!data || !data.users) return null;
        return data.users.find(user => user.email === email);
    }

    addUser(userData) {
        const data = this.getAll();
        if (!data) return false;

 
        if (this.getUserByUsername(userData.username)) {
            return { success: false, message: 'Ce nom d\'utilisateur existe déjà' };
        }

        if (this.getUserByEmail(userData.email)) {
            return { success: false, message: 'Cet e-mail est déjà utilisé' };
        }

 
        const newUser = {
            id: data.users.length > 0 ? Math.max(...data.users.map(u => u.id)) + 1 : 1,
            username: userData.username,
            password: userData.password, // En production, hasher le mot de passe
            email: userData.email,
            fullname: userData.fullname || '',
            phone: userData.phone || '',
            accountType: userData.accountType || 'client',
            profilePhoto: userData.profilePhoto || null,
            createdAt: new Date().toISOString(),
            isActive: true
        };

 
        if (userData.accountType === 'artisan') {
            newUser.specialty = userData.specialty || '';
            newUser.state = userData.state || '';
            newUser.municipality = userData.municipality || '';
            newUser.address = userData.address || '';
            newUser.experience = userData.experience || 0;
            newUser.description = userData.description || '';
            newUser.rating = 0;
            newUser.totalJobs = 0;
            newUser.isVerified = false;
        }

 
        if (userData.accountType === 'client') {
            newUser.totalRequests = 0;
        }

        data.users.push(newUser);
        this.save(data);

 
        this.logActivity('user_registered', newUser.id, `Nouvel utilisateur enregistré: ${newUser.username}`);

        return { success: true, message: 'Compte créé avec succès', user: newUser };
    }

     
    authenticate(username, password) {
        const user = this.getUserByUsername(username);
        if (!user) {
            return { success: false, message: 'Nom d\'utilisateur ou mot de passe incorrect' };
        }

        if (user.password !== password) {
            return { success: false, message: 'Nom d\'utilisateur ou mot de passe incorrect' };
        }

        if (!user.isActive) {
            return { success: false, message: 'Ce compte a été désactivé' };
        }

 
        const session = {
            userId: user.id,
            username: user.username,
            loginTime: new Date().toISOString(),
            token: this.generateToken()
        };

        const data = this.getAll();
        data.sessions.push(session);
        this.save(data);

 
        this.logActivity('user_login', user.id, `Connexion de l'utilisateur: ${user.username}`);

         
        sessionStorage.setItem('currentSession', JSON.stringify(session));
        sessionStorage.setItem('currentUser', JSON.stringify(user));

        return { success: true, message: 'Connexion réussie', user: user, session: session };
    }

 
    logout() {
        const sessionData = sessionStorage.getItem('currentSession');
        if (sessionData) {
            const session = JSON.parse(sessionData);
            const data = this.getAll();
            
 
            const sessionIndex = data.sessions.findIndex(s => s.token === session.token);
            if (sessionIndex !== -1) {
                data.sessions[sessionIndex].logoutTime = new Date().toISOString();
                this.save(data);
            }

 
            this.logActivity('user_logout', session.userId, `Déconnexion de l'utilisateur: ${session.username}`);
        }

        sessionStorage.removeItem('currentSession');
        sessionStorage.removeItem('currentUser');
    }

 
    getCurrentUser() {
        const userData = sessionStorage.getItem('currentUser');
        return userData ? JSON.parse(userData) : null;
    }

 
    isAuthenticated() {
        return sessionStorage.getItem('currentSession') !== null;
    }

 
    generateToken() {
        return 'token_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

 
    logActivity(type, userId, description) {
        const data = this.getAll();
        if (!data.activities) {
            data.activities = [];
        }

        const activity = {
            id: data.activities.length + 1,
            type: type,
            userId: userId,
            description: description,
            timestamp: new Date().toISOString()
        };

        data.activities.push(activity);
        this.save(data);
    }

 
    getActivities(userId = null) {
        const data = this.getAll();
        if (!data.activities) return [];

        let activities = data.activities;
        if (userId) {
            activities = activities.filter(activity => activity.userId === userId);
        }

        return activities.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    }

 
    getAllUsers() {
        const data = this.getAll();
        return data.users || [];
    }

 
    updateUser(userId, updates) {
        const data = this.getAll();
        const userIndex = data.users.findIndex(u => u.id === userId);
        
        if (userIndex === -1) {
            return { success: false, message: 'Utilisateur non trouvé' };
        }

        data.users[userIndex] = { ...data.users[userIndex], ...updates };
        this.save(data);
        
        this.logActivity('user_updated', userId, `Mise à jour du profil utilisateur`);
        
        return { success: true, message: 'Profil mis à jour avec succès', user: data.users[userIndex] };
    }

     
    getAllArtisans() {
        const data = this.getAll();
        return (data.users || []).filter(user => user.accountType === 'artisan' && user.isActive);
    }

     
    getArtisanById(artisanId) {
        const data = this.getAll();
        const artisan = data.users.find(user => user.id === parseInt(artisanId) && user.accountType === 'artisan');
        return artisan || null;
    }

     
    addReview(artisanId, clientId, rating, comment) {
        const data = this.getAll();
        if (!data.reviews) {
            data.reviews = [];
        }

        const review = {
            id: data.reviews.length > 0 ? Math.max(...data.reviews.map(r => r.id)) + 1 : 1,
            artisanId: parseInt(artisanId),
            clientId: parseInt(clientId),
            rating: parseInt(rating),
            comment: comment,
            createdAt: new Date().toISOString()
        };

        data.reviews.push(review);
        this.save(data);

 
        this.updateArtisanRating(artisanId);

        return { success: true, message: 'Commentaire ajouté avec succès', review: review };
    }

 
    getArtisanReviews(artisanId) {
        const data = this.getAll();
        if (!data.reviews) return [];
        
        const reviews = data.reviews.filter(r => r.artisanId === parseInt(artisanId));
        
         
        return reviews.map(review => {
            const client = this.getUserById(review.clientId);
            return {
                ...review,
                clientName: client ? (client.fullname || client.username) : 'Client anonyme',
                clientPhoto: client ? client.profilePhoto : null
            };
        }).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    }

     
    getUserById(userId) {
        const data = this.getAll();
        return data.users.find(user => user.id === parseInt(userId)) || null;
    }

 
    updateArtisanRating(artisanId) {
        const data = this.getAll();
        const reviews = this.getArtisanReviews(artisanId);
        
        if (reviews.length === 0) return;

        const totalRating = reviews.reduce((sum, review) => sum + review.rating, 0);
        const averageRating = (totalRating / reviews.length).toFixed(1);

        const userIndex = data.users.findIndex(u => u.id === parseInt(artisanId));
        if (userIndex !== -1) {
            data.users[userIndex].rating = parseFloat(averageRating);
            data.users[userIndex].totalJobs = reviews.length;
            this.save(data);
        }
    }

 
    
 
    addEmployee(artisanId, employeeData) {
        const data = this.getAll();
        if (!data.employees) {
            data.employees = [];
        }

        const newEmployee = {
            id: data.employees.length > 0 ? Math.max(...data.employees.map(e => e.id)) + 1 : 1,
            artisanId: parseInt(artisanId),
            name: employeeData.name,
            phone: employeeData.phone || '',
            email: employeeData.email || '',
            specialty: employeeData.specialty || '',
            experience: employeeData.experience || 0,
            notes: employeeData.notes || '',
            createdAt: new Date().toISOString(),
            isActive: true
        };

        data.employees.push(newEmployee);
        this.save(data);

        this.logActivity('employee_added', artisanId, `Nouvel employé ajouté: ${newEmployee.name}`);

        return { success: true, message: 'Employé ajouté avec succès', employee: newEmployee };
    }

 
    getArtisanEmployees(artisanId) {
        const data = this.getAll();
        if (!data.employees) return [];
        
        return data.employees.filter(emp => 
            emp.artisanId === parseInt(artisanId) && emp.isActive
        );
    }

 
    getEmployeeById(employeeId) {
        const data = this.getAll();
        if (!data.employees) return null;
        
        return data.employees.find(emp => emp.id === parseInt(employeeId)) || null;
    }

 
    updateEmployee(employeeId, updates) {
        const data = this.getAll();
        if (!data.employees) {
            return { success: false, message: 'Aucun employé trouvé' };
        }

        const employeeIndex = data.employees.findIndex(e => e.id === parseInt(employeeId));
        
        if (employeeIndex === -1) {
            return { success: false, message: 'Employé non trouvé' };
        }

        data.employees[employeeIndex] = { 
            ...data.employees[employeeIndex], 
            ...updates,
            updatedAt: new Date().toISOString()
        };
        this.save(data);
        
        this.logActivity('employee_updated', data.employees[employeeIndex].artisanId, `Mise à jour de l'employé: ${updates.name || data.employees[employeeIndex].name}`);
        
        return { success: true, message: 'Employé mis à jour avec succès', employee: data.employees[employeeIndex] };
    }

 
    deleteEmployee(employeeId) {
        const data = this.getAll();
        if (!data.employees) {
            return { success: false, message: 'Aucun employé trouvé' };
        }

        const employeeIndex = data.employees.findIndex(e => e.id === parseInt(employeeId));
        
        if (employeeIndex === -1) {
            return { success: false, message: 'Employé non trouvé' };
        }

        const employee = data.employees[employeeIndex];
        data.employees[employeeIndex].isActive = false;
        data.employees[employeeIndex].deletedAt = new Date().toISOString();
        this.save(data);
        
        this.logActivity('employee_deleted', employee.artisanId, `Suppression de l'employé: ${employee.name}`);
        
        return { success: true, message: 'Employé supprimé avec succès' };
    }

 
    getEmployeeJobs(employeeId) {
        const data = this.getAll();
        if (!data.jobs) return [];
        
        return data.jobs.filter(job => 
            job.employeeId === parseInt(employeeId) && job.isActive !== false
        ).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    }

 
    addJob(employeeId, artisanId, jobData) {
        const data = this.getAll();
        if (!data.jobs) {
            data.jobs = [];
        }

        const newJob = {
            id: data.jobs.length > 0 ? Math.max(...data.jobs.map(j => j.id)) + 1 : 1,
            employeeId: parseInt(employeeId),
            artisanId: parseInt(artisanId),
            title: jobData.title,
            description: jobData.description || '',
            status: jobData.status || 'pending',
            createdAt: new Date().toISOString(),
            isActive: true
        };

        data.jobs.push(newJob);
        this.save(data);

        this.logActivity('job_added', artisanId, `Nouveau travail assigné: ${newJob.title}`);

        return { success: true, message: 'Travail ajouté avec succès', job: newJob };
    }
}

 
const db = new Database();